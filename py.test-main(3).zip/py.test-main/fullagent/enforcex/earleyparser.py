"""earleyparser — Jay Earley's O(n^3) General Context-Free Grammar (CFG) Chart Parser.

Parses arbitrary Context-Free Grammars `G = (V, Sigma, P, S)` — including
left-recursive, right-recursive, nullable (`epsilon`), and ambiguous grammars —
without requiring Chomsky Normal Form conversion (Earley 1970):
  * Earley Item `(lhs -> rhs, dot_pos, origin_index)` stored in chart sets
    `S[0], S[1], ..., S[n]`.
  * **Predictor**: expands non-terminals to the right of the dot `• B`.
  * **Scanner**: matches terminal tokens `a` against input token `tokens[k]`.
  * **Completer**: advances parent items in `S[origin]` when `A -> alpha •`
    reaches the end of its production.

Used to validate complex recursive output structures (nested XML/HTML blocks,
recursive SQL/arithmetic queries, nested Markdown hierarchies) demanded by
system prompts.

Self-test: ``python3 -m fullagent.enforcex.earleyparser``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "CFGProduction",
    "EarleyItem",
    "EarleyParseReport",
    "EarleyCFGParser",
]


@dataclass(frozen=True)
class CFGProduction:
    lhs: str
    rhs: Tuple[str, ...]  # empty tuple () represents epsilon production


@dataclass(frozen=True)
class EarleyItem:
    prod: CFGProduction
    dot: int
    origin: int

    @property
    def completed(self) -> bool:
        return self.dot >= len(self.prod.rhs)

    @property
    def next_symbol(self) -> Optional[str]:
        if self.completed:
            return None
        return self.prod.rhs[self.dot]

    def advance(self) -> "EarleyItem":
        return EarleyItem(self.prod, self.dot + 1, self.origin)


@dataclass
class EarleyParseReport:
    accepted: bool
    tokens_consumed: int
    total_tokens: int
    chart_sizes: List[int] = field(default_factory=list)
    expected_next: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "accepted": self.accepted,
            "tokens_consumed": self.tokens_consumed,
            "total_tokens": self.total_tokens,
            "chart_sizes": list(self.chart_sizes),
            "expected_next": list(self.expected_next),
        }


class EarleyCFGParser:
    """General Context-Free Grammar chart parser supporting left recursion & nullable rules."""

    def __init__(self, start_symbol: str = "S") -> None:
        self.start_symbol = str(start_symbol)
        self.productions: List[CFGProduction] = []
        self.nonterminals: Set[str] = {self.start_symbol}

    def add_rule(self, lhs: str, *rhs_alternatives: Sequence[str]) -> None:
        nt = str(lhs)
        self.nonterminals.add(nt)
        for alt in rhs_alternatives:
            self.productions.append(CFGProduction(nt, tuple(str(x) for x in alt)))

    def parse(self, tokens: Sequence[str]) -> EarleyParseReport:
        tok_list = [str(t) for t in (tokens or ())]
        n = len(tok_list)
        chart: List[List[EarleyItem]] = [[] for _ in range(n + 1)]
        chart_sets: List[Set[EarleyItem]] = [set() for _ in range(n + 1)]

        def add_to_chart(k: int, item: EarleyItem) -> None:
            if item not in chart_sets[k]:
                chart_sets[k].add(item)
                chart[k].append(item)

        # Seed S[0] with start productions
        for prod in self.productions:
            if prod.lhs == self.start_symbol:
                add_to_chart(0, EarleyItem(prod, 0, 0))

        furthest_k = 0
        for k in range(n + 1):
            idx = 0
            while idx < len(chart[k]):
                item = chart[k][idx]
                idx += 1
                if not item.completed:
                    sym = item.next_symbol
                    assert sym is not None
                    if sym in self.nonterminals:
                        # Predictor
                        for prod in self.productions:
                            if prod.lhs == sym:
                                add_to_chart(k, EarleyItem(prod, 0, k))
                        # Aycock-Horspool nullable advancement if sym already completed at (k, k)
                        if any(it.completed and it.origin == k and it.prod.lhs == sym for it in chart[k]):
                            add_to_chart(k, item.advance())
                    else:
                        # Scanner
                        if k < n and tok_list[k] == sym:
                            add_to_chart(k + 1, item.advance())
                            furthest_k = max(furthest_k, k + 1)
                else:
                    # Completer
                    for prev_item in list(chart[item.origin]):
                        if not prev_item.completed and prev_item.next_symbol == item.prod.lhs:
                            add_to_chart(k, prev_item.advance())

        accepted = any(
            it.completed and it.origin == 0 and it.prod.lhs == self.start_symbol
            for it in chart[n]
        )
        expected = sorted({
            it.next_symbol
            for it in chart[furthest_k]
            if not it.completed and it.next_symbol is not None and it.next_symbol not in self.nonterminals
        })
        return EarleyParseReport(
            accepted=accepted,
            tokens_consumed=furthest_k,
            total_tokens=n,
            chart_sizes=[len(c) for c in chart],
            expected_next=expected,
        )


def _self_test() -> int:
    # Left-recursive arithmetic & parenthesized expression grammar:
    # E -> E + T | T
    # T -> T * F | F
    # F -> ( E ) | id
    p = EarleyCFGParser("E")
    p.add_rule("E", ("E", "+", "T"), ("T",))
    p.add_rule("T", ("T", "*", "F"), ("F",))
    p.add_rule("F", ("(", "E", ")"), ("id",))

    rep_ok = p.parse(["id", "+", "id", "*", "(", "id", "+", "id", ")"])
    assert rep_ok.accepted and rep_ok.tokens_consumed == 9, rep_ok.to_dict()

    # Unclosed parenthesis rejected with expected_next diagnostics
    rep_bad = p.parse(["(", "id", "+", "id"])
    assert not rep_bad.accepted and ")" in rep_bad.expected_next

    print("earleyparser._self_test: OK PASS (Jay Earley Predictor/Scanner/Completer on left-recursive CFG)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
