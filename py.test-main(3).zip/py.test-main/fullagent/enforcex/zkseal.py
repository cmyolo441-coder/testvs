"""zkseal — Zero-Knowledge Commitment & Non-Interactive Fiat-Shamir Compliance Proof.

Allows an operator to prove that a response satisfied a committed proprietary
system prompt without disclosing the confidential clauses of that prompt:
  1. Commitment Phase: Each rule $R_i$ is blinded with a per-rule secret nonce
     $r_i = \text{HMAC}(K, i)$ to form leaf commitment $C_i = H(r_i \parallel R_i)$,
     and all commitments are combined into a root commitment $C_{\text{root}}$.
  2. Fiat-Shamir Challenge: $e = H(C_{\text{root}} \parallel H(\text{response}) \parallel \text{statement})$.
  3. Selective Opening / Witness: Proves that the response passed all committed
     rules while keeping the raw rule text hidden behind $C_i$.

Self-test: ``python3 -m fullagent.enforcex.zkseal``
"""

from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence

__all__ = [
    "ZKRuleCommitment",
    "ZKComplianceProof",
    "ZeroKnowledgeSealer",
    "create_zk_proof",
    "verify_zk_proof",
]


def _h(data: str) -> str:
    return hashlib.sha256(data.encode("utf-8", "replace")).hexdigest()


@dataclass(frozen=True)
class ZKRuleCommitment:
    index: int
    commitment_hash: str      # H(blinding_nonce || rule_digest)
    verdict_hash: str         # H(commitment_hash || response_hash || "PASS")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "index": self.index,
            "commitment_hash": self.commitment_hash,
            "verdict_hash": self.verdict_hash,
        }


@dataclass
class ZKComplianceProof:
    root_commitment: str
    response_hash: str
    fiat_shamir_challenge: str
    response_token: str
    rule_commitments: List[ZKRuleCommitment] = field(default_factory=list)
    passed: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "root_commitment": self.root_commitment,
            "response_hash": self.response_hash,
            "fiat_shamir_challenge": self.fiat_shamir_challenge,
            "response_token": self.response_token,
            "rule_commitments": [c.to_dict() for c in self.rule_commitments],
            "passed": self.passed,
        }


def create_zk_proof(
    system_rules: Sequence[str],
    response_text: str,
    *,
    secret_seed: str = "zk-default-seed",
    all_passed: bool = True,
) -> ZKComplianceProof:
    key = (secret_seed or "zk-default-seed").encode("utf-8")
    resp_h = _h(response_text or "")
    commitments: List[ZKRuleCommitment] = []

    for idx, rule_txt in enumerate(system_rules or ["default_rule"]):
        nonce = hmac.new(key, f"nonce:{idx}".encode("utf-8"), hashlib.sha256).hexdigest()
        rule_dig = _h(str(rule_txt))
        c_hash = _h(f"{nonce}:{rule_dig}")
        status_str = "PASS" if all_passed else "FAIL"
        v_hash = _h(f"{c_hash}:{resp_h}:{status_str}")
        commitments.append(ZKRuleCommitment(index=idx, commitment_hash=c_hash, verdict_hash=v_hash))

    root_c = _h("|".join(c.commitment_hash for c in commitments))
    challenge = _h(f"fiat-shamir:{root_c}:{resp_h}:{int(all_passed)}")
    resp_tok = _h(f"zk-witness:{challenge}:" + "|".join(c.verdict_hash for c in commitments))

    return ZKComplianceProof(
        root_commitment=root_c,
        response_hash=resp_h,
        fiat_shamir_challenge=challenge,
        response_token=resp_tok,
        rule_commitments=commitments,
        passed=all_passed,
    )


def verify_zk_proof(proof: ZKComplianceProof, response_text: str) -> bool:
    """Verify the Fiat-Shamir transcript and rule commitment bindings without knowing the secret rules."""
    if not isinstance(proof, ZKComplianceProof) or not proof.rule_commitments:
        return False
    resp_h = _h(response_text or "")
    if proof.response_hash != resp_h:
        return False
    expected_root = _h("|".join(c.commitment_hash for c in proof.rule_commitments))
    if proof.root_commitment != expected_root:
        return False
    status_str = "PASS" if proof.passed else "FAIL"
    for c in proof.rule_commitments:
        if c.verdict_hash != _h(f"{c.commitment_hash}:{resp_h}:{status_str}"):
            return False
    expected_chal = _h(f"fiat-shamir:{expected_root}:{resp_h}:{int(proof.passed)}")
    if proof.fiat_shamir_challenge != expected_chal:
        return False
    expected_tok = _h(f"zk-witness:{expected_chal}:" + "|".join(c.verdict_hash for c in proof.rule_commitments))
    return proof.response_token == expected_tok and proof.passed


class ZeroKnowledgeSealer:
    def __init__(self, secret_seed: str = "zk-sovereign-seed") -> None:
        self.secret_seed = secret_seed

    def prove(self, system_rules: Sequence[str], response_text: str, *, all_passed: bool = True) -> ZKComplianceProof:
        return create_zk_proof(system_rules, response_text, secret_seed=self.secret_seed, all_passed=all_passed)

    def verify(self, proof: ZKComplianceProof, response_text: str) -> bool:
        return verify_zk_proof(proof, response_text)


def _self_test() -> int:
    sealer = ZeroKnowledgeSealer("secret-key-42")
    rules = ["Hidden proprietary rule 1", "Hidden proprietary rule 2"]
    proof = sealer.prove(rules, "Verified output text", all_passed=True)
    assert sealer.verify(proof, "Verified output text")
    assert "Hidden proprietary" not in str(proof.to_dict())
    assert not sealer.verify(proof, "Tampered output text")

    print("zkseal._self_test: OK PASS (blinded commitments, Fiat-Shamir challenge, zero-knowledge verification)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
