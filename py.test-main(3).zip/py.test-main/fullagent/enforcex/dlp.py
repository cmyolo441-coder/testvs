"""dlp — Enterprise Data Loss Prevention (DLP), Secret Scrubber & Reversible Token Vault.

Self-test: ``python3 -m fullagent.enforcex.dlp``
"""

from __future__ import annotations

import hashlib
import re
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

__all__ = [
    "DLPMatch",
    "DLPReport",
    "VaultedRedactor",
    "luhn_valid",
    "scan_text",
    "redact_text",
]


@dataclass
class DLPMatch:
    kind: str
    category: str
    severity: str
    start: int
    end: int
    masked_value: str
    fingerprint: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "category": self.category,
            "severity": self.severity,
            "start": self.start,
            "end": self.end,
            "masked_value": self.masked_value,
            "fingerprint": self.fingerprint,
        }

    def to_violation(self) -> Dict[str, Any]:
        return {
            "rule_id": f"DLP-{self.kind}",
            "category": f"dlp_{self.category}",
            "severity": self.severity,
            "evidence": self.masked_value,
            "message": f"Sensitive {self.category} detected ({self.kind})",
            "remediation": f"Redact or vault {self.kind} before logging or sending externally.",
        }


@dataclass
class DLPReport:
    clean: bool = True
    matches: List[DLPMatch] = field(default_factory=list)
    redacted_text: str = ""
    risk_score: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "clean": self.clean,
            "matches_count": len(self.matches),
            "matches": [m.to_dict() for m in self.matches],
            "redacted_text": self.redacted_text,
            "risk_score": round(self.risk_score, 2),
        }


_PATTERNS: List[Tuple[str, str, str, re.Pattern[str]]] = [
    (
        "PRIVATE_KEY_PEM",
        "secret",
        "critical",
        re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----.*?-----END (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----", re.DOTALL),
    ),
    (
        "ANTHROPIC_KEY",
        "secret",
        "critical",
        re.compile(r"\bsk-ant-[a-zA-Z0-9_-]{20,120}\b"),
    ),
    (
        "OPENAI_KEY",
        "secret",
        "critical",
        re.compile(r"\bsk-(?:proj-|live-|test-)?[a-zA-Z0-9]{20,120}\b"),
    ),
    (
        "AWS_ACCESS_KEY",
        "secret",
        "critical",
        re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    ),
    (
        "GITHUB_TOKEN",
        "secret",
        "critical",
        re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{30,100}|github_pat_[A-Za-z0-9_]{30,120})\b"),
    ),
    (
        "GOOGLE_API_KEY",
        "secret",
        "high",
        re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b"),
    ),
    (
        "SLACK_TOKEN",
        "secret",
        "high",
        re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{16,80}\b"),
    ),
    (
        "STRIPE_SECRET",
        "secret",
        "critical",
        re.compile(r"\b(?:sk|rk)_(?:live|test)_[0-9a-zA-Z]{20,99}\b"),
    ),
    (
        "JWT_TOKEN",
        "secret",
        "high",
        re.compile(r"\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b"),
    ),
    (
        "DB_CONNECTION_URI",
        "infra",
        "critical",
        re.compile(r"\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|amqp)://[^:\s/@]+:[^@\s/]+@[^\s\"'<>]+"),
    ),
    (
        "US_SSN",
        "pii",
        "high",
        re.compile(r"\b(?!000|666|9\d\d)\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b"),
    ),
    (
        "EMAIL_ADDRESS",
        "pii",
        "low",
        re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,12}\b"),
    ),
]

_CC_CANDIDATE_RE = re.compile(r"\b(?:\d[ -]*?){13,19}\b")


def luhn_valid(number_str: str) -> bool:
    digits = [int(c) for c in (number_str or "") if c.isdigit()]
    if not (13 <= len(digits) <= 19) or len(set(digits)) == 1:
        return False
    total = 0
    for i, d in enumerate(digits[::-1]):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _mask(raw: str) -> str:
    s = raw.strip()
    return "***" if len(s) <= 8 else f"{s[:4]}...{s[-3:]}"


def scan_text(text: str, *, include_pii: bool = True) -> DLPReport:
    if not text or not isinstance(text, str):
        return DLPReport(clean=True, redacted_text=str(text or ""))

    raw_hits: List[Tuple[int, int, str, str, str, str]] = []
    for kind, cat, sev, pat in _PATTERNS:
        if not include_pii and cat == "pii":
            continue
        for m in pat.finditer(text):
            raw_hits.append((m.start(), m.end(), kind, cat, sev, m.group(0)))

    if include_pii:
        for m in _CC_CANDIDATE_RE.finditer(text):
            cand = m.group(0)
            if luhn_valid(cand):
                raw_hits.append((m.start(), m.end(), "CREDIT_CARD", "pii", "high", cand))

    raw_hits.sort(key=lambda x: (x[0], -(x[1] - x[0])))
    filtered: List[Tuple[int, int, str, str, str, str]] = []
    last_end = -1
    for item in raw_hits:
        if item[0] >= last_end:
            filtered.append(item)
            last_end = item[1]

    matches: List[DLPMatch] = []
    out_parts: List[str] = []
    cursor = 0
    for idx, (st, en, kind, cat, sev, raw_val) in enumerate(filtered, 1):
        out_parts.append(text[cursor:st])
        out_parts.append(f"<REDACTED:{kind}:{idx}>")
        cursor = en
        fp = hashlib.sha256(raw_val.encode("utf-8", "replace")).hexdigest()[:12]
        matches.append(
            DLPMatch(
                kind=kind,
                category=cat,
                severity=sev,
                start=st,
                end=en,
                masked_value=_mask(raw_val),
                fingerprint=fp,
            )
        )
    out_parts.append(text[cursor:])
    redacted = "".join(out_parts)

    weights = {"critical": 45.0, "high": 25.0, "medium": 12.0, "low": 5.0}
    risk = min(100.0, sum(weights.get(m.severity, 10.0) for m in matches))
    return DLPReport(
        clean=len(matches) == 0,
        matches=matches,
        redacted_text=redacted,
        risk_score=risk,
    )


def redact_text(text: str, *, include_pii: bool = True) -> str:
    return scan_text(text, include_pii=include_pii).redacted_text


class VaultedRedactor:
    def __init__(self, *, include_pii: bool = True) -> None:
        self.include_pii = include_pii
        self._lock = threading.Lock()
        self._vault: Dict[str, str] = {}
        self._counter = 0

    def scrub(self, text: str) -> Tuple[str, List[DLPMatch]]:
        if not text or not isinstance(text, str):
            return str(text or ""), []
        rep = scan_text(text, include_pii=self.include_pii)
        if rep.clean:
            return text, []
        with self._lock:
            out_parts: List[str] = []
            cursor = 0
            for m in rep.matches:
                self._counter += 1
                token = f"<VAULT:{m.kind}:{self._counter}>"
                self._vault[token] = text[m.start:m.end]
                out_parts.append(text[cursor:m.start])
                out_parts.append(token)
                cursor = m.end
            out_parts.append(text[cursor:])
            return "".join(out_parts), rep.matches

    def restore(self, text: str) -> str:
        if not text or "<VAULT:" not in text:
            return str(text or "")
        with self._lock:
            out = text
            for token, raw_val in self._vault.items():
                if token in out:
                    out = out.replace(token, raw_val)
            return out


def _self_test() -> int:
    sample = (
        "Connect to postgres://admin:s3cr3tPass@db.internal:5432/prod "
        "using key sk-proj-ABCDEFGHIJKLMNOPQRSTUVWXYZ123456 "
        "and AWS AKIAIOSFODNN7EXAMPLE or contact alice@example.com."
    )
    rep = scan_text(sample)
    assert not rep.clean, rep.to_dict()
    kinds = {m.kind for m in rep.matches}
    assert "DB_CONNECTION_URI" in kinds, kinds
    assert "OPENAI_KEY" in kinds, kinds
    assert "AWS_ACCESS_KEY" in kinds, kinds
    assert "EMAIL_ADDRESS" in kinds, kinds
    assert "s3cr3tPass" not in rep.redacted_text
    assert "sk-proj-" not in rep.redacted_text

    assert luhn_valid("4532 0151 1283 0366")
    assert not luhn_valid("4532 0151 1283 0367")

    vr = VaultedRedactor()
    scrubbed, matches = vr.scrub(sample)
    assert len(matches) == 4 and "<VAULT:" in scrubbed
    assert vr.restore(scrubbed) == sample

    print("dlp._self_test: OK PASS (keys, DB URI, Luhn CC, PII, reversible vault)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
