"""diffprivacy — (epsilon, delta)-Differential Privacy, Renyi DP Accountant & Mechanisms.

Provides mathematically rigorous Differential Privacy primitives (Dwork & Roth
2014; Mironov 2017 Rényi Differential Privacy) for sanitizing aggregate
telemetry, audit metrics, and prompt statistics:
  1. **Laplace Mechanism (`Lap(Delta_1 / epsilon)`)**: pure `(epsilon, 0)`-DP
     via inverse-CDF sampling with `os.urandom` cryptographic randomness.
  2. **Analytic Gaussian Mechanism (`N(0, sigma^2)`)**: `(epsilon, delta)`-DP
     with `sigma = Delta_2 * sqrt(2 * ln(1.25 / delta)) / epsilon`.
  3. **Exponential Mechanism (`exp(epsilon * u(x, r) / (2 * Delta_u))`)**:
     selects discrete candidates privately with probability proportional to utility.
  4. **Rényi Differential Privacy (RDP) Composition & Conversion to `(epsilon, delta)`-DP**:
     tracks cumulative RDP `epsilon_RDP(alpha)` across queries at orders
     `alpha in {2, 4, 8, 16, 32, 64}` and converts via Mironov Proposition 3:
     `epsilon(delta) = min_{alpha > 1} (epsilon_RDP(alpha) + ln(1 / delta) / (alpha - 1))`.

Self-test: ``python3 -m fullagent.enforcex.diffprivacy``
"""

from __future__ import annotations

import math
import os
import struct
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "PrivacyBudgetState",
    "DifferentialPrivacyAccountant",
    "laplace_noise",
    "gaussian_noise",
    "exponential_mechanism_probs",
]


def _crypto_uniform_open01() -> float:
    """Cryptographically secure uniform float in `(0, 1)` from `os.urandom`."""
    raw = struct.unpack(">Q", os.urandom(8))[0]
    return (raw + 1.0) / float((1 << 64) + 2.0)


def laplace_noise(scale_b: float) -> float:
    """Sample from `Laplace(0, b)` using exact inverse transform `F^{-1}(u)`."""
    b = max(1e-12, float(scale_b))
    u = _crypto_uniform_open01() - 0.5
    sign = 1.0 if u >= 0.0 else -1.0
    return -b * sign * math.log(max(1e-15, 1.0 - 2.0 * abs(u)))


def gaussian_noise(sigma: float) -> float:
    """Sample from `N(0, sigma^2)` via Box-Muller transform."""
    s = max(1e-12, float(sigma))
    u1 = _crypto_uniform_open01()
    u2 = _crypto_uniform_open01()
    z0 = math.sqrt(-2.0 * math.log(u1)) * math.cos(2.0 * math.pi * u2)
    return s * z0


def exponential_mechanism_probs(
    scores: Sequence[float],
    *,
    epsilon: float = 1.0,
    sensitivity: float = 1.0,
) -> List[float]:
    """Compute exact selection probabilities for the McSherry-Talwar Exponential Mechanism."""
    if not scores:
        return []
    eps = max(1e-6, float(epsilon))
    sens = max(1e-6, float(sensitivity))
    scaled = [(eps * float(u)) / (2.0 * sens) for u in scores]
    m = max(scaled)
    weights = [math.exp(x - m) for x in scaled]
    tot = sum(weights)
    return [w / tot for w in weights]


@dataclass
class PrivacyBudgetState:
    queries_count: int
    basic_epsilon: float
    rdp_converted_epsilon: float
    delta: float
    within_budget: bool

    def to_dict(self) -> Dict[str, Any]:
        return {
            "queries_count": self.queries_count,
            "basic_epsilon": round(self.basic_epsilon, 4),
            "rdp_converted_epsilon": round(self.rdp_converted_epsilon, 4),
            "delta": self.delta,
            "within_budget": self.within_budget,
        }


class DifferentialPrivacyAccountant:
    """Tracks cumulative privacy loss using Rényi Differential Privacy (RDP) orders."""

    ORDERS: Tuple[float, ...] = (1.5, 2.0, 3.0, 4.0, 8.0, 16.0, 32.0, 64.0)

    def __init__(self, max_epsilon: float = 5.0, target_delta: float = 1e-5) -> None:
        self.max_epsilon = float(max_epsilon)
        self.target_delta = max(1e-12, float(target_delta))
        self.rdp_totals: Dict[float, float] = {a: 0.0 for a in self.ORDERS}
        self.basic_epsilon = 0.0
        self.queries_count = 0

    def record_gaussian_query(self, sensitivity_l2: float, sigma: float) -> float:
        """Gaussian mechanism with noise `sigma` satisfies `(alpha, alpha * Delta_2^2 / (2 * sigma^2))`-RDP."""
        self.queries_count += 1
        s2 = max(1e-12, float(sigma)) ** 2
        d2 = float(sensitivity_l2) ** 2
        for alpha in self.ORDERS:
            self.rdp_totals[alpha] += (alpha * d2) / (2.0 * s2)
        eps_single = float(sensitivity_l2) * math.sqrt(2.0 * math.log(1.25 / self.target_delta)) / max(1e-12, float(sigma))
        self.basic_epsilon += eps_single
        return self.effective_epsilon()

    def effective_epsilon(self, delta: Optional[float] = None) -> float:
        d = max(1e-15, float(delta if delta is not None else self.target_delta))
        if self.queries_count == 0:
            return 0.0
        best = float("inf")
        for alpha in self.ORDERS:
            eps_a = self.rdp_totals[alpha] + math.log(1.0 / d) / (alpha - 1.0)
            if eps_a < best:
                best = eps_a
        return min(best, self.basic_epsilon)

    def state(self) -> PrivacyBudgetState:
        eff = self.effective_epsilon()
        return PrivacyBudgetState(
            queries_count=self.queries_count,
            basic_epsilon=self.basic_epsilon,
            rdp_converted_epsilon=eff,
            delta=self.target_delta,
            within_budget=(eff <= self.max_epsilon),
        )


def _self_test() -> int:
    acc = DifferentialPrivacyAccountant(max_epsilon=10.0, target_delta=1e-5)
    for _ in range(10):
        acc.record_gaussian_query(sensitivity_l2=1.0, sigma=5.0)
    st = acc.state()
    # RDP sub-linear composition is strictly tighter than naive basic composition!
    assert st.rdp_converted_epsilon < st.basic_epsilon, st.to_dict()
    assert st.within_budget

    probs = exponential_mechanism_probs([10.0, 20.0, 50.0], epsilon=2.0, sensitivity=5.0)
    assert abs(sum(probs) - 1.0) < 1e-6 and probs[2] > probs[1] > probs[0]

    print("diffprivacy._self_test: OK PASS (Laplace/Gaussian/Exponential mechanisms + Renyi DP composition)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
