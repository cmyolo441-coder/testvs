"""conformal — Split & Adaptive Conformal Prediction (ACI) Uncertainty Calibrator.

Provides finite-sample, distribution-free coverage guarantees (Vovk, Gammerman
& Shafer 2005; Gibbs & Candès 2021 Adaptive Conformal Inference):
  1. **Split Conformal Quantile (`q_hat`)**:
     Given `n` calibration nonconformity residuals `R_1, ..., R_n` and miscoverage
     level `alpha in (0, 1)`, computes the finite-sample corrected order statistic
     at level `ceil((n + 1) * (1 - alpha)) / n`, guaranteeing
     `P(Y_{n+1} in [y_hat - q_hat, y_hat + q_hat]) >= 1 - alpha`.
  2. **Conformal p-Value (`p(y)`)**:
     `p(y) = (1 + |{i : R_i >= R_{n+1}}|) / (n + 1)` — detects out-of-distribution
     adversarial turns when `p(y) < alpha`.
  3. **Gibbs-Candès Online Adaptive Conformal Inference (ACI)**:
     Updates `alpha_{t+1} = alpha_t + gamma * (alpha_target - err_t)` so long-run
     empirical coverage converges to `1 - alpha_target` even under distribution shift!

Self-test: ``python3 -m fullagent.enforcex.conformal``
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "ConformalInterval",
    "SplitConformalCalibrator",
    "AdaptiveConformalInference",
]


@dataclass
class ConformalInterval:
    prediction: float
    lower: float
    upper: float
    quantile_radius: float
    alpha: float
    p_value: float

    def contains(self, true_y: float) -> bool:
        return self.lower <= float(true_y) <= self.upper

    def to_dict(self) -> Dict[str, Any]:
        return {
            "prediction": round(self.prediction, 4),
            "lower": round(self.lower, 4),
            "upper": round(self.upper, 4),
            "quantile_radius": round(self.quantile_radius, 4),
            "alpha": round(self.alpha, 4),
            "p_value": round(self.p_value, 4),
        }


class SplitConformalCalibrator:
    """Distribution-free split conformal prediction calibrator."""

    def __init__(self, residuals: Optional[Sequence[float]] = None) -> None:
        self.residuals: List[float] = sorted(abs(float(r)) for r in (residuals or ()))

    def calibrate_residual(self, y_true: float, y_pred: float) -> None:
        r = abs(float(y_true) - float(y_pred))
        self.residuals.append(r)
        self.residuals.sort()

    def quantile(self, alpha: float = 0.10) -> float:
        n = len(self.residuals)
        if n == 0:
            return 0.0
        a = max(0.001, min(0.999, float(alpha)))
        k = int(math.ceil((n + 1) * (1.0 - a)))
        idx = max(0, min(n - 1, k - 1))
        return self.residuals[idx]

    def p_value(self, residual: float) -> float:
        n = len(self.residuals)
        if n == 0:
            return 1.0
        r = abs(float(residual))
        ge_count = sum(1 for x in self.residuals if x >= r - 1e-12)
        return (1.0 + ge_count) / float(n + 1)

    def predict_interval(self, y_pred: float, *, alpha: float = 0.10, candidate_residual: float = 0.0) -> ConformalInterval:
        q = self.quantile(alpha)
        pval = self.p_value(candidate_residual)
        yp = float(y_pred)
        return ConformalInterval(
            prediction=yp,
            lower=yp - q,
            upper=yp + q,
            quantile_radius=q,
            alpha=alpha,
            p_value=pval,
        )


class AdaptiveConformalInference:
    """Gibbs & Candès (2021) online Adaptive Conformal Inference under distribution shift."""

    def __init__(self, target_alpha: float = 0.10, step_size_gamma: float = 0.05, initial_residuals: Sequence[float] = ()) -> None:
        self.target_alpha = max(0.01, min(0.50, float(target_alpha)))
        self.alpha_t = self.target_alpha
        self.gamma = max(0.001, float(step_size_gamma))
        self.calibrator = SplitConformalCalibrator(initial_residuals)
        self.errors: List[int] = []

    def step(self, y_pred: float, y_true: float) -> ConformalInterval:
        interval = self.calibrator.predict_interval(
            y_pred,
            alpha=self.alpha_t,
            candidate_residual=abs(float(y_true) - float(y_pred)),
        )
        err_t = 0 if interval.contains(y_true) else 1
        self.errors.append(err_t)
        # Gibbs-Candès update: alpha_{t+1} = alpha_t + gamma * (target_alpha - err_t)
        self.alpha_t = max(0.005, min(0.95, self.alpha_t + self.gamma * (self.target_alpha - err_t)))
        self.calibrator.calibrate_residual(y_true, y_pred)
        return interval


def _self_test() -> int:
    cal = SplitConformalCalibrator([0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0])
    iv = cal.predict_interval(90.0, alpha=0.10, candidate_residual=1.0)
    assert iv.quantile_radius >= 4.5
    assert iv.contains(93.0) and not iv.contains(99.0)
    assert iv.p_value > 0.5  # residual=1.0 is small/conforming

    # Outlier residual=12.0 gets minimal conformal p-value = 1 / 11
    assert abs(cal.p_value(12.0) - (1.0 / 11.0)) < 1e-6

    # Verify ACI decreases alpha_t (widens interval) when miscoverage occurs (err_t = 1)
    aci = AdaptiveConformalInference(target_alpha=0.10, step_size_gamma=0.05, initial_residuals=[1.0, 2.0, 3.0, 4.0])
    a_before = aci.alpha_t
    aci.step(y_pred=90.0, y_true=50.0)  # miss -> err_t = 1 -> alpha_t decreases!
    assert aci.alpha_t < a_before

    print("conformal._self_test: OK PASS (Split conformal finite-sample quantile, p-values, Gibbs-Candes ACI)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
