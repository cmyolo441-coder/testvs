"""automata — Nondeterministic & Deterministic Finite Automata (NFA -> DFA) Protocol Compiler.

Implements classical automata theory in pure Python for O(N) sequence verification:
  * `NFA`: Nondeterministic Finite Automaton with epsilon-transitions
  * `epsilon_closure()` & `subset_construct()`: Powerset construction converting
    any NFA into an equivalent Deterministic Finite Automaton (`DFA`)
  * `minimize_dfa()`: Hopcroft-style partition refinement minimization
  * `intersect_dfa()`: Product automaton construction for conjunctive rules
  * Protocol sequence verification over token/section/action streams.

Self-test: ``python3 -m fullagent.enforcex.automata``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "NFA",
    "DFA",
    "AutomataRunReport",
    "subset_construct",
    "minimize_dfa",
    "intersect_dfa",
]


@dataclass
class NFA:
    states: Set[int] = field(default_factory=set)
    alphabet: Set[str] = field(default_factory=set)
    transitions: Dict[Tuple[int, str], Set[int]] = field(default_factory=dict)  # "" = epsilon
    start_state: int = 0
    accept_states: Set[int] = field(default_factory=set)

    def add_transition(self, src: int, symbol: str, dst: int) -> None:
        self.states.add(src)
        self.states.add(dst)
        if symbol:
            self.alphabet.add(symbol)
        self.transitions.setdefault((src, symbol), set()).add(dst)

    def epsilon_closure(self, state_set: Iterable[int]) -> FrozenSet[int]:
        stack = list(state_set)
        closure: Set[int] = set(stack)
        while stack:
            s = stack.pop()
            for nxt in self.transitions.get((s, ""), ()):
                if nxt not in closure:
                    closure.add(nxt)
                    stack.append(nxt)
        return frozenset(closure)


@dataclass
class DFA:
    states: Set[int] = field(default_factory=set)
    alphabet: Set[str] = field(default_factory=set)
    transitions: Dict[Tuple[int, str], int] = field(default_factory=dict)
    start_state: int = 0
    accept_states: Set[int] = field(default_factory=set)

    def accepts(self, sequence: Sequence[str]) -> Tuple[bool, List[int]]:
        cur = self.start_state
        trace = [cur]
        for sym in sequence:
            nxt = self.transitions.get((cur, sym))
            if nxt is None:
                return False, trace
            cur = nxt
            trace.append(cur)
        return (cur in self.accept_states), trace


@dataclass
class AutomataRunReport:
    accepted: bool
    trace: List[int]
    steps: int
    final_state: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "accepted": self.accepted,
            "trace": list(self.trace),
            "steps": self.steps,
            "final_state": self.final_state,
        }


def subset_construct(nfa: NFA) -> DFA:
    """Convert an NFA (with epsilon transitions) to an equivalent DFA via powerset construction."""
    start_set = nfa.epsilon_closure([nfa.start_state])
    state_map: Dict[FrozenSet[int], int] = {start_set: 0}
    worklist: List[FrozenSet[int]] = [start_set]
    dfa_trans: Dict[Tuple[int, str], int] = {}
    dfa_accept: Set[int] = set()
    if start_set & nfa.accept_states:
        dfa_accept.add(0)

    while worklist:
        cur_set = worklist.pop(0)
        cur_id = state_map[cur_set]
        for sym in sorted(nfa.alphabet):
            move_targets: Set[int] = set()
            for s in cur_set:
                move_targets |= nfa.transitions.get((s, sym), set())
            if not move_targets:
                continue
            nxt_set = nfa.epsilon_closure(move_targets)
            if nxt_set not in state_map:
                nxt_id = len(state_map)
                state_map[nxt_set] = nxt_id
                worklist.append(nxt_set)
                if nxt_set & nfa.accept_states:
                    dfa_accept.add(nxt_id)
            dfa_trans[(cur_id, sym)] = state_map[nxt_set]

    return DFA(
        states=set(state_map.values()),
        alphabet=set(nfa.alphabet),
        transitions=dfa_trans,
        start_state=0,
        accept_states=dfa_accept,
    )


def minimize_dfa(dfa: DFA) -> DFA:
    """Minimize a DFA via partition refinement (Hopcroft/Moore equivalence classes)."""
    non_accept = dfa.states - dfa.accept_states
    partitions: List[Set[int]] = [p for p in (set(dfa.accept_states), non_accept) if p]
    if len(partitions) <= 1:
        return dfa

    while True:
        state_to_part = {s: idx for idx, part in enumerate(partitions) for s in part}
        new_parts: List[Set[int]] = []
        for part in partitions:
            buckets: Dict[Tuple[Tuple[str, int], ...], Set[int]] = {}
            for s in part:
                sig = tuple(
                    (sym, state_to_part.get(dfa.transitions[(s, sym)], -1))
                    for sym in sorted(dfa.alphabet)
                    if (s, sym) in dfa.transitions
                )
                buckets.setdefault(sig, set()).add(s)
            new_parts.extend(buckets.values())
        if len(new_parts) == len(partitions):
            break
        partitions = new_parts

    rep_map = {s: idx for idx, part in enumerate(partitions) for s in part}
    min_trans: Dict[Tuple[int, str], int] = {}
    for (s, sym), dst in dfa.transitions.items():
        min_trans[(rep_map[s], sym)] = rep_map[dst]
    return DFA(
        states=set(range(len(partitions))),
        alphabet=set(dfa.alphabet),
        transitions=min_trans,
        start_state=rep_map[dfa.start_state],
        accept_states={rep_map[s] for s in dfa.accept_states},
    )


def intersect_dfa(dfa1: DFA, dfa2: DFA) -> DFA:
    """Construct the product DFA accepting `L(dfa1) intersect L(dfa2)`."""
    alpha = dfa1.alphabet & dfa2.alphabet
    start_pair = (dfa1.start_state, dfa2.start_state)
    pair_map: Dict[Tuple[int, int], int] = {start_pair: 0}
    queue = [start_pair]
    trans: Dict[Tuple[int, str], int] = {}
    accepts: Set[int] = set()
    if start_pair[0] in dfa1.accept_states and start_pair[1] in dfa2.accept_states:
        accepts.add(0)

    while queue:
        s1, s2 = queue.pop(0)
        cid = pair_map[(s1, s2)]
        for sym in sorted(alpha):
            n1 = dfa1.transitions.get((s1, sym))
            n2 = dfa2.transitions.get((s2, sym))
            if n1 is not None and n2 is not None:
                np = (n1, n2)
                if np not in pair_map:
                    nid = len(pair_map)
                    pair_map[np] = nid
                    queue.append(np)
                    if n1 in dfa1.accept_states and n2 in dfa2.accept_states:
                        accepts.add(nid)
                trans[(cid, sym)] = pair_map[np]

    return DFA(
        states=set(pair_map.values()),
        alphabet=alpha,
        transitions=trans,
        start_state=0,
        accept_states=accepts,
    )


def _self_test() -> int:
    # Build NFA for protocol: "plan" -> ("read" | eps) -> "edit" -> "test"
    nfa = NFA(start_state=0, accept_states={3})
    nfa.add_transition(0, "plan", 1)
    nfa.add_transition(1, "read", 2)
    nfa.add_transition(1, "", 2)      # epsilon transition
    nfa.add_transition(2, "edit", 2)
    nfa.add_transition(2, "test", 3)

    dfa = minimize_dfa(subset_construct(nfa))
    ok1, _ = dfa.accepts(["plan", "read", "edit", "test"])
    ok2, _ = dfa.accepts(["plan", "edit", "edit", "test"])
    bad1, _ = dfa.accepts(["edit", "test"])
    assert ok1 and ok2 and not bad1

    print("automata._self_test: OK PASS (NFA epsilon-closure, subset construction, Hopcroft minimization)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
