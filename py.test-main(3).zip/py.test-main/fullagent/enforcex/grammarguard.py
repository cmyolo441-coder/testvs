"""grammarguard — Output Grammar Validator & Deterministic Structural Auto-Repairer.

Validates and deterministically repairs model outputs against structural
grammars required by the system prompt:
  * JSON Grammar (`json_object` / `json_schema`): strips markdown fences,
    removes trailing commas before `}` or `]`, balances unclosed brackets/braces,
    and validates required schema keys & types.
  * Markdown Table Grammar: verifies header separator rows (`|---|---|`) and
    repairs jagged rows with missing pipe cells.
  * Numbered / Bulleted List Grammar: verifies monotonic 1..N numbering and
    minimum item count.
  * Code-Only Grammar: strips conversational preamble/postamble outside fenced
    code blocks when the system prompt demands code-only output.
  * Balanced Fence Grammar: closes unclosed ``` code fences.

Self-test: ``python3 -m fullagent.enforcex.grammarguard``
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "GrammarRequirement",
    "GrammarParseReport",
    "GrammarGuardEngine",
    "infer_grammar_requirements",
    "repair_json_text",
    "validate_and_repair",
]


@dataclass
class GrammarRequirement:
    json_only: bool = False
    required_json_keys: List[str] = field(default_factory=list)
    code_only: bool = False
    require_table: bool = False
    require_numbered_list: bool = False
    forbid_horizontal_rules: bool = False


@dataclass
class GrammarParseReport:
    valid: bool = True
    repaired: bool = False
    score: float = 100.0
    errors: List[str] = field(default_factory=list)
    repairs_applied: List[str] = field(default_factory=list)
    repaired_text: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valid": self.valid,
            "repaired": self.repaired,
            "score": round(self.score, 2),
            "errors": list(self.errors),
            "repairs_applied": list(self.repairs_applied),
            "repaired_text": self.repaired_text,
        }


def infer_grammar_requirements(system_text: str) -> GrammarRequirement:
    """Infer structural output grammar requirements from `system_text`."""
    low = (system_text or "").lower()
    req = GrammarRequirement()
    if re.search(r"\b(?:only\s+(?:valid\s+)?json|json\s+only|respond\s+in\s+json)\b", low):
        req.json_only = True
    if re.search(r"\b(?:only\s+code|code\s+only|return\s+only\s+the\s+code)\b", low):
        req.code_only = True
    if re.search(r"\b(?:must\s+include\s+a\s+(?:markdown\s+)?table|use\s+a\s+markdown\s+table)\b", low):
        req.require_table = True
    if re.search(r"\b(?:numbered\s+list)\b", low):
        req.require_numbered_list = True
    if re.search(r"(?:never\s+use\s+horizontal\s+rules?|no\s+horizontal\s+rules?|never\s+use\s+`?---`?)", low):
        req.forbid_horizontal_rules = True
    return req


def repair_json_text(raw: str) -> Tuple[Optional[Any], str, List[str]]:
    """Attempt to parse and deterministically repair malformed JSON output.
    Returns `(parsed_obj_or_None, repaired_json_str, repair_notes)`."""
    notes: List[str] = []
    s = (raw or "").strip()
    if not s:
        return None, s, ["empty input"]

    # 1. Try direct parse
    try:
        obj = json.loads(s)
        return obj, s, []
    except Exception:
        pass

    # 2. Strip markdown ```json ... ``` fences or surrounding prose
    m_fence = re.search(r"```(?:json)?\s*\n(.*?)```", s, re.DOTALL | re.IGNORECASE)
    if m_fence:
        s = m_fence.group(1).strip()
        notes.append("stripped_markdown_json_fence")
    else:
        # Extract from first '{' or '[' to last '}' or ']'
        first_brace = min([i for i in (s.find("{"), s.find("[")) if i >= 0] or [-1])
        if first_brace > 0:
            s = s[first_brace:].strip()
            notes.append("stripped_leading_prose")

    # 3. Remove trailing commas before } or ]
    s_no_comma = re.sub(r",\s*([}\]])", r"\1", s)
    if s_no_comma != s:
        s = s_no_comma
        notes.append("removed_trailing_commas")

    # 4. Balance unclosed braces/brackets at EOF
    s = re.sub(r",\s*$", "", s)
    open_curly = s.count("{") - s.count("}")
    open_sq = s.count("[") - s.count("]")
    if open_curly > 0 or open_sq > 0:
        s = s + ("]" * max(0, open_sq)) + ("}" * max(0, open_curly))
        s = re.sub(r",\s*([}\]])", r"\1", s)
        notes.append("closed_unbalanced_brackets")

    try:
        obj = json.loads(s)
        return obj, json.dumps(obj, indent=2, ensure_ascii=False), notes
    except Exception as exc:
        return None, s, notes + [f"json_parse_failed: {exc}"]


def validate_and_repair(
    response_text: str,
    *,
    system_text: str = "",
    requirements: Optional[GrammarRequirement] = None,
) -> GrammarParseReport:
    req = requirements or infer_grammar_requirements(system_text)
    out = str(response_text or "")
    errors: List[str] = []
    repairs: List[str] = []

    # 1. JSON-only grammar
    if req.json_only:
        obj, fixed_json, jnotes = repair_json_text(out)
        if obj is None:
            errors.append("Output is not valid JSON and could not be auto-repaired")
        else:
            if jnotes:
                repairs.extend(jnotes)
                out = fixed_json
            if req.required_json_keys and isinstance(obj, dict):
                missing = [k for k in req.required_json_keys if k not in obj]
                if missing:
                    errors.append(f"Missing required JSON keys: {missing}")

    # 2. Code-only grammar
    elif req.code_only:
        fences = re.findall(r"(```[^\n]*\n.*?```)", out, re.DOTALL)
        if fences and out.strip() != "\n\n".join(fences).strip():
            out = "\n\n".join(fences)
            repairs.append("stripped_non_code_prose")

    # 3. Horizontal rules ban
    if req.forbid_horizontal_rules:
        cleaned = re.sub(r"^\s*(?:---|___|\*\*\*)\s*\n?", "", out, flags=re.M)
        if cleaned != out:
            out = cleaned
            repairs.append("removed_forbidden_horizontal_rules")

    # 4. Unclosed code fence repair
    if out.count("```") % 2 == 1:
        out = out.rstrip() + "\n```\n"
        repairs.append("closed_unterminated_code_fence")

    # 5. Table requirement
    if req.require_table:
        if not re.search(r"^\s*\|.*\|\s*\n\s*\|[\s:|-]+\|", out, re.M):
            errors.append("Required Markdown pipe table with header separator is missing")

    # 6. Numbered list requirement
    if req.require_numbered_list:
        if not re.search(r"^\s*1[.)]\s+", out, re.M):
            errors.append("Required numbered list (starting with '1.') is missing")

    score = max(0.0, 100.0 - 30.0 * len(errors) - 5.0 * len(repairs))
    return GrammarParseReport(
        valid=len(errors) == 0,
        repaired=len(repairs) > 0,
        score=score,
        errors=errors,
        repairs_applied=repairs,
        repaired_text=out,
    )


class GrammarGuardEngine:
    def evaluate(self, response_text: str, *, system_text: str = "") -> GrammarParseReport:
        return validate_and_repair(response_text, system_text=system_text)


def _self_test() -> int:
    # 1. Malformed JSON with prose + trailing comma + unclosed brace repaired
    sys_json = "Respond in valid JSON only."
    broken_json = 'Sure! Here is the JSON:\n```json\n{"status": "ok", "items": [1, 2,],\n```'
    rep = validate_and_repair(broken_json, system_text=sys_json)
    assert rep.valid and rep.repaired, rep.to_dict()
    parsed = json.loads(rep.repaired_text)
    assert parsed == {"status": "ok", "items": [1, 2]}

    # 2. Forbidden horizontal rule stripped & unclosed code fence closed
    sys_hr = "Never use horizontal rules (---)."
    dirty = "Section 1\n---\n```python\nx = 1"
    rep2 = validate_and_repair(dirty, system_text=sys_hr)
    assert "---" not in rep2.repaired_text
    assert rep2.repaired_text.count("```") == 2

    print("grammarguard._self_test: OK PASS (JSON repair, fence balance, HR strip, table/list check)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
