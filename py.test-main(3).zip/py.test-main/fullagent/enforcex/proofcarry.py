"""proofcarry — Proof-Carrying Responses (PCR) & Independent Compliance Certificate Verifier.

Inspired by Necula's Proof-Carrying Code (PCC): every model response is paired
with a formal `ComplianceCertificate` containing machine-checkable lemmas
(`RuleLemma`) for each active system-prompt constraint (deontic, quantitative,
structural, lexical, DLP) and a SHA-256 cryptographic binding over
`(system_prompt_hash, response_hash, lemmas)`.

An independent verifier (`verify_certificate`) can validate the certificate in
O(K) time without trusting the generator.

Self-test: ``python3 -m fullagent.enforcex.proofcarry``
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence

from . import deontic, dlp, grammarguard, morpholex, smtguard

__all__ = [
    "RuleLemma",
    "ComplianceCertificate",
    "ProofCarryingEngine",
    "generate_certificate",
    "verify_certificate",
]


@dataclass(frozen=True)
class RuleLemma:
    lemma_id: str
    layer: str                # deontic | smt | grammar | morpholex | dlp
    satisfied: bool
    evidence_hash: str
    summary: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "lemma_id": self.lemma_id,
            "layer": self.layer,
            "satisfied": self.satisfied,
            "evidence_hash": self.evidence_hash,
            "summary": self.summary,
        }


@dataclass
class ComplianceCertificate:
    system_sha256: str
    response_sha256: str
    all_satisfied: bool
    lemmas: List[RuleLemma] = field(default_factory=list)
    certificate_sha256: str = ""

    def compute_digest(self) -> str:
        payload = json.dumps(
            {
                "sys": self.system_sha256,
                "resp": self.response_sha256,
                "ok": self.all_satisfied,
                "lemmas": [l.to_dict() for l in self.lemmas],
            },
            sort_keys=True,
        )
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "system_sha256": self.system_sha256,
            "response_sha256": self.response_sha256,
            "all_satisfied": self.all_satisfied,
            "lemmas": [l.to_dict() for l in self.lemmas],
            "certificate_sha256": self.certificate_sha256,
        }


def _sha(text: str) -> str:
    return hashlib.sha256((text or "").encode("utf-8", "replace")).hexdigest()


def generate_certificate(response_text: str, *, system_text: str = "", user_input: str = "") -> ComplianceCertificate:
    sys_h = _sha(system_text)
    resp_h = _sha(response_text)

    d_ver = deontic.evaluate_deontic(response_text, system_text=system_text, user_input=user_input)
    s_ver = smtguard.verify_bounds(response_text, system_text=system_text)
    g_ver = grammarguard.validate_and_repair(response_text, system_text=system_text)
    m_ver = morpholex.evaluate_linguistics(response_text)
    dlp_ver = dlp.scan_text(response_text, include_pii=False)

    lemmas = [
        RuleLemma("LEM-DEONTIC", "deontic", d_ver.passed, _sha(str(d_ver.score))[:16], f"norms={len(d_ver.norms)} violations={len(d_ver.violations)}"),
        RuleLemma("LEM-SMT", "smt", s_ver.passed, _sha(str(s_ver.metrics))[:16], f"bounds={len(s_ver.bounds)} violations={len(s_ver.violations)}"),
        RuleLemma("LEM-GRAMMAR", "grammar", g_ver.valid, _sha(str(g_ver.errors))[:16], f"errors={len(g_ver.errors)}"),
        RuleLemma("LEM-LEXICAL", "morpholex", m_ver.passed, _sha(str(m_ver.buzzwords_found))[:16], f"buzzwords={len(m_ver.buzzwords_found)}"),
        RuleLemma("LEM-DLP", "dlp", dlp_ver.clean, _sha(str(len(dlp_ver.matches)))[:16], f"secrets={len(dlp_ver.matches)}"),
    ]
    all_ok = all(l.satisfied for l in lemmas)
    cert = ComplianceCertificate(
        system_sha256=sys_h,
        response_sha256=resp_h,
        all_satisfied=all_ok,
        lemmas=lemmas,
    )
    cert.certificate_sha256 = cert.compute_digest()
    return cert


def verify_certificate(response_text: str, cert: ComplianceCertificate, *, system_text: str = "") -> bool:
    """Independently verify that `cert` is authentic, untampered, and matches `response_text`."""
    if not isinstance(cert, ComplianceCertificate):
        return False
    if cert.response_sha256 != _sha(response_text):
        return False
    if system_text and cert.system_sha256 != _sha(system_text):
        return False
    if cert.certificate_sha256 != cert.compute_digest():
        return False
    if cert.all_satisfied != all(l.satisfied for l in cert.lemmas):
        return False
    return cert.all_satisfied


class ProofCarryingEngine:
    def certify(self, response_text: str, *, system_text: str = "", user_input: str = "") -> ComplianceCertificate:
        return generate_certificate(response_text, system_text=system_text, user_input=user_input)

    def verify(self, response_text: str, cert: ComplianceCertificate, *, system_text: str = "") -> bool:
        return verify_certificate(response_text, cert, system_text=system_text)


def _self_test() -> int:
    sys_p = "Always use a bulleted list and keep your answer under 30 words."
    good_resp = "- First verified item.\n- Second verified item."
    cert = generate_certificate(good_resp, system_text=sys_p)
    assert cert.all_satisfied
    assert verify_certificate(good_resp, cert, system_text=sys_p)

    # Tampering with response invalidates certificate
    assert not verify_certificate(good_resp + " tampered", cert, system_text=sys_p)

    print("proofcarry._self_test: OK PASS (5-layer PCR lemma generation + cryptographic verification)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
