"""petrinet — Place/Transition Petri Net Workflow & Concurrency Safety Verifier.

Models concurrent agent & tool workflows as a Petri Net $N = (P, T, Pre, Post, M_0)$
and explores the reachability graph via breadth-first search to verify:
  * Deadlock Freedom: whether any non-terminal reachable marking has zero
    enabled transitions.
  * k-Boundedness: whether any place ever accumulates more than $k$ tokens
    (resource leak / unbounded queue).
  * Mutual Exclusion: whether two critical-section places are ever simultaneously
    marked (`M[p1] > 0 and M[p2] > 0`).

Self-test: ``python3 -m fullagent.enforcex.petrinet``
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Optional, Sequence, Set, Tuple

__all__ = [
    "Transition",
    "PetriReachabilityReport",
    "PetriNetVerifier",
]

Marking = Tuple[Tuple[str, int], ...]


@dataclass(frozen=True)
class Transition:
    name: str
    pre: Dict[str, int]
    post: Dict[str, int]


@dataclass
class PetriReachabilityReport:
    reachable_states: int = 0
    deadlock_free: bool = True
    bounded: bool = True
    mutex_safe: bool = True
    max_tokens_seen: int = 0
    deadlock_markings: List[Dict[str, int]] = field(default_factory=list)
    mutex_violations: List[Dict[str, int]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reachable_states": self.reachable_states,
            "deadlock_free": self.deadlock_free,
            "bounded": self.bounded,
            "mutex_safe": self.mutex_safe,
            "max_tokens_seen": self.max_tokens_seen,
            "deadlock_markings": list(self.deadlock_markings),
            "mutex_violations": list(self.mutex_violations),
        }


class PetriNetVerifier:
    def __init__(self, initial_marking: Dict[str, int]) -> None:
        self.initial: Dict[str, int] = {k: int(v) for k, v in initial_marking.items() if int(v) > 0}
        self.transitions: List[Transition] = []

    def add_transition(self, name: str, pre: Dict[str, int], post: Dict[str, int]) -> None:
        self.transitions.append(Transition(name=name, pre=dict(pre), post=dict(post)))

    @staticmethod
    def _freeze(m: Dict[str, int]) -> Marking:
        return tuple(sorted((k, v) for k, v in m.items() if v > 0))

    @staticmethod
    def _enabled(m: Dict[str, int], t: Transition) -> bool:
        return all(m.get(p, 0) >= w for p, w in t.pre.items())

    @staticmethod
    def _fire(m: Dict[str, int], t: Transition) -> Dict[str, int]:
        nxt = dict(m)
        for p, w in t.pre.items():
            nxt[p] = nxt.get(p, 0) - w
            if nxt[p] <= 0:
                nxt.pop(p, None)
        for p, w in t.post.items():
            nxt[p] = nxt.get(p, 0) + w
        return nxt

    def verify(
        self,
        *,
        terminal_places: Sequence[str] = ("done",),
        mutex_pairs: Sequence[Tuple[str, str]] = (),
        bound_k: int = 10,
        max_states: int = 500,
    ) -> PetriReachabilityReport:
        start_f = self._freeze(self.initial)
        visited: Set[Marking] = {start_f}
        queue: deque[Dict[str, int]] = deque([dict(self.initial)])
        deadlocks: List[Dict[str, int]] = []
        mutex_viols: List[Dict[str, int]] = []
        max_tok = max(self.initial.values(), default=0)
        term_set = set(terminal_places)

        while queue and len(visited) <= max_states:
            cur = queue.popleft()
            for v in cur.values():
                if v > max_tok:
                    max_tok = v

            for p1, p2 in mutex_pairs:
                if cur.get(p1, 0) > 0 and cur.get(p2, 0) > 0:
                    mutex_viols.append(dict(cur))

            enabled_ts = [t for t in self.transitions if self._enabled(cur, t)]
            if not enabled_ts:
                if not any(cur.get(tp, 0) > 0 for tp in term_set):
                    deadlocks.append(dict(cur))
                continue

            for t in enabled_ts:
                nxt = self._fire(cur, t)
                if any(v > bound_k for v in nxt.values()):
                    max_tok = max(max_tok, max(nxt.values()))
                    continue
                nf = self._freeze(nxt)
                if nf not in visited:
                    visited.add(nf)
                    queue.append(nxt)

        return PetriReachabilityReport(
            reachable_states=len(visited),
            deadlock_free=(len(deadlocks) == 0),
            bounded=(max_tok <= bound_k),
            mutex_safe=(len(mutex_viols) == 0),
            max_tokens_seen=max_tok,
            deadlock_markings=deadlocks,
            mutex_violations=mutex_viols,
        )


def _self_test() -> int:
    # Two workers sharing 1 lock mutex -> verify mutual exclusion & deadlock freedom
    net = PetriNetVerifier({"w1_idle": 1, "w2_idle": 1, "lock": 1})
    net.add_transition("w1_acquire", {"w1_idle": 1, "lock": 1}, {"w1_crit": 1})
    net.add_transition("w1_release", {"w1_crit": 1}, {"w1_done": 1, "lock": 1})
    net.add_transition("w2_acquire", {"w2_idle": 1, "lock": 1}, {"w2_crit": 1})
    net.add_transition("w2_release", {"w2_crit": 1}, {"w2_done": 1, "lock": 1})
    net.add_transition("join", {"w1_done": 1, "w2_done": 1}, {"done": 1})

    rep = net.verify(terminal_places=("done",), mutex_pairs=[("w1_crit", "w2_crit")])
    assert rep.deadlock_free and rep.mutex_safe and rep.bounded, rep.to_dict()

    print("petrinet._self_test: OK PASS (reachability BFS, mutex verification, deadlock freedom)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
