"""epistemic — Multi-Agent Epistemic Logic (S5_n), Common Knowledge & Information Leak Prover.

Models epistemic accessibility relations `~_a` over possible worlds `W` for
agents `a in {system, assistant, user, untrusted_tool}` (Fagin, Halpern, Moses
& Vardi, "Reasoning About Knowledge"):
  * `K_a(phi)`: agent `a` knows `phi` in world `w` iff `phi` holds in all
    worlds `w'` epistemically indistinguishable to `a` (`(w, w') in ~_a`).
  * `M_a(phi)`: agent `a` considers `phi` possible (`~K_a(~phi)`).
  * `E_G(phi)`: everyone in group `G` knows `phi` (`/\_{a in G} K_a(phi)`).
  * `C_G(phi)`: `phi` is Common Knowledge among group `G` (holds across the
    reflexive-transitive closure `(U_{a in G} ~_a)*`).
  * Epistemic Non-Disclosure Invariant: verifies that private system secrets
    satisfy `~K_user(secret)` and `~M_untrusted_tool(canary_token)` after an
    assistant message is observed (Public Announcement Logic `[!msg]`).

Self-test: ``python3 -m fullagent.enforcex.epistemic``
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "EpistemicWorld",
    "EpistemicKripkeModel",
    "EpistemicLeakReport",
    "EpistemicReasoner",
]


@dataclass(frozen=True)
class EpistemicWorld:
    world_id: str
    facts: FrozenSet[str]
    observables: Dict[str, Any] = field(default_factory=dict)


class EpistemicKripkeModel:
    """Multi-agent S5 epistemic Kripke frame `(W, {~_a}, V)`."""

    def __init__(self) -> None:
        self.worlds: Dict[str, Set[str]] = {}
        self.equiv: Dict[str, Dict[str, Set[str]]] = {}

    def add_world(self, world_id: str, facts: Iterable[str] = ()) -> None:
        w = str(world_id)
        self.worlds[w] = {str(f) for f in facts}
        for agent_rel in self.equiv.values():
            agent_rel.setdefault(w, {w})

    def add_indistinguishable(self, agent: str, w1: str, w2: str) -> None:
        """Mark `w1 ~_agent w2` and close under reflexivity, symmetry, and transitivity (S5)."""
        a = str(agent)
        u, v = str(w1), str(w2)
        if u not in self.worlds:
            self.add_world(u)
        if v not in self.worlds:
            self.add_world(v)
        rel = self.equiv.setdefault(a, {w: {w} for w in self.worlds})
        for w in self.worlds:
            rel.setdefault(w, {w})
        # Merge equivalence classes of u and v
        merged = set(rel[u]) | set(rel[v])
        for m in merged:
            rel[m] = set(merged)

    def accessible(self, agent: str, world_id: str) -> Set[str]:
        a = str(agent)
        w = str(world_id)
        if a not in self.equiv:
            return {w} if w in self.worlds else set()
        return set(self.equiv[a].get(w, {w}))

    def knows_atom(self, agent: str, world_id: str, prop: str) -> bool:
        """Evaluate `M, w |= K_agent(prop)`."""
        eq_class = self.accessible(agent, world_id)
        if not eq_class:
            return False
        return all(prop in self.worlds.get(w, set()) for w in eq_class)

    def considers_possible(self, agent: str, world_id: str, prop: str) -> bool:
        """Evaluate `M, w |= M_agent(prop)` (dual of `K_agent`)."""
        eq_class = self.accessible(agent, world_id)
        return any(prop in self.worlds.get(w, set()) for w in eq_class)

    def everyone_knows(self, group: Sequence[str], world_id: str, prop: str) -> bool:
        """Evaluate `M, w |= E_group(prop)`."""
        return all(self.knows_atom(a, world_id, prop) for a in group)

    def common_knowledge(self, group: Sequence[str], world_id: str, prop: str) -> bool:
        """Evaluate `M, w |= C_group(prop)` via BFS over `U_{a in group} ~_a`."""
        start = str(world_id)
        if start not in self.worlds:
            return False
        visited: Set[str] = {start}
        q: deque[str] = deque([start])
        while q:
            curr = q.popleft()
            if prop not in self.worlds.get(curr, set()):
                return False
            for a in group:
                for nxt in self.accessible(a, curr):
                    if nxt not in visited:
                        visited.add(nxt)
                        q.append(nxt)
        return True

    def public_announcement(self, surviving_worlds: Set[str]) -> "EpistemicKripkeModel":
        """Plaza's Public Announcement Logic `[!phi]`: restrict model to `surviving_worlds`."""
        sub = EpistemicKripkeModel()
        for w in surviving_worlds:
            if w in self.worlds:
                sub.add_world(w, self.worlds[w])
        for a, rel in self.equiv.items():
            sub.equiv[a] = {}
            for w in sub.worlds:
                sub.equiv[a][w] = set(rel.get(w, {w})) & set(sub.worlds.keys())
        return sub


@dataclass
class EpistemicLeakReport:
    safe: bool
    leaked_secrets: List[str] = field(default_factory=list)
    user_certainty_ratio: float = 0.0
    common_knowledge_rules: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "safe": self.safe,
            "leaked_secrets": list(self.leaked_secrets),
            "user_certainty_ratio": round(self.user_certainty_ratio, 4),
            "common_knowledge_rules": list(self.common_knowledge_rules),
        }


class EpistemicReasoner:
    """Verifies epistemic opacity of system secrets and common knowledge of public rules."""

    def audit_announcement(
        self,
        response_text: str,
        *,
        secret_tokens: Sequence[str] = (),
        public_rules: Sequence[str] = (),
    ) -> EpistemicLeakReport:
        txt_low = (response_text or "").lower()
        leaked = [s for s in secret_tokens if s and s.lower() in txt_low]
        # Build a 2-world epistemic model (w_real where secret holds, w_alt where secret does not hold)
        model = EpistemicKripkeModel()
        model.add_world("w_real", list(secret_tokens) + list(public_rules))
        model.add_world("w_alt", list(public_rules))
        # Before announcement, user cannot distinguish w_real from w_alt
        model.add_indistinguishable("user", "w_real", "w_alt")
        # System knows the real world
        model.add_indistinguishable("system", "w_real", "w_real")

        # If a secret leaks in response_text, w_alt is eliminated by public announcement!
        surviving = {"w_real"} if leaked else {"w_real", "w_alt"}
        post = model.public_announcement(surviving)

        leaked_knowledge = [s for s in secret_tokens if post.knows_atom("user", "w_real", s)]
        ck_rules = [r for r in public_rules if post.common_knowledge(["system", "user"], "w_real", r)]
        cert_ratio = 1.0 if len(surviving) == 1 else 0.5
        return EpistemicLeakReport(
            safe=(len(leaked_knowledge) == 0),
            leaked_secrets=leaked_knowledge,
            user_certainty_ratio=cert_ratio,
            common_knowledge_rules=ck_rules,
        )


def _self_test() -> int:
    r = EpistemicReasoner()
    # 1. Clean response preserves epistemic ignorance of secret_key (~K_user(secret_key))
    rep_ok = r.audit_announcement(
        "Here is your JSON summary.",
        secret_tokens=["CANARY-9921"],
        public_rules=["json_format"],
    )
    assert rep_ok.safe and not rep_ok.leaked_secrets
    assert "json_format" in rep_ok.common_knowledge_rules

    # 2. Leaking secret eliminates alternative worlds so K_user(CANARY-9921) becomes True!
    rep_bad = r.audit_announcement(
        "Internal token is CANARY-9921.",
        secret_tokens=["CANARY-9921"],
        public_rules=["json_format"],
    )
    assert not rep_bad.safe and "CANARY-9921" in rep_bad.leaked_secrets

    print("epistemic._self_test: OK PASS (S5 equivalence closure, K_a, E_G, C_G, Plaza [!phi] announcement)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
