"""paraconsistent — Belnap 4-Valued Logic (FOUR) & Dunn-Belnap Bilattice Reasoner.

When an agent ingests conflicting evidence from multiple sources (e.g. a system
prompt, a stale RAG document, and a user message), classical logic suffers from
the Principle of Explosion (`p /\\ ~p |- q`).

Implements Nuel Belnap's four-valued paraconsistent logic `FOUR = {T, F, B, N}`:
  * `N` (Neither / Unknown):   `{}`          — no evidence for or against
  * `T` (True only):           `{1}`         — positive evidence only
  * `F` (False only):          `{0}`         — negative evidence only
  * `B` (Both / Contradictory):`{0, 1}`      — conflicting positive & negative evidence

Equipped with two orthogonal lattice orderings (Ginsberg Bilattice):
  1. **Truth Ordering (`<=_t`)**: `F <=_t N <=_t T` and `F <=_t B <=_t T`
     (operations: `t_meet` `/\\`, `t_join` `\\/`, negation `~T=F, ~F=T, ~B=B, ~N=N`).
  2. **Knowledge / Information Ordering (`<=_k`)**: `N <=_k T <=_k B` and `N <=_k F <=_k B`
     (operations: `k_meet` consensus `(x @ y)`, `k_join` gullibility `(x + y)`).

Self-test: ``python3 -m fullagent.enforcex.paraconsistent``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Sequence, Set, Tuple

__all__ = [
    "BelnapValue",
    "BilatticeState",
    "ParaconsistentReasoner",
    "N",
    "F",
    "T",
    "B",
]


@dataclass(frozen=True)
class BelnapValue:
    """Element of Belnap's 4-valued bilattice represented by `(pos: bool, neg: bool)`."""
    pos: bool
    neg: bool

    @property
    def symbol(self) -> str:
        if self.pos and self.neg:
            return "B"  # Both (inconsistent / conflicting)
        if self.pos:
            return "T"  # True
        if self.neg:
            return "F"  # False
        return "N"      # Neither (unknown)

    def __invert__(self) -> "BelnapValue":
        """De Morgan negation swap `(pos, neg) -> (neg, pos)`; preserves `B` and `N`."""
        return BelnapValue(self.neg, self.pos)

    def t_meet(self, other: "BelnapValue") -> "BelnapValue":
        """Truth-lattice conjunction `x /\\_t y`: positive iff both positive; negative iff either negative."""
        return BelnapValue(self.pos and other.pos, self.neg or other.neg)

    def t_join(self, other: "BelnapValue") -> "BelnapValue":
        """Truth-lattice disjunction `x \\/_t y`: positive iff either positive; negative iff both negative."""
        return BelnapValue(self.pos or other.pos, self.neg and other.neg)

    def k_meet(self, other: "BelnapValue") -> "BelnapValue":
        """Knowledge-lattice consensus `x *_k y`: retains only agreed evidence."""
        return BelnapValue(self.pos and other.pos, self.neg and other.neg)

    def k_join(self, other: "BelnapValue") -> "BelnapValue":
        """Knowledge-lattice gullibility/fusion `x +_k y`: pools all positive and negative evidence."""
        return BelnapValue(self.pos or other.pos, self.neg or other.neg)

    def designated(self) -> bool:
        """In Priest's LP / Belnap designated values `{T, B}`, positive evidence is present."""
        return self.pos

    def classical_true(self) -> bool:
        """Strictly true without contradiction (`T` only)."""
        return self.pos and not self.neg


N = BelnapValue(False, False)
F = BelnapValue(False, True)
T = BelnapValue(True, False)
B = BelnapValue(True, True)


@dataclass
class BilatticeState:
    valuations: Dict[str, str] = field(default_factory=dict)
    contradictory_atoms: List[str] = field(default_factory=list)
    unknown_atoms: List[str] = field(default_factory=list)
    consistent_true: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "valuations": dict(self.valuations),
            "contradictory_atoms": list(self.contradictory_atoms),
            "unknown_atoms": list(self.unknown_atoms),
            "consistent_true": list(self.consistent_true),
        }


class ParaconsistentReasoner:
    """Fuses multi-source evidence in `FOUR` without explosion on conflicting atoms."""

    def __init__(self) -> None:
        self.env: Dict[str, BelnapValue] = {}

    def observe(self, atom: str, value: BelnapValue) -> BelnapValue:
        cur = self.env.get(atom, N)
        fused = cur.k_join(value)
        self.env[atom] = fused
        return fused

    def value_of(self, atom: str) -> BelnapValue:
        return self.env.get(atom, N)

    def summarize(self) -> BilatticeState:
        vals = {k: v.symbol for k, v in sorted(self.env.items())}
        both = [k for k, v in sorted(self.env.items()) if v == B]
        neither = [k for k, v in sorted(self.env.items()) if v == N]
        strict_t = [k for k, v in sorted(self.env.items()) if v == T]
        return BilatticeState(
            valuations=vals,
            contradictory_atoms=both,
            unknown_atoms=neither,
            consistent_true=strict_t,
        )


def _self_test() -> int:
    # 1. Verify Bilattice identities: ~B == B, ~N == N, F /\_t T == F, F +_k T == B, B *_k T == T
    assert (~B) == B and (~N) == N and (~T) == F and (~F) == T
    assert F.t_meet(T) == F and F.t_join(T) == T
    assert N.t_meet(B) == F and N.t_join(B) == T
    assert F.k_join(T) == B and B.k_meet(T) == T

    # 2. Verify non-explosion: contradictory atom `B` does not make unrelated atom `q` true
    pr = ParaconsistentReasoner()
    pr.observe("allow_markdown", T)
    pr.observe("allow_markdown", F)  # conflicting source -> B
    pr.observe("json_valid", T)
    state = pr.summarize()
    assert state.valuations["allow_markdown"] == "B"
    assert "allow_markdown" in state.contradictory_atoms
    assert state.valuations["json_valid"] == "T"
    assert pr.value_of("unrelated_claim") == N

    print("paraconsistent._self_test: OK PASS (Belnap FOUR truth/knowledge bilattices, non-explosion verified)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
