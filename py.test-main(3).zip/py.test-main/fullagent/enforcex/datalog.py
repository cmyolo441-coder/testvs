"""datalog — Stratified Datalog Deductive Rule Engine (Bottom-Up Fixpoint Evaluator).

Evaluates declarative Horn clauses with stratified negation over relational
security and compliance facts:
  * Facts (EDB): `("calls", "turn1", "read_file", ".env")`
  * Rules (IDB): `Head :- PosAtom1, PosAtom2, ~NegAtom1`
  * Variables are strings starting with uppercase (`"?X"` or `"X"`), constants
    start with lowercase or literals.

Computes the exact least fixpoint model and supports relational queries.

Self-test: ``python3 -m fullagent.enforcex.datalog``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "Atom",
    "DatalogRule",
    "StratifiedDatalogEngine",
]

Fact = Tuple[str, ...]


@dataclass(frozen=True)
class Atom:
    pred: str
    terms: Tuple[str, ...]
    negated: bool = False


@dataclass(frozen=True)
class DatalogRule:
    head: Atom
    body: Tuple[Atom, ...]
    stratum: int = 0


def _is_var(term: str) -> bool:
    return bool(term) and (term.startswith("?") or term[0].isupper())


def _match_atom(atom: Atom, fact: Fact, subst: Dict[str, str]) -> Optional[Dict[str, str]]:
    if atom.pred != fact[0] or len(atom.terms) != len(fact) - 1:
        return None
    new_s = dict(subst)
    for t, val in zip(atom.terms, fact[1:]):
        if _is_var(t):
            if t in new_s and new_s[t] != val:
                return None
            new_s[t] = val
        elif t != val:
            return None
    return new_s


def _instantiate(atom: Atom, subst: Dict[str, str]) -> Fact:
    return (atom.pred,) + tuple(subst.get(t, t) for t in atom.terms)


class StratifiedDatalogEngine:
    """Bottom-up fixpoint evaluator for stratified Datalog programs."""

    def __init__(self) -> None:
        self.facts: Set[Fact] = set()
        self.rules: List[DatalogRule] = []

    def add_fact(self, pred: str, *args: str) -> None:
        self.facts.add((str(pred),) + tuple(str(a) for a in args))

    def add_rule(self, head: Atom, body: Sequence[Atom], *, stratum: int = 0) -> None:
        self.rules.append(DatalogRule(head=head, body=tuple(body), stratum=int(stratum)))

    def materialize(self) -> Set[Fact]:
        """Evaluate all strata to fixpoint and return the full materialized fact set."""
        strata = sorted({r.stratum for r in self.rules})
        db = set(self.facts)

        for st in strata:
            st_rules = [r for r in self.rules if r.stratum == st]
            while True:
                added = False
                for rule in st_rules:
                    pos_atoms = [a for a in rule.body if not a.negated]
                    neg_atoms = [a for a in rule.body if a.negated]

                    subst_list: List[Dict[str, str]] = [{}]
                    for pa in pos_atoms:
                        next_substs: List[Dict[str, str]] = []
                        for sub in subst_list:
                            for f in db:
                                m = _match_atom(pa, f, sub)
                                if m is not None:
                                    next_substs.append(m)
                        subst_list = next_substs
                        if not subst_list:
                            break

                    for sub in subst_list:
                        # Check negated atoms
                        neg_holds = False
                        for na in neg_atoms:
                            if any(_match_atom(na, f, sub) is not None for f in db):
                                neg_holds = True
                                break
                        if not neg_holds:
                            derived = _instantiate(rule.head, sub)
                            if derived not in db:
                                db.add(derived)
                                added = True
                if not added:
                    break

        self.facts = db
        return db

    def query(self, pred: str, *pattern: str) -> List[Tuple[str, ...]]:
        self.materialize()
        q_atom = Atom(pred, tuple(pattern))
        out: List[Tuple[str, ...]] = []
        for f in sorted(self.facts):
            if _match_atom(q_atom, f, {}) is not None:
                out.append(f[1:])
        return out


def _self_test() -> int:
    eng = StratifiedDatalogEngine()
    # Taint propagation + negation rule:
    # tainted_session(S) :- read_secret(S, F)
    # exfil_violation(S, U) :- tainted_session(S), net_post(S, U), ~sanitized(S)
    eng.add_fact("read_secret", "sess_1", ".env")
    eng.add_fact("net_post", "sess_1", "https://evil.example")
    eng.add_fact("read_secret", "sess_2", ".env")
    eng.add_fact("sanitized", "sess_2")
    eng.add_fact("net_post", "sess_2", "https://api.internal")

    eng.add_rule(
        Atom("tainted_session", ("?S",)),
        [Atom("read_secret", ("?S", "?F"))],
        stratum=0,
    )
    eng.add_rule(
        Atom("exfil_violation", ("?S", "?U")),
        [
            Atom("tainted_session", ("?S",)),
            Atom("net_post", ("?S", "?U")),
            Atom("sanitized", ("?S",), negated=True),
        ],
        stratum=1,
    )

    hits = eng.query("exfil_violation", "?S", "?U")
    assert hits == [("sess_1", "https://evil.example")], hits

    print("datalog._self_test: OK PASS (stratified semi-naive fixpoint, unification, negation)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
