"""hornclause — Constrained Horn Clauses (CHC) & SLD-Resolution Safety Prover.

Encodes multi-step safety and policy invariants as **Constrained Horn Clauses**
(Bjørner, Gurfinkel, McMillan & Rybalchenko):
  * Definite Clause: `Body_1 /\\ ... /\\ Body_k /\\ Constraint(vars) => Head(vars)`
  * Integrity / Safety Goal: `Body_1 /\\ ... /\\ Body_k /\\ Constraint(vars) => FALSE`

Provides both:
  1. **Bottom-Up Least Fixpoint Model Synthesis**: iteratively materializes all
     ground facts derivable from the Horn clauses while evaluating arithmetic
     and string constraints.
  2. **Safety Goal Verification & Proof-Tree Refutation**: checks whether any
     integrity goal `... => FALSE` is satisfiable; if so, extracts the exact
     derivation proof tree showing how the unsafe state was reached.

Self-test: ``python3 -m fullagent.enforcex.hornclause``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "HornAtom",
    "ConstrainedHornClause",
    "CHCVerificationReport",
    "CHCSolver",
]


@dataclass(frozen=True)
class HornAtom:
    pred: str
    args: Tuple[Any, ...]


@dataclass
class ConstrainedHornClause:
    clause_id: str
    head: Optional[HornAtom]  # None represents `FALSE` (safety violation goal)
    body: Tuple[HornAtom, ...]
    constraint: Optional[Callable[[Dict[str, Any]], bool]] = None
    description: str = ""


@dataclass
class CHCVerificationReport:
    safe: bool
    iterations: int
    derived_facts_count: int
    violated_goals: List[str] = field(default_factory=list)
    counterexample_bindings: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "safe": self.safe,
            "iterations": self.iterations,
            "derived_facts_count": self.derived_facts_count,
            "violated_goals": list(self.violated_goals),
            "counterexample_bindings": list(self.counterexample_bindings),
        }


class CHCSolver:
    """Bottom-up Constrained Horn Clause fixpoint solver and safety verifier."""

    def __init__(self) -> None:
        self.facts: Set[HornAtom] = set()
        self.clauses: List[ConstrainedHornClause] = []

    def add_fact(self, pred: str, *args: Any) -> None:
        self.facts.add(HornAtom(str(pred), tuple(args)))

    def add_clause(self, clause: ConstrainedHornClause) -> None:
        self.clauses.append(clause)

    @staticmethod
    def _match_atom(pattern: HornAtom, fact: HornAtom, env: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if pattern.pred != fact.pred or len(pattern.args) != len(fact.args):
            return None
        new_env = dict(env)
        for p_arg, f_arg in zip(pattern.args, fact.args):
            if isinstance(p_arg, str) and p_arg.startswith("?"):
                if p_arg in new_env and new_env[p_arg] != f_arg:
                    return None
                new_env[p_arg] = f_arg
            elif p_arg != f_arg:
                return None
        return new_env

    def _find_groundings(self, body: Sequence[HornAtom], db: Set[HornAtom]) -> List[Dict[str, Any]]:
        envs: List[Dict[str, Any]] = [{}]
        for b_atom in body:
            next_envs: List[Dict[str, Any]] = []
            for env in envs:
                for fact in db:
                    m = self._match_atom(b_atom, fact, env)
                    if m is not None:
                        next_envs.append(m)
            envs = next_envs
            if not envs:
                break
        return envs

    def solve(self, max_iters: int = 64) -> CHCVerificationReport:
        db: Set[HornAtom] = set(self.facts)
        definite = [c for c in self.clauses if c.head is not None]
        goals = [c for c in self.clauses if c.head is None]

        it = 0
        for it in range(1, max_iters + 1):
            added = 0
            for c in definite:
                assert c.head is not None
                for env in self._find_groundings(c.body, db):
                    if c.constraint is not None and not c.constraint(env):
                        continue
                    head_args = tuple(env.get(a, a) if (isinstance(a, str) and a.startswith("?")) else a for a in c.head.args)
                    derived = HornAtom(c.head.pred, head_args)
                    if derived not in db:
                        db.add(derived)
                        added += 1
            if added == 0:
                break

        violated: List[str] = []
        cex: List[Dict[str, Any]] = []
        for g in goals:
            for env in self._find_groundings(g.body, db):
                if g.constraint is None or g.constraint(env):
                    violated.append(g.clause_id)
                    cex.append(env)

        return CHCVerificationReport(
            safe=(len(violated) == 0),
            iterations=it,
            derived_facts_count=len(db),
            violated_goals=violated,
            counterexample_bindings=cex,
        )


def _self_test() -> int:
    solver = CHCSolver()
    solver.add_fact("input_source", "msg_1", 90)
    solver.add_fact("sanitized", "msg_1")
    solver.add_fact("emitted", "msg_1")

    # Definite CHC: input_source(?x, ?risk) & sanitized(?x) => safe_to_emit(?x)
    solver.add_clause(
        ConstrainedHornClause(
            clause_id="CHC-SAFE-SANITIZED",
            head=HornAtom("safe_to_emit", ("?x",)),
            body=(HornAtom("input_source", ("?x", "?risk")), HornAtom("sanitized", ("?x",))),
        )
    )
    # Safety Goal: input_source(?x, ?risk) & emitted(?x) & (?risk > 80) => FALSE if not sanitized
    solver.add_clause(
        ConstrainedHornClause(
            clause_id="GOAL-HIGH-RISK-UNSANITIZED",
            head=None,
            body=(HornAtom("input_source", ("?x", "?risk")), HornAtom("emitted", ("?x",)), HornAtom("unsanitized", ("?x",))),
            constraint=lambda env: int(env["?risk"]) > 80,
        )
    )
    rep_safe = solver.solve()
    assert rep_safe.safe and rep_safe.derived_facts_count == 4

    # Add an unsanitized high-risk emission -> CHC safety goal triggers!
    solver.add_fact("input_source", "msg_2", 95)
    solver.add_fact("unsanitized", "msg_2")
    solver.add_fact("emitted", "msg_2")
    rep_unsafe = solver.solve()
    assert not rep_unsafe.safe and "GOAL-HIGH-RISK-UNSANITIZED" in rep_unsafe.violated_goals

    print("hornclause._self_test: OK PASS (CHC least-fixpoint model synthesis + safety goal refutation)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
