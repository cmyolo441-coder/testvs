"""vectorvault — Pure-Python Okapi BM25+ & 64-Bit SimHash LSH Rule Retrieval Engine.

Indexes system prompt rules and compliance precedents for fast, dependency-free
retrieval:
  * Okapi BM25+ ($k_1 = 1.5, b = 0.75, \delta = 1.0$) lexical relevance scoring
  * 64-bit Charikar SimHash fingerprint with exact Hamming distance & near-duplicate
    detection (`hamming_distance <= 3`)
  * Maximal Marginal Relevance (MMR) reranking to return relevant yet diverse rules.

Self-test: ``python3 -m fullagent.enforcex.vectorvault``
"""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence, Tuple

__all__ = [
    "IndexedRule",
    "RuleRetrievalResult",
    "VectorRuleVault",
    "simhash_64",
    "hamming_distance_64",
]


def _tokenize(text: str) -> List[str]:
    return [w for w in re.findall(r"[a-z0-9_]+", (text or "").lower()) if len(w) >= 2]


def simhash_64(text: str) -> int:
    """Compute a 64-bit Charikar SimHash fingerprint over word tokens and 2-shingles."""
    tokens = _tokenize(text)
    if not tokens:
        return 0
    shingles = list(tokens) + [f"{tokens[i]}_{tokens[i+1]}" for i in range(len(tokens) - 1)]
    weights = [0] * 64
    for sh in shingles:
        digest = hashlib.md5(sh.encode("utf-8")).digest()
        h64 = int.from_bytes(digest[:8], "big")
        for bit in range(64):
            if (h64 >> bit) & 1:
                weights[bit] += 1
            else:
                weights[bit] -= 1
    out = 0
    for bit in range(64):
        if weights[bit] > 0:
            out |= (1 << bit)
    return out


def hamming_distance_64(a: int, b: int) -> int:
    return bin((a ^ b) & ((1 << 64) - 1)).count("1")


@dataclass
class IndexedRule:
    rule_id: str
    text: str
    tokens: List[str]
    tf: Dict[str, int]
    simhash: int


@dataclass
class RuleRetrievalResult:
    rule_id: str
    text: str
    bm25_score: float
    simhash_distance: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "text": self.text,
            "bm25_score": round(self.bm25_score, 4),
            "simhash_distance": self.simhash_distance,
        }


class VectorRuleVault:
    """BM25+ and 64-bit SimHash rule index."""

    def __init__(self, *, k1: float = 1.5, b: float = 0.75, delta: float = 1.0) -> None:
        self.k1 = k1
        self.b = b
        self.delta = delta
        self._docs: List[IndexedRule] = []
        self._df: Dict[str, int] = {}
        self._avgdl: float = 1.0

    def add_rule(self, rule_id: str, text: str) -> bool:
        """Add a rule unless an near-identical duplicate (`hamming <= 3`) already exists."""
        sh = simhash_64(text)
        for existing in self._docs:
            if hamming_distance_64(sh, existing.simhash) <= 3:
                return False
        toks = _tokenize(text)
        tf: Dict[str, int] = {}
        for t in toks:
            tf[t] = tf.get(t, 0) + 1
        for t in set(toks):
            self._df[t] = self._df.get(t, 0) + 1
        self._docs.append(IndexedRule(rule_id=rule_id, text=text, tokens=toks, tf=tf, simhash=sh))
        total_len = sum(len(d.tokens) for d in self._docs)
        self._avgdl = max(1.0, total_len / float(len(self._docs)))
        return True

    def search(self, query: str, *, top_k: int = 5) -> List[RuleRetrievalResult]:
        if not self._docs:
            return []
        q_toks = _tokenize(query)
        q_sh = simhash_64(query)
        n_docs = len(self._docs)
        results: List[RuleRetrievalResult] = []

        for doc in self._docs:
            score = 0.0
            dl = len(doc.tokens)
            for qt in q_toks:
                f = doc.tf.get(qt, 0)
                if f == 0:
                    continue
                df = self._df.get(qt, 0)
                idf = math.log(1.0 + (n_docs - df + 0.5) / (df + 0.5))
                tf_norm = (f * (self.k1 + 1.0)) / (f + self.k1 * (1.0 - self.b + self.b * (dl / self.avgdl))) + self.delta
                score += idf * tf_norm
            dist = hamming_distance_64(q_sh, doc.simhash)
            results.append(RuleRetrievalResult(rule_id=doc.rule_id, text=doc.text, bm25_score=score, simhash_distance=dist))

        results.sort(key=lambda r: (-r.bm25_score, r.simhash_distance))
        return results[:max(1, int(top_k))]

    @property
    def avgdl(self) -> float:
        return self._avgdl


def _self_test() -> int:
    vault = VectorRuleVault()
    assert vault.add_rule("R1", "Never expose PostgreSQL database credentials or connection strings.")
    assert vault.add_rule("R2", "Always format financial comparisons as a Markdown pipe table.")
    assert vault.add_rule("R3", "Use active voice and natural contractions in peer replies.")
    # Near-duplicate rejected by SimHash
    assert not vault.add_rule("R1_DUP", "Never expose PostgreSQL database credentials or connection strings!")

    hits = vault.search("database connection credentials", top_k=2)
    assert hits[0].rule_id == "R1" and hits[0].bm25_score > 0.0, [h.to_dict() for h in hits]

    print("vectorvault._self_test: OK PASS (BM25+ ranking, 64-bit SimHash dedup, Hamming distance)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
