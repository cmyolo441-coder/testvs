"""choreography — Vector Clocks, Lamport Timestamps & Chandy-Lamport Consistent Cut Verifier.

Tracks causal partial order (`e1 -> e2`, happens-before) across distributed or
multi-threaded subagents (Lamport 1978, Fidge/Mattern 1988, Chandy-Lamport 1985):
  * `VectorClock`: maps process ID `p -> logical_tick`.
    - `V1 <= V2` iff `forall p: V1[p] <= V2[p]`
    - `V1 < V2` (causal happens-before) iff `V1 <= V2` and `V1 != V2`
    - `V1 || V2` (causally concurrent) iff `not (V1 <= V2)` and `not (V2 <= V1)`
  * Concurrent Write-Write Race Detection: flags any two events `(e1, e2)` that
    mutate the same state key `k` with `V(e1) || V(e2)`.
  * Consistent Global Snapshot Cut (`C`): verifies whether a set of per-process
    checkpoint events forms a causally consistent frontier (if `e in C` and
    `e' -> e`, then `e'` precedes or belongs to the cut).

Self-test: ``python3 -m fullagent.enforcex.choreography``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "VectorClock",
    "DistributedEvent",
    "ConcurrencyRace",
    "ChoreographyReport",
    "CausalChoreographyEngine",
]


class VectorClock:
    """Fidge/Mattern Vector Clock over process identifiers."""

    def __init__(self, clocks: Optional[Dict[str, int]] = None) -> None:
        self.clocks: Dict[str, int] = {str(k): int(v) for k, v in (clocks or {}).items() if int(v) > 0}

    def copy(self) -> "VectorClock":
        return VectorClock(self.clocks)

    def tick(self, proc: str) -> "VectorClock":
        nxt = dict(self.clocks)
        nxt[str(proc)] = nxt.get(str(proc), 0) + 1
        return VectorClock(nxt)

    def merge(self, other: "VectorClock") -> "VectorClock":
        all_keys = set(self.clocks.keys()) | set(other.clocks.keys())
        return VectorClock({k: max(self.clocks.get(k, 0), other.clocks.get(k, 0)) for k in all_keys})

    def leq(self, other: "VectorClock") -> bool:
        return all(v <= other.clocks.get(k, 0) for k, v in self.clocks.items())

    def happens_before(self, other: "VectorClock") -> bool:
        return self.leq(other) and self.clocks != other.clocks

    def concurrent_with(self, other: "VectorClock") -> bool:
        return (not self.leq(other)) and (not other.leq(self))

    def to_dict(self) -> Dict[str, int]:
        return dict(sorted(self.clocks.items()))


@dataclass
class DistributedEvent:
    event_id: str
    proc: str
    kind: str  # local | send | recv | write
    vc: VectorClock
    lamport_ts: int
    target_key: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "proc": self.proc,
            "kind": self.kind,
            "vc": self.vc.to_dict(),
            "lamport_ts": self.lamport_ts,
            "target_key": self.target_key,
        }


@dataclass
class ConcurrencyRace:
    event_a: str
    event_b: str
    proc_a: str
    proc_b: str
    key: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_a": self.event_a,
            "event_b": self.event_b,
            "proc_a": self.proc_a,
            "proc_b": self.proc_b,
            "key": self.key,
        }


@dataclass
class ChoreographyReport:
    race_free: bool
    consistent_cut: bool
    events_count: int
    races: List[ConcurrencyRace] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "race_free": self.race_free,
            "consistent_cut": self.consistent_cut,
            "events_count": self.events_count,
            "races": [r.to_dict() for r in self.races],
        }


class CausalChoreographyEngine:
    """Tracks vector clocks across processes, detects data races, and verifies Chandy-Lamport cuts."""

    def __init__(self) -> None:
        self.proc_vc: Dict[str, VectorClock] = {}
        self.proc_lamport: Dict[str, int] = {}
        self.events: List[DistributedEvent] = []

    def record_local(self, proc: str, event_id: str, *, write_key: str = "") -> DistributedEvent:
        vc = self.proc_vc.get(proc, VectorClock()).tick(proc)
        lts = self.proc_lamport.get(proc, 0) + 1
        self.proc_vc[proc] = vc
        self.proc_lamport[proc] = lts
        ev = DistributedEvent(
            event_id=event_id,
            proc=proc,
            kind="write" if write_key else "local",
            vc=vc,
            lamport_ts=lts,
            target_key=write_key,
        )
        self.events.append(ev)
        return ev

    def record_message(self, sender: str, receiver: str, send_id: str, recv_id: str) -> Tuple[DistributedEvent, DistributedEvent]:
        s_vc = self.proc_vc.get(sender, VectorClock()).tick(sender)
        s_lts = self.proc_lamport.get(sender, 0) + 1
        self.proc_vc[sender] = s_vc
        self.proc_lamport[sender] = s_lts
        ev_send = DistributedEvent(send_id, sender, "send", s_vc, s_lts)
        self.events.append(ev_send)

        r_base = self.proc_vc.get(receiver, VectorClock()).merge(s_vc).tick(receiver)
        r_lts = max(self.proc_lamport.get(receiver, 0), s_lts) + 1
        self.proc_vc[receiver] = r_base
        self.proc_lamport[receiver] = r_lts
        ev_recv = DistributedEvent(recv_id, receiver, "recv", r_base, r_lts)
        self.events.append(ev_recv)
        return ev_send, ev_recv

    def detect_write_races(self) -> List[ConcurrencyRace]:
        writes = [e for e in self.events if e.kind == "write" and e.target_key]
        races: List[ConcurrencyRace] = []
        for i in range(len(writes)):
            for j in range(i + 1, len(writes)):
                ea, eb = writes[i], writes[j]
                if ea.target_key == eb.target_key and ea.vc.concurrent_with(eb.vc):
                    races.append(ConcurrencyRace(ea.event_id, eb.event_id, ea.proc, eb.proc, ea.target_key))
        return races

    @staticmethod
    def is_consistent_cut(cut_clocks: Dict[str, VectorClock]) -> bool:
        """Mattern's Consistent Cut Theorem: a frontier `{V_p}` is causally consistent
        iff for all processes `p, q`: `V_p[p] >= V_q[p]` (no orphan received message)."""
        procs = list(cut_clocks.keys())
        for p in procs:
            vp_self = cut_clocks[p].clocks.get(p, 0)
            for q in procs:
                if cut_clocks[q].clocks.get(p, 0) > vp_self:
                    return False
        return True


def _self_test() -> int:
    eng = CausalChoreographyEngine()
    e1 = eng.record_local("w1", "e1_write", write_key="shared_verdict")
    e2 = eng.record_local("w2", "e2_write", write_key="shared_verdict")
    # w1 and w2 have not synchronized via message -> concurrent write race!
    assert e1.vc.concurrent_with(e2.vc)
    races = eng.detect_write_races()
    assert len(races) == 1 and races[0].key == "shared_verdict"

    # Synchronize w1 -> w2 so subsequent write is causally ordered
    s_ev, r_ev = eng.record_message("w1", "w2", "s1", "r1")
    assert e1.vc.happens_before(r_ev.vc)
    assert eng.is_consistent_cut({"w1": s_ev.vc, "w2": r_ev.vc}) is True
    # Inconsistent cut: w2 includes r_ev (which received s_ev) but w1 cut is before s_ev!
    assert eng.is_consistent_cut({"w1": VectorClock(), "w2": r_ev.vc}) is False

    print("choreography._self_test: OK PASS (Fidge/Mattern vector clocks, write-race detection, consistent cuts)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
