"""cusum — Page's Two-Sided Tabular CUSUM & Shiryaev-Roberts Change-Point Detector.

Provides sequential quickest-detection algorithms (Page 1954, Shiryaev 1963,
Roberts 1966, Lorden 1971) to detect multi-turn compliance degradation or
adversarial drift with minimax optimal detection delay:
  1. **Page's Two-Sided Tabular CUSUM**:
     - Upper statistic: `S_t^+ = max(0, S_{t-1}^+ + (x_t - mu_0 - k))`
     - Lower statistic: `S_t^- = max(0, S_{t-1}^- + (mu_0 - k - x_t))`
     - Triggers alarm when `max(S_t^+, S_t^-) > h`, where `k = delta / 2` is the
       reference allowance and `h` controls the Average Run Length (`ARL_0`).
  2. **Shiryaev-Roberts-Pollak (SRP) Statistic**:
     - `R_t = (1 + R_{t-1}) * LR_t`, where `LR_t = exp(delta * (x_t - mu_0 - delta/2) / sigma^2)`
       is the Gaussian likelihood ratio between pre-change `N(mu_0, sigma^2)`
       and post-change `N(mu_1, sigma^2)`.

Self-test: ``python3 -m fullagent.enforcex.cusum``
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "ChangePointStep",
    "SequentialDriftDetector",
]


@dataclass
class ChangePointStep:
    step: int
    value: float
    cusum_pos: float
    cusum_neg: float
    shiryaev_roberts: float
    alarm: bool
    direction: str  # none | upward_shift | downward_shift

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "value": round(self.value, 4),
            "cusum_pos": round(self.cusum_pos, 4),
            "cusum_neg": round(self.cusum_neg, 4),
            "shiryaev_roberts": round(self.shiryaev_roberts, 4),
            "alarm": self.alarm,
            "direction": self.direction,
        }


class SequentialDriftDetector:
    """Two-sided Page CUSUM and Shiryaev-Roberts sequential change-point detector."""

    def __init__(
        self,
        baseline_mean: float = 95.0,
        sigma: float = 4.0,
        shift_magnitude: float = 8.0,
        cusum_threshold_h: float = 16.0,
        sr_threshold: float = 120.0,
    ) -> None:
        self.mu0 = float(baseline_mean)
        self.sigma = max(1e-3, float(sigma))
        self.delta = abs(float(shift_magnitude))
        self.k = 0.5 * self.delta
        self.h = float(cusum_threshold_h)
        self.sr_threshold = float(sr_threshold)

        self.step_count = 0
        self.s_pos = 0.0
        self.s_neg = 0.0
        self.sr_stat = 0.0

    def reset(self) -> None:
        self.s_pos = 0.0
        self.s_neg = 0.0
        self.sr_stat = 0.0

    def update(self, x: float) -> ChangePointStep:
        self.step_count += 1
        val = float(x)
        self.s_pos = max(0.0, self.s_pos + (val - self.mu0 - self.k))
        self.s_neg = max(0.0, self.s_neg + (self.mu0 - self.k - val))

        # Log-likelihood ratio for downward compliance drop (mu_1 = mu_0 - delta)
        z_drop = (self.mu0 - val)
        log_lr = (self.delta * (z_drop - 0.5 * self.delta)) / (self.sigma ** 2)
        lr = math.exp(max(-20.0, min(20.0, log_lr)))
        self.sr_stat = min(1e9, (1.0 + self.sr_stat) * lr)

        alarm = False
        direction = "none"
        if self.s_neg > self.h or self.sr_stat > self.sr_threshold:
            alarm = True
            direction = "downward_shift"
        elif self.s_pos > self.h:
            alarm = True
            direction = "upward_shift"

        return ChangePointStep(
            step=self.step_count,
            value=val,
            cusum_pos=self.s_pos,
            cusum_neg=self.s_neg,
            shiryaev_roberts=self.sr_stat,
            alarm=alarm,
            direction=direction,
        )


def _self_test() -> int:
    det = SequentialDriftDetector(baseline_mean=95.0, sigma=3.0, shift_magnitude=10.0, cusum_threshold_h=15.0)
    # 10 nominal observations around 95.0 -> zero alarms
    for v in (95.0, 96.0, 94.0, 95.5, 94.5, 95.0, 96.2, 94.8, 95.1, 95.0):
        st = det.update(v)
        assert not st.alarm

    # Sudden compliance degradation to 80.0 -> CUSUM & Shiryaev-Roberts quickly trigger downward_shift alarm!
    triggered = False
    for _ in range(4):
        st = det.update(80.0)
        if st.alarm:
            triggered = True
            assert st.direction == "downward_shift"
            break
    assert triggered

    print("cusum._self_test: OK PASS (Page two-sided CUSUM + Shiryaev-Roberts quickest change-point detection)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
