"""circuit — Adaptive 3-State Circuit Breaker, Token-Bucket Rate Limiter & Bulkhead Governor.

Self-test: ``python3 -m fullagent.enforcex.circuit``
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional

__all__ = [
    "CircuitOpenError",
    "RateLimitExceededError",
    "CircuitMetrics",
    "CircuitBreaker",
    "TokenBucketLimiter",
    "Bulkhead",
]


class CircuitOpenError(RuntimeError):
    """Raised when a call is rejected because the circuit breaker is OPEN."""


class RateLimitExceededError(RuntimeError):
    """Raised when a token bucket rate limit is exceeded."""


@dataclass
class CircuitMetrics:
    name: str
    state: str = "CLOSED"
    total_calls: int = 0
    successes: int = 0
    failures: int = 0
    rejected: int = 0
    consecutive_failures: int = 0
    last_failure_ts: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "state": self.state,
            "total_calls": self.total_calls,
            "successes": self.successes,
            "failures": self.failures,
            "rejected": self.rejected,
            "consecutive_failures": self.consecutive_failures,
            "last_failure_ts": self.last_failure_ts,
        }


class CircuitBreaker:
    def __init__(
        self,
        name: str = "default",
        *,
        failure_threshold: int = 3,
        recovery_timeout_s: float = 5.0,
        half_open_successes: int = 1,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.name = str(name or "default")
        self.failure_threshold = max(1, int(failure_threshold))
        self.recovery_timeout_s = max(0.01, float(recovery_timeout_s))
        self.half_open_successes = max(1, int(half_open_successes))
        self._clock = clock
        self._lock = threading.RLock()
        self._state = "CLOSED"
        self._total = 0
        self._successes = 0
        self._failures = 0
        self._rejected = 0
        self._consec_failures = 0
        self._half_open_ok = 0
        self._opened_at = 0.0

    @property
    def state(self) -> str:
        with self._lock:
            self._check_cooldown()
            return self._state

    def _check_cooldown(self) -> None:
        if self._state == "OPEN":
            if self._clock() - self._opened_at >= self.recovery_timeout_s:
                self._state = "HALF_OPEN"
                self._half_open_ok = 0

    def allow_request(self) -> bool:
        with self._lock:
            self._check_cooldown()
            return self._state in ("CLOSED", "HALF_OPEN")

    def record_success(self) -> None:
        with self._lock:
            self._successes += 1
            self._consec_failures = 0
            if self._state == "HALF_OPEN":
                self._half_open_ok += 1
                if self._half_open_ok >= self.half_open_successes:
                    self._state = "CLOSED"

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            self._consec_failures += 1
            now = self._clock()
            if self._state == "HALF_OPEN" or self._consec_failures >= self.failure_threshold:
                self._state = "OPEN"
                self._opened_at = now

    def call(
        self,
        fn: Callable[..., Any],
        *args: Any,
        fallback: Optional[Callable[[], Any]] = None,
        **kwargs: Any,
    ) -> Any:
        with self._lock:
            self._total += 1
            self._check_cooldown()
            if self._state == "OPEN":
                self._rejected += 1
                if fallback is not None:
                    return fallback()
                raise CircuitOpenError(f"Circuit '{self.name}' is OPEN")

        try:
            result = fn(*args, **kwargs)
        except Exception:
            self.record_failure()
            if fallback is not None:
                return fallback()
            raise
        else:
            self.record_success()
            return result

    def reset(self) -> None:
        with self._lock:
            self._state = "CLOSED"
            self._consec_failures = 0
            self._half_open_ok = 0

    def metrics(self) -> CircuitMetrics:
        with self._lock:
            self._check_cooldown()
            return CircuitMetrics(
                name=self.name,
                state=self._state,
                total_calls=self._total,
                successes=self._successes,
                failures=self._failures,
                rejected=self._rejected,
                consecutive_failures=self._consec_failures,
                last_failure_ts=self._opened_at,
            )


class TokenBucketLimiter:
    def __init__(
        self,
        rate_per_sec: float = 10.0,
        burst: int = 20,
        *,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self.rate = max(0.001, float(rate_per_sec))
        self.capacity = float(max(1, int(burst)))
        self._tokens = self.capacity
        self._clock = clock
        self._last_ts = self._clock()
        self._lock = threading.Lock()

    def try_acquire(self, tokens: float = 1.0) -> bool:
        need = max(0.0, float(tokens))
        with self._lock:
            now = self._clock()
            elapsed = max(0.0, now - self._last_ts)
            self._last_ts = now
            self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
            if self._tokens >= need:
                self._tokens -= need
                return True
            return False


class Bulkhead:
    def __init__(self, max_concurrent: int = 4, timeout_s: float = 5.0) -> None:
        self.max_concurrent = max(1, int(max_concurrent))
        self.timeout_s = max(0.01, float(timeout_s))
        self._sem = threading.BoundedSemaphore(self.max_concurrent)
        self._lock = threading.Lock()
        self.active = 0
        self.rejected = 0

    def run(self, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        acquired = self._sem.acquire(timeout=self.timeout_s)
        if not acquired:
            with self._lock:
                self.rejected += 1
            raise RateLimitExceededError("Bulkhead concurrency limit reached")
        with self._lock:
            self.active += 1
        try:
            return fn(*args, **kwargs)
        finally:
            with self._lock:
                self.active -= 1
            self._sem.release()


def _self_test() -> int:
    now_box = [100.0]
    cb = CircuitBreaker("test", failure_threshold=2, recovery_timeout_s=10.0, clock=lambda: now_box[0])
    assert cb.state == "CLOSED"

    for _ in range(2):
        try:
            cb.call(lambda: (_ for _ in ()).throw(ValueError("boom")))
        except ValueError:
            pass
    assert cb.state == "OPEN"
    assert cb.call(lambda: "live", fallback=lambda: "fallback_val") == "fallback_val"
    assert cb.metrics().rejected == 1

    now_box[0] += 11.0
    assert cb.state == "HALF_OPEN"
    assert cb.call(lambda: "recovered") == "recovered"
    assert cb.state == "CLOSED"

    tb = TokenBucketLimiter(rate_per_sec=2.0, burst=2, clock=lambda: now_box[0])
    assert tb.try_acquire(1.0) and tb.try_acquire(1.0)
    assert not tb.try_acquire(1.0)
    now_box[0] += 1.0
    assert tb.try_acquire(1.0)

    bh = Bulkhead(max_concurrent=2, timeout_s=0.05)
    assert bh.run(lambda x: x + 1, 41) == 42

    print("circuit._self_test: OK PASS (CLOSED->OPEN->HALF_OPEN->CLOSED, token bucket, bulkhead)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
