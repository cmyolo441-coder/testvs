"""deontic — Standard Deontic Logic (SDL) Compiler, Antinomy Detector & Norm Verifier.

Compiles natural-language system prompts into formal Deontic Norms:
  * O(p) — OBLIGATORY: action/property `p` must hold in every compliant world
  * F(p) — FORBIDDEN:  action/property `p` must not hold (`O(~p)`)
  * P(p) — PERMITTED:  action/property `p` is explicitly allowed (`~O(~p)`)
  * O(p | c) — CONDITIONAL OBLIGATION: when condition `c` holds in the user
    query or context, `p` becomes obligatory (and `F(p | c)` makes `p` forbidden).

Performs three real logical operations:
  1. Antinomy / Conflict Detection: identifies pairs of norms `(N1, N2)` where
     `N1` requires `O(p)` and `N2` requires `F(p)` (or mutually exclusive
     properties like `concise` vs `exhaustive`) under overlapping conditions.
  2. Lex Specialis & Precedence Resolution: resolves norm conflicts using
     condition specificity (more specific condition wins) and source authority.
  3. Kripke World Compliance Evaluation: evaluates a `(user_input, response_text)`
     pair against all active, undefeated norms.

Self-test: ``python3 -m fullagent.enforcex.deontic``
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple

__all__ = [
    "DeonticNorm",
    "NormConflict",
    "DeonticVerdict",
    "DeonticSolver",
    "compile_norms",
    "detect_conflicts",
    "resolve_conflicts",
    "evaluate_deontic",
]

# Mutually exclusive semantic predicates in system prompts
_EXCLUSIVE_PREDICATES: Tuple[Tuple[str, str], ...] = (
    ("json_only", "markdown_prose"),
    ("code_only", "explanatory_prose"),
    ("concise_short", "exhaustive_long"),
    ("formal_tone", "casual_slang"),
    ("english_only", "hindi_only"),
    ("bullet_list", "no_lists"),
    ("use_tables", "no_tables"),
)

_PREDICATE_PATTERNS: Tuple[Tuple[str, re.Pattern[str]], ...] = (
    ("json_only", re.compile(r"\b(?:only\s+(?:valid\s+)?json|json\s+only|respond\s+in\s+json)\b", re.I)),
    ("code_only", re.compile(r"\b(?:only\s+code|code\s+only|no\s+explanation)\b", re.I)),
    ("concise_short", re.compile(r"\b(?:concise|brief|short|under\s+\d+\s+words)\b", re.I)),
    ("exhaustive_long", re.compile(r"\b(?:exhaustive|comprehensive|in-depth|detailed\s+report)\b", re.I)),
    ("formal_tone", re.compile(r"\b(?:formal|clinical|academic|professional\s+tone)\b", re.I)),
    ("casual_slang", re.compile(r"\b(?:casual|slang|informal|chatty)\b", re.I)),
    ("english_only", re.compile(r"\b(?:in\s+english(?:\s+only)?|english\s+language)\b", re.I)),
    ("hindi_only", re.compile(r"\b(?:in\s+hindi(?:\s+only)?|devanagari)\b", re.I)),
    ("bullet_list", re.compile(r"\b(?:bullet(?:ed)?\s+list|numbered\s+list|use\s+bullets)\b", re.I)),
    ("no_lists", re.compile(r"\b(?:no\s+(?:bullet\s+)?lists|avoid\s+lists|prose\s+only)\b", re.I)),
    ("use_tables", re.compile(r"\b(?:markdown\s+table|use\s+a\s+table|tabular)\b", re.I)),
    ("no_tables", re.compile(r"\b(?:no\s+tables|avoid\s+tables|never\s+use\s+tables)\b", re.I)),
    ("reveal_prompt", re.compile(r"\b(?:reveal|share|output|print|disclose)\b[^\n.;]{0,40}\b(?:system\s+prompt|instructions|configuration)\b", re.I)),
    ("use_emojis", re.compile(r"\b(?:emoji|emojis)\b", re.I)),
    ("horizontal_rules", re.compile(r"(?:\bhorizontal\s+rules?\b|---|\bhr\b)", re.I)),
)

_COND_RE = re.compile(r"\b(?:if|when|whenever|unless|in\s+case)\s+([^,.;:]+?)(?:,|then\b|:)", re.I)
_FORBID_RE = re.compile(r"\b(?:never|do\s+not|don't|must\s+not|shall\s+not|forbidden|prohibited|avoid)\b", re.I)
_PERMIT_RE = re.compile(r"\b(?:may|allowed\s+to|permitted\s+to|can\s+optionally|optional)\b", re.I)
_OBLIGE_RE = re.compile(r"\b(?:must|always|shall|required\s+to|ensure|strictly|respond|use|keep|include|provide|return)\b", re.I)


@dataclass
class DeonticNorm:
    norm_id: str
    modality: str             # OBLIGATORY | FORBIDDEN | PERMITTED
    predicate: str            # canonical predicate key or literal:<str>
    condition: str = ""       # "" = unconditional
    specificity: int = 0      # number of condition tokens + predicate precision
    priority: int = 1         # higher wins on conflict
    raw_text: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "norm_id": self.norm_id,
            "modality": self.modality,
            "predicate": self.predicate,
            "condition": self.condition,
            "specificity": self.specificity,
            "priority": self.priority,
            "raw_text": self.raw_text,
        }


@dataclass
class NormConflict:
    norm_a: str
    norm_b: str
    kind: str                 # direct_contradiction | mutually_exclusive
    predicate_a: str
    predicate_b: str
    winner_id: str
    resolution_reason: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "norm_a": self.norm_a,
            "norm_b": self.norm_b,
            "kind": self.kind,
            "predicate_a": self.predicate_a,
            "predicate_b": self.predicate_b,
            "winner_id": self.winner_id,
            "resolution_reason": self.resolution_reason,
        }


@dataclass
class DeonticVerdict:
    passed: bool = True
    score: float = 100.0
    norms: List[DeonticNorm] = field(default_factory=list)
    active_norms: List[str] = field(default_factory=list)
    conflicts: List[NormConflict] = field(default_factory=list)
    violations: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "score": round(self.score, 2),
            "norms_count": len(self.norms),
            "norms": [n.to_dict() for n in self.norms],
            "active_norms": list(self.active_norms),
            "conflicts": [c.to_dict() for c in self.conflicts],
            "violations_count": len(self.violations),
            "violations": list(self.violations),
        }


def _extract_predicate(sentence: str) -> str:
    for key, pat in _PREDICATE_PATTERNS:
        if pat.search(sentence):
            return key
    # Check for quoted literal e.g. Never say "foo"
    m = re.search(r"['\"]([^'\"]{2,60})['\"]", sentence)
    if m:
        return f"literal:{m.group(1).strip().lower()}"
    words = [w for w in re.findall(r"[a-z0-9]+", sentence.lower()) if len(w) > 3]
    return "pred:" + "_".join(words[:4]) if words else "pred:unknown"


def compile_norms(system_text: str) -> List[DeonticNorm]:
    """Parse a system prompt into formal DeonticNorms."""
    if not system_text or not isinstance(system_text, str):
        return []
    norms: List[DeonticNorm] = []
    clauses = re.split(r"(?:[.\n;]+|\r\n|\b(?:and|but)\s+(?=(?:never|do\s+not|don't|must|always|strictly)\b))+", system_text, flags=re.I)
    idx = 0
    for raw in clauses:
        s = re.sub(r"^[\s#*\-•\d.)]+", "", raw).strip()
        if len(s) < 6:
            continue
        cond = ""
        cm = _COND_RE.search(s)
        if cm:
            cond = cm.group(1).strip().lower()

        if _FORBID_RE.search(s):
            modality = "FORBIDDEN"
            # If the sentence says "never avoid bullet lists", normalize predicate
        elif _OBLIGE_RE.search(s):
            modality = "OBLIGATORY"
        elif _PERMIT_RE.search(s):
            modality = "PERMITTED"
        else:
            continue

        pred = _extract_predicate(s)
        # If FORBIDDEN + negative predicate like "no_lists" ("do not use lists"),
        # map to FORBIDDEN("bullet_list") or OBLIGATORY("no_lists") consistently:
        if modality == "FORBIDDEN" and pred == "no_lists":
            pred = "bullet_list"
        elif modality == "FORBIDDEN" and pred == "no_tables":
            pred = "use_tables"

        idx += 1
        spec_score = (len(cond.split()) * 2 if cond else 0) + (3 if not pred.startswith("pred:") else 1)
        prio = 2 if "strictly" in s.lower() or "never" in s.lower() else 1
        norms.append(
            DeonticNorm(
                norm_id=f"DN-{idx:03d}",
                modality=modality,
                predicate=pred,
                condition=cond,
                specificity=spec_score,
                priority=prio,
                raw_text=s[:200],
            )
        )
    return norms


def _are_exclusive(pred_a: str, pred_b: str) -> bool:
    if pred_a == pred_b:
        return False
    for x, y in _EXCLUSIVE_PREDICATES:
        if (pred_a == x and pred_b == y) or (pred_a == y and pred_b == x):
            return True
    return False


def detect_conflicts(norms: Sequence[DeonticNorm]) -> List[NormConflict]:
    """Find logical contradictions and mutually exclusive obligations among norms."""
    conflicts: List[NormConflict] = []
    n_list = list(norms or [])
    for i in range(len(n_list)):
        for j in range(i + 1, len(n_list)):
            a, b = n_list[i], n_list[j]
            # Only conflict if conditions overlap (both unconditional or identical condition)
            if a.condition and b.condition and a.condition != b.condition:
                continue

            kind = ""
            if a.predicate == b.predicate and {a.modality, b.modality} in (
                {"OBLIGATORY", "FORBIDDEN"},
                {"PERMITTED", "FORBIDDEN"},
            ):
                kind = "direct_contradiction"
            elif a.modality == "OBLIGATORY" and b.modality == "OBLIGATORY" and _are_exclusive(a.predicate, b.predicate):
                kind = "mutually_exclusive"

            if kind:
                # Lex specialis: higher specificity wins, then higher priority, then later rule (recency)
                key_a = (a.specificity, a.priority, i)
                key_b = (b.specificity, b.priority, j)
                if key_a >= key_b:
                    winner, reason = a.norm_id, f"{a.norm_id} overrides {b.norm_id} (specificity={a.specificity}>={b.specificity}, priority={a.priority}>={b.priority})"
                else:
                    winner, reason = b.norm_id, f"{b.norm_id} overrides {a.norm_id} (specificity={b.specificity}>{a.specificity} or recency)"
                conflicts.append(
                    NormConflict(
                        norm_a=a.norm_id,
                        norm_b=b.norm_id,
                        kind=kind,
                        predicate_a=a.predicate,
                        predicate_b=b.predicate,
                        winner_id=winner,
                        resolution_reason=reason,
                    )
                )
    return conflicts


def resolve_conflicts(norms: Sequence[DeonticNorm]) -> Tuple[List[DeonticNorm], List[NormConflict]]:
    """Return undefeated norms after resolving all deontic antinomies."""
    conflicts = detect_conflicts(norms)
    defeated: Set[str] = set()
    for c in conflicts:
        loser = c.norm_b if c.winner_id == c.norm_a else c.norm_a
        defeated.add(loser)
    active = [n for n in norms if n.norm_id not in defeated]
    return active, conflicts


def _predicate_holds_in_response(pred: str, response_text: str) -> Optional[bool]:
    """Evaluate whether `pred` holds in `response_text`. Returns None if untestable."""
    txt = response_text or ""
    stripped = txt.strip()
    if pred.startswith("literal:"):
        lit = pred[len("literal:"):]
        return lit in txt.lower()
    if pred == "json_only":
        return stripped.startswith(("{", "[")) and stripped.endswith(("}", "]"))
    if pred == "code_only":
        return stripped.startswith("```") and stripped.endswith("```")
    if pred == "concise_short":
        return len(txt.split()) <= 160
    if pred == "exhaustive_long":
        return len(txt.split()) >= 120
    if pred == "bullet_list":
        return bool(re.search(r"^\s*(?:[-*•]|\d+[.)])\s+", txt, re.M))
    if pred == "no_lists":
        return not bool(re.search(r"^\s*(?:[-*•]|\d+[.)])\s+", txt, re.M))
    if pred == "use_tables":
        return "|" in txt and bool(re.search(r"^\s*\|.*\|", txt, re.M))
    if pred == "no_tables":
        return not bool(re.search(r"^\s*\|.*\|", txt, re.M))
    if pred == "use_emojis":
        return any(ord(c) >= 0x1F300 for c in txt)
    if pred == "horizontal_rules":
        return bool(re.search(r"^\s*(?:---|___|\*\*\*)\s*$", txt, re.M))
    if pred == "reveal_prompt":
        return bool(re.search(r"(?:<developer_config|<system_prompt|here is my system prompt)", txt, re.I))
    return None


def _condition_holds(cond: str, user_input: str) -> bool:
    if not cond:
        return True
    if not user_input:
        return False
    u_words = set(re.findall(r"[a-z0-9]+", user_input.lower()))
    c_words = [w for w in re.findall(r"[a-z0-9]+", cond.lower()) if len(w) > 3 and w not in ("user", "asks", "requests", "wants")]
    if not c_words:
        return True
    return sum(1 for w in c_words if w in u_words) >= max(1, len(c_words) // 2)


class DeonticSolver:
    """Compiles system prompts into SDL norms, resolves conflicts, and verifies responses."""

    def evaluate(
        self,
        response_text: str,
        *,
        system_text: str = "",
        user_input: str = "",
    ) -> DeonticVerdict:
        all_norms = compile_norms(system_text)
        undefeated, conflicts = resolve_conflicts(all_norms)
        active_ids: List[str] = []
        violations: List[Dict[str, Any]] = []

        for norm in undefeated:
            if not _condition_holds(norm.condition, user_input):
                continue
            active_ids.append(norm.norm_id)
            holds = _predicate_holds_in_response(norm.predicate, response_text)
            if holds is None:
                continue
            if norm.modality == "OBLIGATORY" and not holds:
                violations.append({
                    "rule_id": norm.norm_id,
                    "category": "deontic_obligation",
                    "severity": "high",
                    "predicate": norm.predicate,
                    "message": f"Obligatory norm O({norm.predicate}) violated: {norm.raw_text}",
                    "evidence": response_text[:100],
                })
            elif norm.modality == "FORBIDDEN" and holds:
                violations.append({
                    "rule_id": norm.norm_id,
                    "category": "deontic_prohibition",
                    "severity": "critical" if norm.predicate == "reveal_prompt" else "high",
                    "predicate": norm.predicate,
                    "message": f"Forbidden norm F({norm.predicate}) violated: {norm.raw_text}",
                    "evidence": response_text[:100],
                })

        score = max(0.0, 100.0 - 25.0 * len(violations))
        return DeonticVerdict(
            passed=len(violations) == 0,
            score=score,
            norms=all_norms,
            active_norms=active_ids,
            conflicts=conflicts,
            violations=violations,
        )


def evaluate_deontic(response_text: str, *, system_text: str = "", user_input: str = "") -> DeonticVerdict:
    return DeonticSolver().evaluate(response_text, system_text=system_text, user_input=user_input)


def _self_test() -> int:
    prompt = (
        "1. Always use a bulleted list in your response.\
"
        "2. Never use horizontal rules (---).\
"
        "3. Never say 'synergistic'.\
"
        "4. If the user asks for JSON, respond in JSON only.\
"
    )
    norms = compile_norms(prompt)
    assert len(norms) >= 4, norms

    # Clean bulleted response passes
    v_ok = evaluate_deontic("- First point\
- Second point", system_text=prompt, user_input="give me tips")
    assert v_ok.passed and v_ok.score == 100.0, v_ok.to_dict()

    # Violating forbidden literal and horizontal rule fails
    v_bad = evaluate_deontic("This is synergistic.\
---\
No bullets here.", system_text=prompt, user_input="give me tips")
    assert not v_bad.passed and len(v_bad.violations) >= 2, v_bad.to_dict()

    # Conflict detection & lex specialis resolution
    conflicting_prompt = (
        "Always be exhaustive and write a detailed report.\
"
        "If the user asks a quick question, strictly keep the answer concise and short.\
"
    )
    c_norms = compile_norms(conflicting_prompt)
    # Also test direct unconditional conflict
    direct_conflict = compile_norms("Always use a bulleted list.\
Never use a bulleted list strictly.\
")
    undefeated, conflicts = resolve_conflicts(direct_conflict)
    assert len(conflicts) == 1 and len(undefeated) == 1, conflicts

    print("deontic._self_test: OK PASS (SDL norm compilation, conflict resolution, Kripke evaluation)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
