"""egraph — Equality Saturation (E-Graph), Union-Find Congruence Closure & Cost Extractor.

Implements a compact **E-Graph** (Nelson-Oppen congruence closure + Willsey et
al. `egg` equality saturation) to canonicalize equivalent expressions, rules,
and code fragments:
  * **E-Node `f(c_1, ..., c_k)`**: an operator symbol applied to child **E-Class** IDs.
  * **E-Class**: an equivalence class of E-Nodes representing the same semantic value.
  * **Path-Compressed Union-Find**: maintains canonical E-Class representatives.
  * **Upward Congruence Closure (`rebuild()`)**: whenever `find(c1) == find(c2)`,
    parent E-Nodes `f(c1)` and `f(c2)` are automatically merged into the same E-Class!
  * **Minimum-Cost AST Extraction**: bottom-up dynamic programming extracts the
    simplest canonical term from any E-Class.

Self-test: ``python3 -m fullagent.enforcex.egraph``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "ENode",
    "TermAST",
    "EGraph",
]


@dataclass(frozen=True)
class ENode:
    op: str
    children: Tuple[int, ...] = ()

    def canonicalize(self, find_fn: Callable[[int], int]) -> "ENode":
        return ENode(self.op, tuple(find_fn(c) for c in self.children))


@dataclass(frozen=True)
class TermAST:
    op: str
    args: Tuple["TermAST", ...] = ()

    def __str__(self) -> str:
        if not self.args:
            return self.op
        return f"({self.op} " + " ".join(str(a) for a in self.args) + ")"


class EGraph:
    """Hashconsed E-Graph with congruence closure and minimum-cost extraction."""

    def __init__(self) -> None:
        self.parent: List[int] = []
        self.eclasses: Dict[int, Set[ENode]] = {}
        self.memo: Dict[ENode, int] = {}
        self.worklist: List[int] = []

    def find(self, eclass_id: int) -> int:
        root = int(eclass_id)
        while self.parent[root] != root:
            self.parent[root] = self.parent[self.parent[root]]
            root = self.parent[root]
        return root

    def add_enode(self, node: ENode) -> int:
        canon = node.canonicalize(self.find)
        if canon in self.memo:
            return self.find(self.memo[canon])
        new_id = len(self.parent)
        self.parent.append(new_id)
        self.eclasses[new_id] = {canon}
        self.memo[canon] = new_id
        return new_id

    def add_term(self, term: TermAST) -> int:
        child_ids = tuple(self.add_term(a) for a in term.args)
        return self.add_enode(ENode(term.op, child_ids))

    def union(self, id1: int, id2: int) -> int:
        r1, r2 = self.find(id1), self.find(id2)
        if r1 == r2:
            return r1
        self.parent[r2] = r1
        self.eclasses[r1].update(self.eclasses.pop(r2, set()))
        self.worklist.append(r1)
        return r1

    def rebuild(self) -> None:
        """Restore upward congruence closure invariant across all E-Classes until fixpoint."""
        while self.worklist:
            self.worklist.clear()
            for cid in list(self.eclasses.keys()):
                root = self.find(cid)
                nodes = list(self.eclasses.get(root, ()))
                new_nodes: Set[ENode] = set()
                for n in nodes:
                    cn = n.canonicalize(self.find)
                    if cn in self.memo:
                        existing = self.find(self.memo[cn])
                        if existing != root:
                            root = self.union(root, existing)
                    self.memo[cn] = root
                    new_nodes.add(cn)
                self.eclasses[root] = new_nodes

    def equivalent(self, id1: int, id2: int) -> bool:
        self.rebuild()
        return self.find(id1) == self.find(id2)

    def extract_best(self, eclass_id: int, op_costs: Optional[Dict[str, float]] = None) -> Tuple[float, TermAST]:
        """Extract minimum-cost TermAST from `eclass_id` via Bellman-Ford DP over E-Classes."""
        self.rebuild()
        costs = op_costs or {}
        best_cost: Dict[int, float] = {}
        best_node: Dict[int, ENode] = {}

        changed = True
        while changed:
            changed = False
            for cid, nodes in list(self.eclasses.items()):
                root = self.find(cid)
                for n in nodes:
                    if all(self.find(ch) in best_cost for ch in n.children):
                        c_val = float(costs.get(n.op, 1.0)) + sum(best_cost[self.find(ch)] for ch in n.children)
                        if c_val < best_cost.get(root, float("inf")):
                            best_cost[root] = c_val
                            best_node[root] = n
                            changed = True

        def build_ast(cid: int, seen: Set[int]) -> TermAST:
            r = self.find(cid)
            n = best_node[r]
            if r in seen:
                return TermAST(n.op)
            return TermAST(n.op, tuple(build_ast(ch, seen | {r}) for ch in n.children))

        target = self.find(eclass_id)
        return best_cost[target], build_ast(target, set())


def _self_test() -> int:
    eg = EGraph()
    # Build terms: (mul x 2), (shl x 1), and (div (mul x 2) 2)
    x = eg.add_term(TermAST("x"))
    two = eg.add_term(TermAST("2"))
    one = eg.add_term(TermAST("1"))
    mul_x_2 = eg.add_enode(ENode("mul", (x, two)))
    shl_x_1 = eg.add_enode(ENode("shl", (x, one)))
    div_mul = eg.add_enode(ENode("div", (mul_x_2, two)))
    div_shl = eg.add_enode(ENode("div", (shl_x_1, two)))

    # Assert rewrite equivalence: (mul x 2) == (shl x 1)
    eg.union(mul_x_2, shl_x_1)
    # Upward congruence closure automatically proves (div (mul x 2) 2) == (div (shl x 1) 2)!
    assert eg.equivalent(div_mul, div_shl)

    # Assert algebraic simplification: (div (mul x 2) 2) == x
    eg.union(div_mul, x)
    cost, simplest = eg.extract_best(div_shl)
    assert cost == 1.0 and str(simplest) == "x", (cost, str(simplest))

    print("egraph._self_test: OK PASS (Union-Find hashconsing, upward congruence closure, min-cost AST extraction)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
