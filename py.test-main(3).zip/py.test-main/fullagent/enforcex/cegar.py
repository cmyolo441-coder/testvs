"""cegar — Counterexample-Guided Abstraction Refinement (CEGAR) Loop & Predicate Splitter.

Implements Clarke, Grumberg, Jha, Lu & Veith's **CEGAR** algorithm for
verifying safety properties over large or infinite state spaces:
  1. **Predicate Abstraction**: projects concrete states `s` onto bitvectors
     over a current predicate set `P = {p_1, ..., p_k}`.
  2. **Abstract Reachability**: searches for an abstract error path
     `a_0 -> a_1 -> ... -> a_m` from initial states to an unsafe state.
  3. **Feasibility / Spuriousness Check**: simulates the abstract trace on the
     concrete transition system. If feasible, returns a real concrete
     counterexample.
  4. **Craig-Style Predicate Discovery & Refinement**: if the abstract path is
     *spurious* at step `i` (the concrete post-image of `a_i` does not intersect
     `a_{i+1}`), automatically adds a separating predicate `p_{new}` that splits
     the spurious abstract state and repeats the loop!

Self-test: ``python3 -m fullagent.enforcex.cegar``
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "Predicate",
    "CEGARReport",
    "CEGARVerifier",
]


@dataclass(frozen=True)
class Predicate:
    name: str
    fn: Callable[[Dict[str, Any]], bool]


@dataclass
class CEGARReport:
    safe: bool
    iterations: int
    predicates_learned: List[str] = field(default_factory=list)
    concrete_counterexample: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "safe": self.safe,
            "iterations": self.iterations,
            "predicates_learned": list(self.predicates_learned),
            "concrete_counterexample": list(self.concrete_counterexample),
        }


class CEGARVerifier:
    """Predicate-abstraction model checker with automatic spurious-path refinement."""

    def verify(
        self,
        concrete_states: Sequence[Dict[str, Any]],
        initial_indices: Sequence[int],
        transitions: Dict[int, Sequence[int]],
        is_unsafe: Callable[[Dict[str, Any]], bool],
        candidate_predicates: Sequence[Predicate],
        *,
        max_iters: int = 12,
    ) -> CEGARReport:
        active_preds: List[Predicate] = []
        remaining_preds: List[Predicate] = list(candidate_predicates)

        def abstract_sig(idx: int) -> Tuple[bool, ...]:
            st = concrete_states[idx]
            return tuple(bool(p.fn(st)) for p in active_preds)

        for it in range(1, max_iters + 1):
            # 1. Partition concrete state indices by their abstract predicate bitvector
            sig_to_concretes: Dict[Tuple[bool, ...], Set[int]] = {}
            idx_to_sig: Dict[int, Tuple[bool, ...]] = {}
            for idx in range(len(concrete_states)):
                sig = abstract_sig(idx)
                idx_to_sig[idx] = sig
                sig_to_concretes.setdefault(sig, set()).add(idx)

            init_sigs = {idx_to_sig[i] for i in initial_indices}
            unsafe_sigs = {idx_to_sig[i] for i in range(len(concrete_states)) if is_unsafe(concrete_states[i])}

            # Existential abstract transition relation: A -> B iff exists u in A, v in B with (u, v) in R
            abs_trans: Dict[Tuple[bool, ...], Set[Tuple[bool, ...]]] = {s: set() for s in sig_to_concretes}
            for u, succs in transitions.items():
                su = idx_to_sig[u]
                for v in succs:
                    abs_trans[su].add(idx_to_sig[v])

            # 2. BFS in abstract graph from init_sigs to unsafe_sigs
            q: deque[List[Tuple[bool, ...]]] = deque([[s] for s in sorted(init_sigs)])
            seen: Set[Tuple[bool, ...]] = set(init_sigs)
            abs_path: Optional[List[Tuple[bool, ...]]] = None
            while q:
                path = q.popleft()
                last = path[-1]
                if last in unsafe_sigs:
                    abs_path = path
                    break
                for nxt in sorted(abs_trans.get(last, ())):
                    if nxt not in seen:
                        seen.add(nxt)
                        q.append(path + [nxt])

            if abs_path is None:
                # Abstract over-approximation has NO path to unsafe -> system is provably SAFE!
                return CEGARReport(
                    safe=True,
                    iterations=it,
                    predicates_learned=[p.name for p in active_preds],
                )

            # 3. Check if abstract path corresponds to a real concrete path
            frontier: Dict[int, List[int]] = {
                i: [i] for i in initial_indices if idx_to_sig[i] == abs_path[0]
            }
            spurious_step = -1
            for step_idx in range(len(abs_path) - 1):
                next_sig = abs_path[step_idx + 1]
                next_frontier: Dict[int, List[int]] = {}
                for u, c_path in frontier.items():
                    for v in transitions.get(u, ()):
                        if idx_to_sig[v] == next_sig and v not in next_frontier:
                            next_frontier[v] = c_path + [v]
                if not next_frontier:
                    spurious_step = step_idx
                    break
                frontier = next_frontier

            if spurious_step == -1:
                # Check if any reached concrete state in final bucket is genuinely unsafe
                for u, c_path in frontier.items():
                    if is_unsafe(concrete_states[u]):
                        return CEGARReport(
                            safe=False,
                            iterations=it,
                            predicates_learned=[p.name for p in active_preds],
                            concrete_counterexample=[concrete_states[i] for i in c_path],
                        )

            # 4. Path is spurious! Refine abstraction by selecting a predicate that separates
            # reachable concrete states in bucket from dead-end states in the same bucket
            chosen_pred: Optional[Predicate] = None
            bucket_states = sig_to_concretes[abs_path[max(0, spurious_step)]]
            reachable_in_bucket = set(frontier.keys())
            others_in_bucket = bucket_states - reachable_in_bucket
            for cand in remaining_preds:
                vals_r = {bool(cand.fn(concrete_states[i])) for i in reachable_in_bucket}
                vals_o = {bool(cand.fn(concrete_states[i])) for i in others_in_bucket}
                if vals_r != vals_o or len(vals_r | vals_o) > 1:
                    chosen_pred = cand
                    break
            if chosen_pred is None and remaining_preds:
                chosen_pred = remaining_preds[0]
            if chosen_pred is None:
                break
            remaining_preds.remove(chosen_pred)
            active_preds.append(chosen_pred)

        return CEGARReport(
            safe=False,
            iterations=max_iters,
            predicates_learned=[p.name for p in active_preds],
        )


def _self_test() -> int:
    # Concrete transition system where s0 -> s1 (validated=True), and s2 (validated=False) -> s3 (unsafe)
    # Without predicate `validated`, s1 and s2 merge into one abstract state, creating a spurious path s0 -> {s1,s2} -> s3!
    states = [
        {"id": "s0_init", "validated": True, "leaked": False},
        {"id": "s1_safe_done", "validated": True, "leaked": False},
        {"id": "s2_unvalidated", "validated": False, "leaked": False},
        {"id": "s3_unsafe_leak", "validated": False, "leaked": True},
    ]
    transitions = {
        0: [1],
        1: [1],
        2: [3],
        3: [3],
    }
    preds = [
        Predicate("is_leaked", lambda s: s["leaked"]),
        Predicate("is_validated", lambda s: s["validated"]),
    ]
    v = CEGARVerifier()
    rep = v.verify(
        concrete_states=states,
        initial_indices=[0],
        transitions=transitions,
        is_unsafe=lambda s: s["leaked"],
        candidate_predicates=preds,
    )
    assert rep.safe is True and rep.iterations >= 2
    assert "is_validated" in rep.predicates_learned

    print("cegar._self_test: OK PASS (spurious counterexample elimination & automatic predicate refinement)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
