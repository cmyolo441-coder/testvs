"""dempstershafer — Dempster-Shafer Theory of Evidence, Belief/Plausibility & Pignistic Transform.

Implements Glenn Shafer's **Mathematical Theory of Evidence** (1976) and
Smets' **Transferable Belief Model** over a frame of discernment
`Theta = {safe, warning, violation}`:
  * **Basic Probability Assignment (BPA / Mass Function `m: 2^Theta -> [0, 1]`)**:
    `m(empty) = 0` and `sum_{A subseteq Theta} m(A) = 1`. Mass assigned to
    `Theta` itself represents explicit epistemic ignorance!
  * **Belief Function (`Bel(A) = sum_{B subseteq A} m(B)`)**: lower bound on probability.
  * **Plausibility Function (`Pl(A) = sum_{B & A != empty} m(B) = 1 - Bel(Theta \\ A)`)**:
    upper bound on probability.
  * **Dempster's Rule of Orthogonal Combination (`m_1 (+) m_2`)**:
    `m_{12}(C) = (1 / (1 - K)) * sum_{A & B = C} m_1(A) * m_2(B)`, where
    `K = sum_{A & B = empty} m_1(A) * m_2(B)` is the inter-sensor conflict mass.
  * **Smets' Pignistic Probability (`BetP(omega) = sum_{omega in A} m(A) / |A|`)**.

Self-test: ``python3 -m fullagent.enforcex.dempstershafer``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Sequence, Tuple

__all__ = [
    "MassAssignment",
    "DempsterShaferReport",
    "DempsterShaferEngine",
]


class MassAssignment:
    """Basic Probability Assignment `m: 2^Theta -> [0, 1]`."""

    def __init__(self, frame: Iterable[str], masses: Optional[Dict[FrozenSet[str], float]] = None) -> None:
        self.frame: FrozenSet[str] = frozenset(str(x) for x in frame)
        raw: Dict[FrozenSet[str], float] = {}
        for focal, val in (masses or {}).items():
            fset = frozenset(str(x) for x in focal) & self.frame
            if fset and float(val) > 0.0:
                raw[fset] = raw.get(fset, 0.0) + float(val)
        tot = sum(raw.values())
        if tot <= 1e-12:
            self.masses: Dict[FrozenSet[str], float] = {self.frame: 1.0}
        else:
            self.masses = {k: v / tot for k, v in raw.items()}

    def belief(self, hypothesis: Iterable[str]) -> float:
        h = frozenset(str(x) for x in hypothesis) & self.frame
        return sum(v for focal, v in self.masses.items() if focal.issubset(h))

    def plausibility(self, hypothesis: Iterable[str]) -> float:
        h = frozenset(str(x) for x in hypothesis) & self.frame
        return sum(v for focal, v in self.masses.items() if len(focal & h) > 0)

    def pignistic_probabilities(self) -> Dict[str, float]:
        """Smets' pignistic transformation `BetP(x) = sum_{x in A} m(A) / |A|`."""
        bet: Dict[str, float] = {x: 0.0 for x in self.frame}
        for focal, mass in self.masses.items():
            share = mass / float(len(focal))
            for elem in focal:
                bet[elem] += share
        return bet


@dataclass
class DempsterShaferReport:
    conflict_k: float
    belief_intervals: Dict[str, Tuple[float, float]]
    pignistic: Dict[str, float]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conflict_k": round(self.conflict_k, 4),
            "belief_intervals": {k: (round(v[0], 4), round(v[1], 4)) for k, v in self.belief_intervals.items()},
            "pignistic": {k: round(v, 4) for k, v in self.pignistic.items()},
        }


class DempsterShaferEngine:
    """Combines multi-sensor evidence via Dempster's Rule of Combination."""

    def __init__(self, frame: Sequence[str] = ("safe", "warning", "violation")) -> None:
        self.frame: FrozenSet[str] = frozenset(str(x) for x in frame)

    def combine(self, m1: MassAssignment, m2: MassAssignment) -> Tuple[MassAssignment, float]:
        """Compute `m1 (+) m2` and conflict mass `K in [0, 1)`."""
        combined: Dict[FrozenSet[str], float] = {}
        conflict_k = 0.0
        for a, v1 in m1.masses.items():
            for b, v2 in m2.masses.items():
                inter = a & b
                prod = v1 * v2
                if not inter:
                    conflict_k += prod
                else:
                    combined[inter] = combined.get(inter, 0.0) + prod

        if conflict_k >= 1.0 - 1e-12:
            # Total conflict fallback: Yager's rule assigns conflict mass to universal ignorance Theta
            return MassAssignment(self.frame, {self.frame: 1.0}), 1.0

        norm = 1.0 / (1.0 - conflict_k)
        normalized = {k: v * norm for k, v in combined.items()}
        return MassAssignment(self.frame, normalized), conflict_k

    def evaluate_sensors(self, assignments: Sequence[MassAssignment]) -> DempsterShaferReport:
        if not assignments:
            base = MassAssignment(self.frame)
            total_k = 0.0
        else:
            base = assignments[0]
            total_k = 0.0
            for nxt in assignments[1:]:
                base, k = self.combine(base, nxt)
                total_k = max(total_k, k)

        intervals: Dict[str, Tuple[float, float]] = {}
        for x in sorted(self.frame):
            intervals[x] = (base.belief([x]), base.plausibility([x]))
        return DempsterShaferReport(
            conflict_k=total_k,
            belief_intervals=intervals,
            pignistic=base.pignistic_probabilities(),
        )


def _self_test() -> int:
    eng = DempsterShaferEngine(("safe", "warning", "violation"))
    # Sensor 1 assigns 0.70 to {safe} and 0.30 to universal ignorance Theta
    s1 = MassAssignment(eng.frame, {frozenset(["safe"]): 0.70, eng.frame: 0.30})
    # Sensor 2 assigns 0.80 to {safe} and 0.20 to Theta
    s2 = MassAssignment(eng.frame, {frozenset(["safe"]): 0.80, eng.frame: 0.20})

    rep = eng.evaluate_sensors([s1, s2])
    # Combined mass on {safe} = 1 - (0.30 * 0.20) = 0.94, ignorance = 0.06, conflict K = 0.0!
    bel_safe, pl_safe = rep.belief_intervals["safe"]
    assert abs(bel_safe - 0.94) < 1e-6 and abs(pl_safe - 1.0) < 1e-6
    assert abs(sum(rep.pignistic.values()) - 1.0) < 1e-6

    print("dempstershafer._self_test: OK PASS (BPA mass functions, Bel/Pl intervals, Dempster combination, BetP)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
