"""tokensteer — Provider-Ready Logit-Bias, Stop-Sequence & Assistant Prefill Compiler.

Compiles natural-language system prompt rules into concrete decoding parameters:
  * `forbidden_strings`: extracted from `Never say "..."` / `Do not use "..."`
    and banned buzzwords/openers.
  * `logit_bias`: maps token IDs (via a pluggable tokenizer or byte/word hash)
    to `-100.0` (hard ban) or `+5.0` (boost).
  * `stop_sequences`: structural boundary tags (`</developer_config>`, `---` when
    horizontal rules are banned).
  * `assistant_prefill`: e.g. `"{ "` for JSON-only mode or `"```python\n"` for
    Python-code-only mode.

Self-test: ``python3 -m fullagent.enforcex.tokensteer``
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence

__all__ = [
    "TokenSteeringSpec",
    "TokenSteeringCompiler",
    "compile_token_steering",
]


@dataclass
class TokenSteeringSpec:
    forbidden_phrases: List[str] = field(default_factory=list)
    logit_bias: Dict[int, float] = field(default_factory=dict)
    stop_sequences: List[str] = field(default_factory=list)
    assistant_prefill: str = ""
    temperature_cap: float = 0.7
    response_format: Optional[Dict[str, str]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "forbidden_phrases": list(self.forbidden_phrases),
            "logit_bias": dict(self.logit_bias),
            "stop_sequences": list(self.stop_sequences),
            "assistant_prefill": self.assistant_prefill,
            "temperature_cap": self.temperature_cap,
            "response_format": self.response_format,
        }


def compile_token_steering(
    system_text: str,
    *,
    tokenizer_encode: Optional[Callable[[str], Sequence[int]]] = None,
) -> TokenSteeringSpec:
    s = system_text or ""
    low = s.lower()
    forbidden: List[str] = []

    # Extract quoted strings after negative verbs
    for line in s.splitlines():
        if re.search(r"\b(?:never|do\s+not|don't|forbid|ban|avoid)\b", line, re.I):
            for m in re.finditer(r"['\"]([^'\"]{2,40})['\"]", line):
                lit = m.group(1).strip()
                if lit and lit not in forbidden:
                    forbidden.append(lit)

    stops = ["</developer_config>", "</system_instructions>"]
    if re.search(r"\b(?:never\s+use\s+horizontal\s+rules?|no\s+horizontal\s+rules?)\b", low):
        stops.append("\n---\n")

    prefill = ""
    resp_fmt = None
    temp = 0.5
    if re.search(r"\b(?:only\s+(?:valid\s+)?json|json\s+only|respond\s+in\s+json)\b", low):
        prefill = "{"
        resp_fmt = {"type": "json_object"}
        temp = 0.1
    elif re.search(r"\b(?:python\s+code\s+only|only\s+python\s+code)\b", low):
        prefill = "```python\n"
        temp = 0.1

    bias: Dict[int, float] = {}
    if callable(tokenizer_encode):
        for phrase in forbidden:
            try:
                tok_ids = list(tokenizer_encode(phrase))
                if tok_ids:
                    bias[int(tok_ids[0])] = -100.0
            except Exception:
                pass

    return TokenSteeringSpec(
        forbidden_phrases=forbidden,
        logit_bias=bias,
        stop_sequences=stops,
        assistant_prefill=prefill,
        temperature_cap=temp,
        response_format=resp_fmt,
    )


class TokenSteeringCompiler:
    def compile(self, system_text: str, *, tokenizer_encode: Optional[Callable[[str], Sequence[int]]] = None) -> TokenSteeringSpec:
        return compile_token_steering(system_text, tokenizer_encode=tokenizer_encode)


def _self_test() -> int:
    prompt = (
        'Never say "delve" or "synergistic".\n'
        "Never use horizontal rules.\n"
        "Respond in JSON only."
    )
    spec = compile_token_steering(prompt, tokenizer_encode=lambda w: [sum(ord(c) for c in w)])
    assert "delve" in spec.forbidden_phrases and "synergistic" in spec.forbidden_phrases
    assert "\n---\n" in spec.stop_sequences
    assert spec.assistant_prefill == "{"
    assert spec.response_format == {"type": "json_object"}
    assert len(spec.logit_bias) == 2 and all(v == -100.0 for v in spec.logit_bias.values())

    print("tokensteer._self_test: OK PASS (logit_bias, stop sequences, JSON prefill, temperature cap)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
