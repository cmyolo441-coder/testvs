"""citationguard — Claim-Source Grounding, URL Specificity & Anti-Hallucination Verifier.

Audits Markdown hyperlinks `[Anchor](URL)` and citations in responses:
  1. Bare Homepage Detection: flags generic root URLs (`https://example.com/`
     with no path or query) when a specific entity page is required.
  2. Bracketed Number Citation Ban: flags academic-style `[1]`, `[2]` citations
     when inline clickable `[Entity](URL)` links are mandated.
  3. Placeholder / Fabricated Domain Detection: flags `example.com`, `url_here`,
     `link_to_source`, `http://localhost` in external citations.
  4. Shared URL Reuse Detection: flags when 3+ distinct entities reuse the
     exact same URL.

Self-test: ``python3 -m fullagent.enforcex.citationguard``
"""

from __future__ import annotations

import re
import urllib.parse
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

__all__ = [
    "LinkRecord",
    "GroundingVerificationReport",
    "CitationGroundingEngine",
    "audit_citations",
]

_MD_LINK_RE = re.compile(r"\[([^\[\]]+)\]\(([^()\s]+)\)")
_BRACKET_CITE_RE = re.compile(r"(?<!\!)\[\d{1,3}\](?!\()")
_PLACEHOLDER_DOMAINS = {"example.com", "www.example.com", "domain.com", "yoursite.com", "url", "link"}


@dataclass
class LinkRecord:
    anchor: str
    url: str
    domain: str
    is_bare_homepage: bool = False
    is_placeholder: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "anchor": self.anchor,
            "url": self.url,
            "domain": self.domain,
            "is_bare_homepage": self.is_bare_homepage,
            "is_placeholder": self.is_placeholder,
        }


@dataclass
class GroundingVerificationReport:
    passed: bool = True
    score: float = 100.0
    links: List[LinkRecord] = field(default_factory=list)
    bracket_citations: List[str] = field(default_factory=list)
    violations: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "score": round(self.score, 2),
            "links_count": len(self.links),
            "links": [l.to_dict() for l in self.links],
            "bracket_citations": list(self.bracket_citations),
            "violations_count": len(self.violations),
            "violations": list(self.violations),
        }


def audit_citations(text: str) -> GroundingVerificationReport:
    s = text or ""
    links: List[LinkRecord] = []
    violations: List[Dict[str, Any]] = []
    url_anchors: Dict[str, List[str]] = {}

    for m in _MD_LINK_RE.finditer(s):
        anchor, url = m.group(1).strip(), m.group(2).strip()
        parsed = urllib.parse.urlparse(url)
        domain = (parsed.hostname or "").lower()
        path = parsed.path or ""
        is_bare = bool(domain and path in ("", "/") and not parsed.query and not parsed.fragment)
        is_ph = domain in _PLACEHOLDER_DOMAINS or url.lower() in ("url", "link", "#")

        rec = LinkRecord(
            anchor=anchor,
            url=url,
            domain=domain,
            is_bare_homepage=is_bare,
            is_placeholder=is_ph,
        )
        links.append(rec)
        url_anchors.setdefault(url, []).append(anchor.lower())

        if is_bare:
            violations.append({
                "rule_id": "CITE-BARE-HOMEPAGE",
                "category": "citation_specificity",
                "severity": "medium",
                "evidence": f"[{anchor}]({url})",
                "message": f"Bare homepage URL '{url}' used for '{anchor}'; link to the dedicated entity page.",
            })
        if is_ph:
            violations.append({
                "rule_id": "CITE-PLACEHOLDER-URL",
                "category": "citation_fabrication",
                "severity": "high",
                "evidence": f"[{anchor}]({url})",
                "message": f"Placeholder or fabricated URL '{url}' detected.",
            })

    # Check bracketed [1] citations
    b_cites = _BRACKET_CITE_RE.findall(s)
    if b_cites:
        violations.append({
            "rule_id": "CITE-BRACKET-NUMBER",
            "category": "citation_format",
            "severity": "medium",
            "evidence": ", ".join(b_cites[:5]),
            "message": "Bracketed numeric citations like [1] are forbidden; use inline clickable [Entity](URL) links.",
        })

    # Check excessive URL reuse across distinct entity anchors
    for url, anchors in url_anchors.items():
        if len(set(anchors)) >= 3:
            violations.append({
                "rule_id": "CITE-SHARED-URL",
                "category": "citation_specificity",
                "severity": "low",
                "evidence": f"{url} -> {sorted(set(anchors))}",
                "message": f"Single URL '{url}' reused across {len(set(anchors))} distinct entities.",
            })

    score = max(0.0, 100.0 - 20.0 * len(violations))
    return GroundingVerificationReport(
        passed=(len(violations) == 0),
        score=score,
        links=links,
        bracket_citations=b_cites,
        violations=violations,
    )


class CitationGroundingEngine:
    def evaluate(self, text: str) -> GroundingVerificationReport:
        return audit_citations(text)


def _self_test() -> int:
    good = "Check out [Python AST Docs](https://docs.python.org/3/library/ast.html) for details."
    r_ok = audit_citations(good)
    assert r_ok.passed and len(r_ok.links) == 1, r_ok.to_dict()

    bad = "See [Vendor](https://vendor.io/) and [Docs](https://example.com/doc) [1]."
    r_bad = audit_citations(bad)
    assert not r_bad.passed
    rids = {v["rule_id"] for v in r_bad.violations}
    assert "CITE-BARE-HOMEPAGE" in rids
    assert "CITE-PLACEHOLDER-URL" in rids
    assert "CITE-BRACKET-NUMBER" in rids

    print("citationguard._self_test: OK PASS (bare homepage, placeholder URL, [1] bracket detector)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
