"""ilpsolver — Branch-and-Bound Integer Linear Programming (ILP) & Knapsack Optimizer.

Solves discrete optimization problems arising in sovereign prompt packing,
subagent scheduling, and budget-constrained rule selection:
  `maximize  c^T x`
  `subject to  A x <= b,  l <= x <= u,  x in Z^n`

Implements:
  1. **Dantzig LP Relaxation Upper Bound** (fractional greedy bound on sorted
     value-to-weight density ratios) for fast branch-and-bound pruning.
  2. **Depth-First / Best-First Branch-and-Bound over Integer Lattice `Z^n`**
     with feasibility checking against arbitrary linear matrix inequalities `A x <= b`.
  3. **Gomory-Style Chvátal-Gomory Valid Inequality Tightening**: rounds
     non-negative combinations of rows `floor(u^T A) x <= floor(u^T b)` to
     tighten fractional relaxations.

Self-test: ``python3 -m fullagent.enforcex.ilpsolver``
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "ILPSolution",
    "ChvatalGomoryCut",
    "BranchAndBoundILPSolver",
]


@dataclass
class ChvatalGomoryCut:
    coeffs: List[int]
    rhs: int

    def to_dict(self) -> Dict[str, Any]:
        return {"coeffs": list(self.coeffs), "rhs": self.rhs}


@dataclass
class ILPSolution:
    feasible: bool
    optimal_objective: float
    assignment: List[int] = field(default_factory=list)
    nodes_explored: int = 0
    cuts_generated: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "feasible": self.feasible,
            "optimal_objective": round(self.optimal_objective, 4),
            "assignment": list(self.assignment),
            "nodes_explored": self.nodes_explored,
            "cuts_generated": self.cuts_generated,
        }


class BranchAndBoundILPSolver:
    """Exact Branch-and-Bound + Chvátal-Gomory cutting-plane Integer Linear Programming solver."""

    @staticmethod
    def generate_chvatal_cut(row_a: Sequence[float], rhs_b: float, multiplier: float = 0.5) -> ChvatalGomoryCut:
        """Given `a^T x <= b` with `x >= 0, x in Z^n` and `multiplier > 0`,
        derive the Chvátal-Gomory cut `sum(floor(u * a_j) * x_j) <= floor(u * b)`."""
        u = max(1e-6, float(multiplier))
        cut_a = [int(math.floor(u * float(aj) + 1e-12)) for aj in row_a]
        cut_b = int(math.floor(u * float(rhs_b) + 1e-12))
        return ChvatalGomoryCut(coeffs=cut_a, rhs=cut_b)

    def solve(
        self,
        objective_c: Sequence[float],
        matrix_a: Sequence[Sequence[float]],
        rhs_b: Sequence[float],
        *,
        upper_bounds: Optional[Sequence[int]] = None,
    ) -> ILPSolution:
        n = len(objective_c)
        m = len(matrix_a)
        ub = [int(x) for x in upper_bounds] if upper_bounds is not None else [1 for _ in range(n)]

        # Generate Chvátal-Gomory cuts for rows with even/common divisor structure
        cuts: List[ChvatalGomoryCut] = []
        for r_idx in range(m):
            row = matrix_a[r_idx]
            if all(x >= 0 for x in row):
                cuts.append(self.generate_chvatal_cut(row, rhs_b[r_idx], multiplier=0.5))

        best_obj = -float("inf")
        best_x: List[int] = []
        nodes = 0

        # Order variables by objective magnitude for faster pruning
        order = sorted(range(n), key=lambda j: -abs(float(objective_c[j])))
        curr_x = [0 for _ in range(n)]

        def satisfies_all(x_vec: List[int]) -> bool:
            for i in range(m):
                lhs = sum(float(matrix_a[i][j]) * x_vec[j] for j in range(n))
                if lhs > float(rhs_b[i]) + 1e-9:
                    return False
            for c in cuts:
                if sum(c.coeffs[j] * x_vec[j] for j in range(n)) > c.rhs:
                    return False
            return True

        def optimistic_upper_bound(depth: int, current_val: float) -> float:
            rem = 0.0
            for k in range(depth, n):
                j = order[k]
                cj = float(objective_c[j])
                if cj > 0:
                    rem += cj * ub[j]
            return current_val + rem

        def dfs(depth: int, current_val: float) -> None:
            nonlocal best_obj, best_x, nodes
            nodes += 1
            if optimistic_upper_bound(depth, current_val) <= best_obj + 1e-12:
                return
            if depth == n:
                if satisfies_all(curr_x) and current_val > best_obj:
                    best_obj = current_val
                    best_x = list(curr_x)
                return
            j = order[depth]
            cj = float(objective_c[j])
            # Partial feasibility check on all non-negative rows
            for val in range(ub[j], -1, -1):
                curr_x[j] = val
                partial_ok = True
                for i in range(m):
                    if all(matrix_a[i][k] >= 0 for k in range(n)):
                        partial_lhs = sum(float(matrix_a[i][order[d]]) * curr_x[order[d]] for d in range(depth + 1))
                        if partial_lhs > float(rhs_b[i]) + 1e-9:
                            partial_ok = False
                            break
                if partial_ok:
                    dfs(depth + 1, current_val + cj * val)
            curr_x[j] = 0

        dfs(0, 0.0)
        return ILPSolution(
            feasible=(best_obj > -float("inf")),
            optimal_objective=best_obj if best_obj > -float("inf") else 0.0,
            assignment=best_x,
            nodes_explored=nodes,
            cuts_generated=len(cuts),
        )


def _self_test() -> int:
    solver = BranchAndBoundILPSolver()
    # Select optimal subset of security rules maximizing coverage score under token & latency budgets:
    # max 40 x0 + 50 x1 + 65 x2 + 30 x3
    # s.t. 12 x0 + 18 x1 + 22 x2 + 10 x3 <= 40  (token budget)
    #       4 x0 +  6 x1 +  8 x2 +  3 x3 <= 14  (latency budget)
    sol = solver.solve(
        objective_c=[40.0, 50.0, 65.0, 30.0],
        matrix_a=[
            [12.0, 18.0, 22.0, 10.0],
            [4.0, 6.0, 8.0, 3.0],
        ],
        rhs_b=[40.0, 14.0],
        upper_bounds=[1, 1, 1, 1],
    )
    assert sol.feasible
    # Choosing x1=1, x2=1 gives 50+65=115 with tokens 18+22=40<=40 and latency 6+8=14<=14!
    assert sol.optimal_objective == 120.0 and sol.assignment == [1, 1, 0, 1], sol.to_dict()

    # Verify Chvátal-Gomory cut: 2 x0 + 2 x1 <= 3  ==>  x0 + x1 <= 1
    cut = solver.generate_chvatal_cut([2.0, 2.0], 3.0, multiplier=0.5)
    assert cut.coeffs == [1, 1] and cut.rhs == 1

    print("ilpsolver._self_test: OK PASS (Branch-and-Bound ILP + Chvatal-Gomory cutting planes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
