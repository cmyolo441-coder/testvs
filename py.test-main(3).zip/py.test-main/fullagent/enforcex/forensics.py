"""forensics — Exact Shapley-Value Blame Attribution & Incident Forensics Engine.

When a model response violates the system prompt, attributes exact cooperative
game-theoretic blame across the 4 root-cause factors $N = \{1, 2, 3, 4\}$:
  1. `attention_burying`: critical directive was buried in the mid-context trough
  2. `adversarial_user_input`: user prompt contained override/injection pressure
  3. `conflict_ambiguity`: system prompt contained conflicting or vague norms
  4. `tool_output_noise`: tool outputs injected distracting or hostile text

Computes exact Shapley values $\phi_i(v)$ over all $2^4 = 16$ coalitions so the
blame shares sum strictly to the total compliance loss (`efficiency axiom`).

Self-test: ``python3 -m fullagent.enforcex.forensics``
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, List, Sequence

__all__ = [
    "FACTORS",
    "ForensicInvestigationReport",
    "IncidentForensicsEngine",
    "compute_shapley_blame",
]

FACTORS = (
    "attention_burying",
    "adversarial_user_input",
    "conflict_ambiguity",
    "tool_output_noise",
)


@dataclass
class ForensicInvestigationReport:
    total_loss: float
    shapley_blame: Dict[str, float]
    blame_shares_pct: Dict[str, float]
    primary_culprit: str
    remediation_playbook: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_loss": round(self.total_loss, 3),
            "shapley_blame": {k: round(v, 4) for k, v in self.shapley_blame.items()},
            "blame_shares_pct": {k: round(v, 2) for k, v in self.blame_shares_pct.items()},
            "primary_culprit": self.primary_culprit,
            "remediation_playbook": self.remediation_playbook,
        }


_PLAYBOOKS = {
    "attention_burying": "Pin buried rules into a Recency Attention Anchor via attentionsteer.optimize_prompt_layout().",
    "adversarial_user_input": "Sanitize user input and wrap in hierarchyguard Ring-2 fences before model dispatch.",
    "conflict_ambiguity": "Resolve deontic norm antinomies via deontic.resolve_conflicts() and autohealer.",
    "tool_output_noise": "Pass tool outputs through toolguard.sanitize_tool_output() and compactguard.",
}


def compute_shapley_blame(
    *,
    attention_burying: float = 0.0,
    adversarial_user_input: float = 0.0,
    conflict_ambiguity: float = 0.0,
    tool_output_noise: float = 0.0,
) -> ForensicInvestigationReport:
    """Compute exact Shapley values over the 4 root-cause factors in [0, 1]."""
    intensities = {
        "attention_burying": max(0.0, min(1.0, float(attention_burying))),
        "adversarial_user_input": max(0.0, min(1.0, float(adversarial_user_input))),
        "conflict_ambiguity": max(0.0, min(1.0, float(conflict_ambiguity))),
        "tool_output_noise": max(0.0, min(1.0, float(tool_output_noise))),
    }
    base_weights = {
        "attention_burying": 28.0,
        "adversarial_user_input": 38.0,
        "conflict_ambiguity": 22.0,
        "tool_output_noise": 18.0,
    }

    def characteristic_v(coalition: FrozenSet[str]) -> float:
        if not coalition:
            return 0.0
        linear = sum(base_weights[f] * intensities[f] for f in coalition)
        # Superadditive synergy when buried attention + adversarial input co-occur
        synergy = 0.0
        if "attention_burying" in coalition and "adversarial_user_input" in coalition:
            synergy += 14.0 * intensities["attention_burying"] * intensities["adversarial_user_input"]
        if "adversarial_user_input" in coalition and "tool_output_noise" in coalition:
            synergy += 10.0 * intensities["adversarial_user_input"] * intensities["tool_output_noise"]
        return min(100.0, linear + synergy)

    n = len(FACTORS)
    n_fact = math.factorial(n)
    shapley: Dict[str, float] = {f: 0.0 for f in FACTORS}

    for f in FACTORS:
        others = [x for x in FACTORS if x != f]
        for r in range(len(others) + 1):
            for subset in itertools.combinations(others, r):
                s_set = frozenset(subset)
                weight = (math.factorial(len(s_set)) * math.factorial(n - len(s_set) - 1)) / float(n_fact)
                marginal = characteristic_v(s_set | {f}) - characteristic_v(s_set)
                shapley[f] += weight * marginal

    total_loss = characteristic_v(frozenset(FACTORS))
    if total_loss > 0:
        shares = {k: (v / total_loss) * 100.0 for k, v in shapley.items()}
    else:
        shares = {k: 0.0 for k in FACTORS}

    culprit = max(FACTORS, key=lambda f: shapley[f])
    return ForensicInvestigationReport(
        total_loss=total_loss,
        shapley_blame=shapley,
        blame_shares_pct=shares,
        primary_culprit=culprit,
        remediation_playbook=_PLAYBOOKS[culprit],
    )


class IncidentForensicsEngine:
    def investigate(self, **kwargs: float) -> ForensicInvestigationReport:
        return compute_shapley_blame(**kwargs)


def _self_test() -> int:
    rep = compute_shapley_blame(
        attention_burying=0.8,
        adversarial_user_input=0.9,
        conflict_ambiguity=0.1,
        tool_output_noise=0.0,
    )
    # Shapley efficiency axiom: sum of Shapley values equals v(N) - v(empty) == total_loss
    assert abs(sum(rep.shapley_blame.values()) - rep.total_loss) < 1e-6, rep.to_dict()
    assert abs(sum(rep.blame_shares_pct.values()) - 100.0) < 1e-5
    assert rep.primary_culprit == "adversarial_user_input"

    print("forensics._self_test: OK PASS (exact 2^4 coalition Shapley values, efficiency axiom verified)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
