"""satisolver — DPLL Boolean Satisfiability (SAT), MaxSAT & Minimal Unsatisfiable Core Solver.

Implements a real Davis-Putnam-Logemann-Loveland (DPLL) SAT solver with:
  * Unit Propagation (`_unit_propagate`)
  * Pure Literal Elimination (`_pure_literal_assign`)
  * Weighted MaxSAT branch-and-bound solver (finds the assignment that
    maximizes total satisfied clause weight when hard + soft rules conflict)
  * Deletion-based Minimal Unsatisfiable Subset (MUS) extractor to pinpoint
    the exact minimal set of mutually contradictory rules in a system prompt.

Self-test: ``python3 -m fullagent.enforcex.satisolver``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, FrozenSet, Iterable, List, Optional, Sequence, Set, Tuple

__all__ = [
    "CNFClause",
    "SATComplianceResult",
    "MaxSATSolver",
    "dpll_solve",
    "extract_mus",
    "solve_maxsat",
]

# A literal is an int: +k means variable k is True, -k means variable k is False.


@dataclass(frozen=True)
class CNFClause:
    clause_id: str
    literals: Tuple[int, ...]
    weight: float = 1.0
    hard: bool = True
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "clause_id": self.clause_id,
            "literals": list(self.literals),
            "weight": self.weight,
            "hard": self.hard,
            "description": self.description,
        }


@dataclass
class SATComplianceResult:
    satisfiable: bool = True
    assignment: Dict[int, bool] = field(default_factory=dict)
    satisfied_weight: float = 0.0
    total_weight: float = 0.0
    violated_clauses: List[str] = field(default_factory=list)
    unsat_core: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "satisfiable": self.satisfiable,
            "assignment": dict(self.assignment),
            "satisfied_weight": round(self.satisfied_weight, 3),
            "total_weight": round(self.total_weight, 3),
            "violated_clauses": list(self.violated_clauses),
            "unsat_core": list(self.unsat_core),
        }


def _simplify_clauses(clauses: List[Tuple[int, ...]], lit: int) -> Optional[List[Tuple[int, ...]]]:
    """Assign `lit = True` and simplify `clauses`. Returns None if an empty clause is produced."""
    neg = -lit
    out: List[Tuple[int, ...]] = []
    for c in clauses:
        if lit in c:
            continue  # Clause satisfied
        if neg in c:
            rem = tuple(x for x in c if x != neg)
            if not rem:
                return None  # Conflict (empty clause)
            out.append(rem)
        else:
            out.append(c)
    return out


def dpll_solve(
    clauses: Sequence[Sequence[int]],
    assignment: Optional[Dict[int, bool]] = None,
) -> Optional[Dict[int, bool]]:
    """Real recursive DPLL SAT solver with unit propagation and pure-literal elimination."""
    work: List[Tuple[int, ...]] = [tuple(c) for c in clauses]
    assign: Dict[int, bool] = dict(assignment) if assignment else {}

    # 1. Unit propagation loop
    while True:
        if any(len(c) == 0 for c in work):
            return None
        unit_lits = [c[0] for c in work if len(c) == 1]
        if not unit_lits:
            break
        lit = unit_lits[0]
        var = abs(lit)
        val = lit > 0
        if var in assign and assign[var] != val:
            return None
        assign[var] = val
        simplified = _simplify_clauses(work, lit)
        if simplified is None:
            return None
        work = simplified

    if not work:
        return assign

    # 2. Pure literal elimination
    all_lits: Set[int] = {x for c in work for x in c}
    pure_lits = [x for x in all_lits if -x not in all_lits]
    for lit in pure_lits:
        assign[abs(lit)] = (lit > 0)
        simplified = _simplify_clauses(work, lit)
        if simplified is None:
            return None
        work = simplified
    if not work:
        return assign

    # 3. Choose branching variable (most frequent literal heuristic - DLIS lite)
    counts: Dict[int, int] = {}
    for c in work:
        for x in c:
            counts[x] = counts.get(x, 0) + 1
    best_lit = max(counts, key=lambda k: counts[k])

    for choice in (best_lit, -best_lit):
        next_clauses = _simplify_clauses(work, choice)
        if next_clauses is not None:
            next_assign = dict(assign)
            next_assign[abs(choice)] = (choice > 0)
            res = dpll_solve(next_clauses, next_assign)
            if res is not None:
                return res
    return None


def extract_mus(clauses: Sequence[CNFClause]) -> List[str]:
    """Extract a Minimal Unsatisfiable Subset (MUS) of clause IDs using deletion-based reduction."""
    c_list = list(clauses or [])
    if dpll_solve([c.literals for c in c_list]) is not None:
        return []  # Satisfiable -> no UNSAT core

    core = list(c_list)
    i = 0
    while i < len(core):
        candidate = core[:i] + core[i + 1:]
        if candidate and dpll_solve([c.literals for c in candidate]) is None:
            # Clause i is redundant for unsatisfiability; drop it
            core = candidate
        else:
            i += 1
    return [c.clause_id for c in core]


def solve_maxsat(clauses: Sequence[CNFClause]) -> SATComplianceResult:
    """Solve weighted MaxSAT over CNFClauses, returning the optimal assignment and MUS if UNSAT."""
    c_list = list(clauses or [])
    total_w = sum(c.weight for c in c_list)
    if not c_list:
        return SATComplianceResult(satisfiable=True, total_weight=0.0)

    # First try exact DPLL on all clauses
    exact = dpll_solve([c.literals for c in c_list])
    if exact is not None:
        return SATComplianceResult(
            satisfiable=True,
            assignment=exact,
            satisfied_weight=total_w,
            total_weight=total_w,
        )

    # UNSAT: extract minimal unsatisfiable core and find max-weight assignment
    mus = extract_mus(c_list)
    vars_all = sorted({abs(x) for c in c_list for x in c.literals})[:16]
    best_w = -1.0
    best_assign: Dict[int, bool] = {}
    best_violated: List[str] = []

    n = len(vars_all)
    for mask in range(1 << n):
        cand = {vars_all[b]: bool((mask >> b) & 1) for b in range(n)}
        # Check hard clauses if possible
        sat_w = 0.0
        viol: List[str] = []
        for c in c_list:
            clause_sat = any(
                (lit > 0 and cand.get(abs(lit), False)) or (lit < 0 and not cand.get(abs(lit), False))
                for lit in c.literals
            )
            if clause_sat:
                sat_w += c.weight
            else:
                viol.append(c.clause_id)
        if sat_w > best_w:
            best_w = sat_w
            best_assign = cand
            best_violated = viol

    return SATComplianceResult(
        satisfiable=False,
        assignment=best_assign,
        satisfied_weight=max(0.0, best_w),
        total_weight=total_w,
        violated_clauses=best_violated,
        unsat_core=mus,
    )


class MaxSATSolver:
    def solve(self, clauses: Sequence[CNFClause]) -> SATComplianceResult:
        return solve_maxsat(clauses)


def _self_test() -> int:
    # 1. Satisfiable formula: (x1 | x2) & (~x1 | x3) & (~x2 | x3)
    sat_clauses = [
        CNFClause("C1", (1, 2), weight=2.0),
        CNFClause("C2", (-1, 3), weight=2.0),
        CNFClause("C3", (-2, 3), weight=2.0),
    ]
    res_sat = solve_maxsat(sat_clauses)
    assert res_sat.satisfiable and res_sat.satisfied_weight == 6.0, res_sat.to_dict()
    assert res_sat.assignment[3] is True

    # 2. Unsatisfiable formula with extra irrelevant clause -> MUS isolates exact conflict
    unsat_clauses = [
        CNFClause("R1_JSON", (1,), weight=5.0, description="Must be JSON"),
        CNFClause("R2_NO_JSON", (-1,), weight=1.0, description="Never use JSON"),
        CNFClause("R3_POLITE", (2,), weight=3.0, description="Be polite"),
    ]
    res_unsat = solve_maxsat(unsat_clauses)
    assert not res_unsat.satisfiable
    assert set(res_unsat.unsat_core) == {"R1_JSON", "R2_NO_JSON"}, res_unsat.to_dict()
    # MaxSAT satisfies R1_JSON (w=5) + R3_POLITE (w=3) = 8.0, violating only R2_NO_JSON (w=1)
    assert res_unsat.satisfied_weight == 8.0
    assert res_unsat.violated_clauses == ["R2_NO_JSON"]

    print("satisolver._self_test: OK PASS (DPLL unit propagation, MaxSAT optimization, MUS extraction)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
