"""fuzzyguard — Gödel, Łukasiewicz & Product T-Norm Continuous Fuzzy Logic Engine.

Evaluates graduated, multi-dimensional system-prompt constraints (such as
"keep paragraphs reasonably short", "maintain high lexical density", "avoid
excessive hedging") over `[0.0, 1.0]` truth degrees using the three fundamental
continuous t-norms (Hájek, "Metamathematics of Fuzzy Logic"):
  1. Łukasiewicz Logic:
     - T-norm:   `T_L(a, b) = max(0, a + b - 1)`
     - T-conorm: `S_L(a, b) = min(1, a + b)`
     - Residuum: `I_L(a, b) = min(1, 1 - a + b)`
  2. Gödel-Dummett Logic:
     - T-norm:   `T_G(a, b) = min(a, b)`
     - T-conorm: `S_G(a, b) = max(a, b)`
     - Residuum: `I_G(a, b) = 1.0 if a <= b else b`
  3. Product (Goguen) Logic:
     - T-norm:   `T_P(a, b) = a * b`
     - T-conorm: `S_P(a, b) = a + b - a * b`
     - Residuum: `I_P(a, b) = 1.0 if a <= b else b / a`

Also provides trapezoidal membership functions and Mamdani centroid defuzzification.

Self-test: ``python3 -m fullagent.enforcex.fuzzyguard``
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence, Tuple

__all__ = [
    "TrapezoidalFuzzySet",
    "FuzzyEvaluationReport",
    "FuzzyLogicEngine",
    "lukasiewicz_tnorm",
    "lukasiewicz_residuum",
    "godel_tnorm",
    "godel_residuum",
    "product_tnorm",
    "product_residuum",
]


def _clamp01(x: float) -> float:
    return max(0.0, min(1.0, float(x)))


def lukasiewicz_tnorm(a: float, b: float) -> float:
    return _clamp01(_clamp01(a) + _clamp01(b) - 1.0)


def lukasiewicz_tconorm(a: float, b: float) -> float:
    return _clamp01(_clamp01(a) + _clamp01(b))


def lukasiewicz_residuum(a: float, b: float) -> float:
    return _clamp01(1.0 - _clamp01(a) + _clamp01(b))


def godel_tnorm(a: float, b: float) -> float:
    return min(_clamp01(a), _clamp01(b))


def godel_tconorm(a: float, b: float) -> float:
    return max(_clamp01(a), _clamp01(b))


def godel_residuum(a: float, b: float) -> float:
    aa, bb = _clamp01(a), _clamp01(b)
    return 1.0 if aa <= bb else bb


def product_tnorm(a: float, b: float) -> float:
    return _clamp01(a) * _clamp01(b)


def product_tconorm(a: float, b: float) -> float:
    aa, bb = _clamp01(a), _clamp01(b)
    return _clamp01(aa + bb - aa * bb)


def product_residuum(a: float, b: float) -> float:
    aa, bb = _clamp01(a), _clamp01(b)
    return 1.0 if aa <= bb or aa <= 1e-12 else _clamp01(bb / aa)


@dataclass(frozen=True)
class TrapezoidalFuzzySet:
    """Trapezoidal membership function `(a <= b <= c <= d)`."""
    name: str
    a: float
    b: float
    c: float
    d: float

    def membership(self, x: float) -> float:
        val = float(x)
        if val <= self.a or val >= self.d:
            if val == self.a == self.b:
                return 1.0
            if val == self.c == self.d:
                return 1.0
            return 0.0
        if self.b <= val <= self.c:
            return 1.0
        if val < self.b:
            return (val - self.a) / max(1e-12, self.b - self.a)
        return (self.d - val) / max(1e-12, self.d - self.c)


@dataclass
class FuzzyEvaluationReport:
    lukasiewicz_truth: float
    godel_truth: float
    product_truth: float
    centroid_score: float
    clause_degrees: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "lukasiewicz_truth": round(self.lukasiewicz_truth, 4),
            "godel_truth": round(self.godel_truth, 4),
            "product_truth": round(self.product_truth, 4),
            "centroid_score": round(self.centroid_score, 2),
            "clause_degrees": {k: round(v, 4) for k, v in self.clause_degrees.items()},
        }


class FuzzyLogicEngine:
    """Multi-t-norm fuzzy evaluator and Mamdani centroid defuzzifier."""

    def __init__(self) -> None:
        self.concise_set = TrapezoidalFuzzySet("concise_words", 5.0, 15.0, 180.0, 320.0)
        self.lexical_density_set = TrapezoidalFuzzySet("lexical_density", 0.30, 0.48, 1.00, 1.00)

    @staticmethod
    def centroid_defuzzify(samples: Sequence[Tuple[float, float]]) -> float:
        """Compute center of gravity `sum(x_i * mu_i) / sum(mu_i)`."""
        num = sum(float(x) * max(0.0, float(mu)) for x, mu in samples)
        den = sum(max(0.0, float(mu)) for _, mu in samples)
        return num / den if den > 1e-12 else 0.0

    def evaluate_response(self, response_text: str) -> FuzzyEvaluationReport:
        words = [w.lower().strip(".,:;!?()[]{}") for w in (response_text or "").split() if w.strip()]
        w_count = len(words)
        unique_ratio = len(set(words)) / max(1.0, float(w_count))

        deg_concise = self.concise_set.membership(w_count)
        deg_density = self.lexical_density_set.membership(unique_ratio)
        deg_fence_balanced = 1.0 if (response_text or "").count("```") % 2 == 0 else 0.2

        degrees = {
            "conciseness": deg_concise,
            "lexical_density": deg_density,
            "fence_balance": deg_fence_balanced,
        }
        vals = list(degrees.values())

        t_luk = vals[0]
        t_god = vals[0]
        t_prd = vals[0]
        for v in vals[1:]:
            t_luk = lukasiewicz_tnorm(t_luk, v)
            t_god = godel_tnorm(t_god, v)
            t_prd = product_tnorm(t_prd, v)

        centroid = self.centroid_defuzzify([
            (100.0, t_god),
            (90.0, t_prd),
            (80.0, t_luk),
            (20.0, 1.0 - t_god),
        ])
        return FuzzyEvaluationReport(
            lukasiewicz_truth=t_luk,
            godel_truth=t_god,
            product_truth=t_prd,
            centroid_score=centroid,
            clause_degrees=degrees,
        )


def _self_test() -> int:
    # Verify t-norm ordering: Lukasiewicz <= Product <= Godel for all a, b in [0, 1]
    for a in (0.2, 0.5, 0.8):
        for b in (0.3, 0.6, 0.9):
            tl = lukasiewicz_tnorm(a, b)
            tp = product_tnorm(a, b)
            tg = godel_tnorm(a, b)
            assert tl <= tp + 1e-12 <= tg + 2e-12, (a, b, tl, tp, tg)
            # Residuation adjunction property: T(a, c) <= b iff c <= I(a, b)
            res = lukasiewicz_residuum(a, b)
            assert lukasiewicz_tnorm(a, res) <= b + 1e-12

    eng = FuzzyLogicEngine()
    rep = eng.evaluate_response("Here is a clear, concise, well-structured explanation with rich vocabulary and zero unclosed blocks.")
    assert rep.godel_truth >= 0.8 and rep.centroid_score >= 80.0, rep.to_dict()

    print("fuzzyguard._self_test: OK PASS (Lukasiewicz/Godel/Product t-norms, residua adjunction, Mamdani centroid)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
