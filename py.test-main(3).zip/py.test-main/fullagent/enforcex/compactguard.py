"""compactguard — Lossless Directive-Preserving Context Compaction Engine.

Compacts long conversation histories to fit a target character/token budget
while guaranteeing that:
  1. `messages[0]` (the sealed system prompt) is preserved 100% intact.
  2. Every user constraint (`must`, `never`, `do not`, budgets `$...`, file paths,
     deadlines) from dropped turns is distilled into a `[PINNED USER CONSTRAINTS]`
     ledger so the model never forgets earlier requirements after compaction.
  3. Assistant tool_calls and their matching tool results are dropped only as
     complete atomic units (never creating orphan tool calls or responses).

Self-test: ``python3 -m fullagent.enforcex.compactguard``
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence

__all__ = [
    "CompactionIntegrityReport",
    "DirectiveCompactionGuard",
    "compact_preserving_directives",
]

_CONSTRAINT_RE = re.compile(
    r"([^.\n?!]*(?:\bmust\b|\bnever\b|\bdo\s+not\b|\bdon't\b|\balways\b|\bunder\s+\$\d+|\bdeadline\b|\bonly\b)[^.\n?!]*[.\n?!]?)",
    re.I,
)


@dataclass
class CompactionIntegrityReport:
    messages: List[Dict[str, Any]] = field(default_factory=list)
    pinned_constraints: List[str] = field(default_factory=list)
    chars_before: int = 0
    chars_after: int = 0
    system_intact: bool = True

    def to_dict(self) -> Dict[str, Any]:
        return {
            "messages_count": len(self.messages),
            "pinned_constraints": list(self.pinned_constraints),
            "chars_before": self.chars_before,
            "chars_after": self.chars_after,
            "system_intact": self.system_intact,
        }


def _extract_user_constraints(messages: Sequence[Dict[str, Any]]) -> List[str]:
    pinned: List[str] = []
    seen = set()
    for m in messages:
        if m.get("role") != "user":
            continue
        txt = str(m.get("content") or "")
        for match in _CONSTRAINT_RE.finditer(txt):
            c = re.sub(r"\s+", " ", match.group(1)).strip()
            if 10 <= len(c) <= 180 and c.lower() not in seen:
                seen.add(c.lower())
                pinned.append(c)
    return pinned[:20]


def compact_preserving_directives(
    messages: Sequence[Dict[str, Any]],
    *,
    max_chars: int = 8000,
    keep_recent_turns: int = 4,
) -> CompactionIntegrityReport:
    orig = [dict(m) for m in (messages or []) if isinstance(m, dict)]
    chars_before = sum(len(str(m.get("content") or "")) for m in orig)
    if not orig:
        return CompactionIntegrityReport()

    sys_msg = orig[0] if orig[0].get("role") == "system" else None
    body = orig[1:] if sys_msg else orig[:]

    # Group body into atomic user-turn units so tool_calls and tool results stay paired
    units: List[List[Dict[str, Any]]] = []
    cur_unit: List[Dict[str, Any]] = []
    for m in body:
        if m.get("role") == "user" and cur_unit:
            units.append(cur_unit)
            cur_unit = [m]
        else:
            cur_unit.append(m)
    if cur_unit:
        units.append(cur_unit)

    if chars_before <= max_chars or len(units) <= keep_recent_turns:
        return CompactionIntegrityReport(
            messages=orig,
            pinned_constraints=_extract_user_constraints(orig),
            chars_before=chars_before,
            chars_after=chars_before,
            system_intact=True,
        )

    dropped_units = units[:-keep_recent_turns]
    kept_units = units[-keep_recent_turns:]
    dropped_msgs = [m for u in dropped_units for m in u]
    pinned = _extract_user_constraints(dropped_msgs)

    out: List[Dict[str, Any]] = []
    if sys_msg is not None:
        new_sys = dict(sys_msg)
        if pinned:
            pin_block = "\n".join(f"  - {c}" for c in pinned)
            new_sys["content"] = (
                str(new_sys.get("content") or "").rstrip()
                + f"\n\n[PINNED USER CONSTRAINTS FROM EARLIER TURNS — STILL BINDING]\n{pin_block}"
            )
        out.append(new_sys)

    for u in kept_units:
        out.extend(u)

    chars_after = sum(len(str(m.get("content") or "")) for m in out)
    sys_intact = bool(sys_msg is None or str(sys_msg.get("content") or "") in str(out[0].get("content") or ""))
    return CompactionIntegrityReport(
        messages=out,
        pinned_constraints=pinned,
        chars_before=chars_before,
        chars_after=chars_after,
        system_intact=sys_intact,
    )


class DirectiveCompactionGuard:
    def compact(self, messages: Sequence[Dict[str, Any]], *, max_chars: int = 8000) -> CompactionIntegrityReport:
        return compact_preserving_directives(messages, max_chars=max_chars)


def _self_test() -> int:
    msgs = [{"role": "system", "content": "Sovereign System Prompt."}]
    msgs.append({"role": "user", "content": "You must never use external libraries and keep cost under $50."})
    msgs.append({"role": "assistant", "content": "Understood. " + ("detail " * 400)})
    for i in range(6):
        msgs.append({"role": "user", "content": f"Follow-up step {i}"})
        msgs.append({"role": "assistant", "content": f"Step {i} output " + ("x" * 300)})

    rep = compact_preserving_directives(msgs, max_chars=1500, keep_recent_turns=2)
    assert rep.system_intact and rep.chars_after < rep.chars_before, rep.to_dict()
    assert any("under $50" in c for c in rep.pinned_constraints)
    assert "under $50" in rep.messages[0]["content"]

    print("compactguard._self_test: OK PASS (atomic turn compaction, constraint pinning, system integrity)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
