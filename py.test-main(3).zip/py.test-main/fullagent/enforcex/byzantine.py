"""byzantine — $3f+1$ Byzantine Fault Tolerant (PBFT) Multi-Verifier Quorum Engine.

Adjudicates compliance verdicts across $N = 3f + 1$ verifier subagents where up
to $f$ verifiers may be Byzantine (faulty, compromised, equivocating, or
emitting extreme outlier scores):
  * Equivocation Detection & Slashing: if a verifier submits two conflicting
    votes for the same turn/sequence, both votes are discarded and the verifier
    is slashed into `slashed_verifiers`.
  * Byzantine Trimmed Median / Mean: sorts honest scores, trims the top $f$ and
    bottom $f$ extremes, and requires a $2f + 1$ supermajority quorum for finality.

Self-test: ``python3 -m fullagent.enforcex.byzantine``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Sequence, Set, Tuple

__all__ = [
    "VerifierVote",
    "BFTConsensusCertificate",
    "ByzantineQuorumEngine",
    "adjudicate_byzantine_quorum",
]


@dataclass(frozen=True)
class VerifierVote:
    verifier_id: str
    seq: int
    passed: bool
    score: float


@dataclass
class BFTConsensusCertificate:
    seq: int
    quorum_reached: bool
    passed: bool
    trimmed_score: float
    total_verifiers: int
    fault_tolerance_f: int
    quorum_size: int
    slashed_verifiers: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "seq": self.seq,
            "quorum_reached": self.quorum_reached,
            "passed": self.passed,
            "trimmed_score": round(self.trimmed_score, 2),
            "total_verifiers": self.total_verifiers,
            "fault_tolerance_f": self.fault_tolerance_f,
            "quorum_size": self.quorum_size,
            "slashed_verifiers": list(self.slashed_verifiers),
        }


def adjudicate_byzantine_quorum(votes: Sequence[VerifierVote], seq: int = 1) -> BFTConsensusCertificate:
    by_id: Dict[str, List[VerifierVote]] = {}
    for v in (votes or []):
        if v.seq == seq:
            by_id.setdefault(v.verifier_id, []).append(v)

    slashed: List[str] = []
    honest: List[VerifierVote] = []
    for vid, vlist in sorted(by_id.items()):
        # Equivocation check: multiple distinct votes for the same seq
        distinct = {(x.passed, round(x.score, 2)) for x in vlist}
        if len(distinct) > 1:
            slashed.append(vid)
        else:
            honest.append(vlist[0])

    n = len(honest)
    f = max(0, (n - 1) // 3)
    quorum_req = 2 * f + 1 if n >= 4 else max(1, (n // 2) + 1)

    if not honest:
        return BFTConsensusCertificate(
            seq=seq,
            quorum_reached=False,
            passed=False,
            trimmed_score=0.0,
            total_verifiers=0,
            fault_tolerance_f=0,
            quorum_size=1,
            slashed_verifiers=slashed,
        )

    pass_votes = sum(1 for v in honest if v.passed)
    fail_votes = n - pass_votes
    quorum_ok = (pass_votes >= quorum_req) or (fail_votes >= quorum_req)
    passed = pass_votes >= quorum_req

    # Byzantine trimmed mean: drop lowest f and highest f scores when n >= 2f + 1
    scores = sorted(max(0.0, min(100.0, float(v.score))) for v in honest)
    if f > 0 and len(scores) > 2 * f:
        trimmed = scores[f:len(scores) - f]
    else:
        trimmed = scores
    t_mean = sum(trimmed) / len(trimmed)

    return BFTConsensusCertificate(
        seq=seq,
        quorum_reached=quorum_ok,
        passed=passed,
        trimmed_score=t_mean,
        total_verifiers=n,
        fault_tolerance_f=f,
        quorum_size=quorum_req,
        slashed_verifiers=slashed,
    )


class ByzantineQuorumEngine:
    def adjudicate(self, votes: Sequence[VerifierVote], seq: int = 1) -> BFTConsensusCertificate:
        return adjudicate_byzantine_quorum(votes, seq=seq)


def _self_test() -> int:
    # 4 honest verifiers (score ~95, pass=True), 1 Byzantine liar (score=0, pass=False),
    # and 1 equivocating Byzantine node sending two conflicting votes
    votes = [
        VerifierVote("v1", 1, True, 96.0),
        VerifierVote("v2", 1, True, 94.0),
        VerifierVote("v3", 1, True, 95.0),
        VerifierVote("v4", 1, True, 95.0),
        VerifierVote("byz_liar", 1, False, 0.0),
        VerifierVote("byz_equiv", 1, True, 100.0),
        VerifierVote("byz_equiv", 1, False, 10.0),
    ]
    cert = adjudicate_byzantine_quorum(votes, seq=1)
    assert "byz_equiv" in cert.slashed_verifiers
    assert cert.quorum_reached and cert.passed
    # Trimmed mean drops the 0.0 outlier and the 96.0 top, averaging [94, 95, 95] = 94.67
    assert 94.0 <= cert.trimmed_score <= 96.0, cert.to_dict()

    print("byzantine._self_test: OK PASS (equivocation slashing, f-trimmed mean, 2f+1 PBFT finality)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
