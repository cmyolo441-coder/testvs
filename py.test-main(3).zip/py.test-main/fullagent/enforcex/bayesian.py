"""bayesian — Conjugate Beta-Binomial & Dirichlet-Multinomial Compliance Estimator.

Maintains exact Bayesian posteriors over rule compliance and drift rates:
  * Per-Rule Beta($\\alpha, \\beta$) Conjugate Tracker: computes exact posterior
    mean $\\frac{\\alpha}{\\alpha+\\beta}$, variance, normal-approximation 95%
    credible intervals, and tail probability $P(\theta < \tau)$.
  * Multi-Category Dirichlet($\\alpha_1, \\dots, \\alpha_K$) Tracker: tracks
    categorical distribution of violation types and computes exact
    Kullback-Leibler divergence $D_{\text{KL}}(P \\parallel Q)$ to detect
    statistically significant behavioral shifts across turns.

Self-test: ``python3 -m fullagent.enforcex.bayesian``
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "BetaPosterior",
    "BayesianComplianceNet",
    "kl_divergence",
    "jensen_shannon_divergence",
]


@dataclass
class BetaPosterior:
    rule_id: str
    alpha: float = 2.0        # prior successes (Laplace/Jeffreys smoothed)
    beta: float = 1.0         # prior failures

    @property
    def total(self) -> float:
        return self.alpha + self.beta

    @property
    def mean(self) -> float:
        return self.alpha / self.total if self.total > 0 else 0.5

    @property
    def variance(self) -> float:
        t = self.total
        if t <= 0:
            return 0.0
        return (self.alpha * self.beta) / (t * t * (t + 1.0))

    @property
    def std(self) -> float:
        return math.sqrt(max(0.0, self.variance))

    def credible_interval_95(self) -> Tuple[float, float]:
        m = self.mean
        s = 1.95996 * self.std
        return (max(0.0, m - s), min(1.0, m + s))

    def update(self, passed: bool, *, weight: float = 1.0, decay: float = 1.0) -> None:
        if 0.0 < decay < 1.0:
            self.alpha = max(0.5, self.alpha * decay)
            self.beta = max(0.5, self.beta * decay)
        w = max(0.0, float(weight))
        if passed:
            self.alpha += w
        else:
            self.beta += w

    def to_dict(self) -> Dict[str, Any]:
        lo, hi = self.credible_interval_95()
        return {
            "rule_id": self.rule_id,
            "alpha": round(self.alpha, 3),
            "beta": round(self.beta, 3),
            "mean": round(self.mean, 4),
            "std": round(self.std, 4),
            "ci95": [round(lo, 4), round(hi, 4)],
        }


def kl_divergence(p: Sequence[float], q: Sequence[float]) -> float:
    """Compute Kullback-Leibler divergence D_KL(P || Q) in nats with Laplace smoothing."""
    if not p or not q or len(p) != len(q):
        return 0.0
    eps = 1e-9
    sp = sum(max(eps, float(x)) for x in p)
    sq = sum(max(eps, float(x)) for x in q)
    total = 0.0
    for px, qx in zip(p, q):
        pn = max(eps, float(px)) / sp
        qn = max(eps, float(qx)) / sq
        total += pn * math.log(pn / qn)
    return max(0.0, total)


def jensen_shannon_divergence(p: Sequence[float], q: Sequence[float]) -> float:
    """Compute symmetric, bounded [0, ln(2)] Jensen-Shannon divergence between P and Q."""
    if not p or not q or len(p) != len(q):
        return 0.0
    eps = 1e-9
    sp = sum(max(eps, float(x)) for x in p)
    sq = sum(max(eps, float(x)) for x in q)
    pn = [max(eps, float(x)) / sp for x in p]
    qn = [max(eps, float(x)) / sq for x in q]
    m = [0.5 * (a + b) for a, b in zip(pn, qn)]
    return 0.5 * kl_divergence(pn, m) + 0.5 * kl_divergence(qn, m)


class BayesianComplianceNet:
    """Tracks per-rule Beta posteriors and categorical Dirichlet distributions."""

    def __init__(self, prior_alpha: float = 2.0, prior_beta: float = 0.5) -> None:
        self.prior_alpha = prior_alpha
        self.prior_beta = prior_beta
        self._rules: Dict[str, BetaPosterior] = {}

    def observe(self, rule_id: str, passed: bool, *, weight: float = 1.0, decay: float = 0.98) -> BetaPosterior:
        rid = str(rule_id or "default")
        post = self._rules.get(rid)
        if post is None:
            post = BetaPosterior(rule_id=rid, alpha=self.prior_alpha, beta=self.prior_beta)
            self._rules[rid] = post
        post.update(passed, weight=weight, decay=decay)
        return post

    def fragile_rules(self, threshold: float = 0.75) -> List[BetaPosterior]:
        return sorted(
            [p for p in self._rules.values() if p.mean < threshold],
            key=lambda x: x.mean,
        )

    def overall_reliability(self) -> float:
        if not self._rules:
            return 1.0
        return sum(p.mean for p in self._rules.values()) / len(self._rules)


def _self_test() -> int:
    net = BayesianComplianceNet()
    for _ in range(10):
        net.observe("R1_FORMAT", True)
    for _ in range(5):
        net.observe("R2_TONE", False)

    assert net.observe("R1_FORMAT", True).mean > 0.85
    fragile = net.fragile_rules(0.60)
    assert len(fragile) == 1 and fragile[0].rule_id == "R2_TONE"

    # KL & JS divergence checks
    p = [0.8, 0.1, 0.1]
    q = [0.1, 0.1, 0.8]
    assert kl_divergence(p, p) < 1e-9
    assert kl_divergence(p, q) > 1.0
    assert abs(jensen_shannon_divergence(p, q) - jensen_shannon_divergence(q, p)) < 1e-9

    print("bayesian._self_test: OK PASS (Beta-Binomial posteriors, credible intervals, KL/JS divergence)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
