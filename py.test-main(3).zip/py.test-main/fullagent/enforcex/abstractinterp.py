"""abstractinterp — Interval `[lo, hi]` & Taint Abstract Interpretation Engine.

Executes static abstract interpretation over Python AST snippets using the
product domain `Interval x Taint`:
  * `Interval(lo, hi)`: exact interval arithmetic (`+`, `-`, `*`, `//`) with
    Galois widening (`widen`) for loops and division-by-zero / negative-index
    detection (`0 in rhs_interval`).
  * `tainted: bool`: tracks whether an abstract value depends on untrusted input.

Self-test: ``python3 -m fullagent.enforcex.abstractinterp``
"""

from __future__ import annotations

import ast
import math
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

__all__ = [
    "Interval",
    "AbstractValue",
    "AbstractFixpointReport",
    "AbstractInterpreter",
    "analyze_ast_intervals",
]

INF = float("inf")
NEG_INF = float("-inf")


@dataclass(frozen=True)
class Interval:
    lo: float = NEG_INF
    hi: float = INF

    def is_bottom(self) -> bool:
        return self.lo > self.hi

    def contains(self, x: float) -> bool:
        return self.lo <= x <= self.hi

    def join(self, other: "Interval") -> "Interval":
        if self.is_bottom():
            return other
        if other.is_bottom():
            return self
        return Interval(min(self.lo, other.lo), max(self.hi, other.hi))

    def widen(self, nxt: "Interval") -> "Interval":
        lo = self.lo if nxt.lo >= self.lo else NEG_INF
        hi = self.hi if nxt.hi <= self.hi else INF
        return Interval(lo, hi)

    def add(self, other: "Interval") -> "Interval":
        return Interval(self.lo + other.lo, self.hi + other.hi)

    def sub(self, other: "Interval") -> "Interval":
        return Interval(self.lo - other.hi, self.hi - other.lo)

    def mul(self, other: "Interval") -> "Interval":
        prods = (self.lo * other.lo, self.lo * other.hi, self.hi * other.lo, self.hi * other.hi)
        valid = [p for p in prods if not math.isnan(p)]
        return Interval(min(valid), max(valid)) if valid else Interval()

    def to_dict(self) -> Dict[str, Any]:
        return {"lo": self.lo, "hi": self.hi}


@dataclass
class AbstractValue:
    interval: Interval = field(default_factory=Interval)
    tainted: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {"interval": self.interval.to_dict(), "tainted": self.tainted}


@dataclass
class AbstractFixpointReport:
    safe: bool = True
    env: Dict[str, AbstractValue] = field(default_factory=dict)
    warnings: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "safe": self.safe,
            "env": {k: v.to_dict() for k, v in self.env.items()},
            "warnings_count": len(self.warnings),
            "warnings": list(self.warnings),
        }


class AbstractInterpreter:
    """Evaluates Python AST statements over the Interval x Taint abstract domain."""

    def __init__(self, initial_env: Optional[Dict[str, AbstractValue]] = None) -> None:
        self.env: Dict[str, AbstractValue] = dict(initial_env) if initial_env else {}
        self.warnings: List[Dict[str, Any]] = []

    def _eval_expr(self, node: ast.AST) -> AbstractValue:
        if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
            v = float(node.value)
            return AbstractValue(Interval(v, v), False)
        if isinstance(node, ast.Name):
            if node.id in self.env:
                return self.env[node.id]
            tainted = node.id.startswith(("user_", "untrusted_", "raw_"))
            return AbstractValue(Interval(NEG_INF, INF), tainted)
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
            sub = self._eval_expr(node.operand)
            return AbstractValue(Interval(-sub.interval.hi, -sub.interval.lo), sub.tainted)
        if isinstance(node, ast.BinOp):
            left = self._eval_expr(node.left)
            right = self._eval_expr(node.right)
            tainted = left.tainted or right.tainted
            if isinstance(node.op, ast.Add):
                return AbstractValue(left.interval.add(right.interval), tainted)
            if isinstance(node.op, ast.Sub):
                return AbstractValue(left.interval.sub(right.interval), tainted)
            if isinstance(node.op, ast.Mult):
                return AbstractValue(left.interval.mul(right.interval), tainted)
            if isinstance(node.op, (ast.Div, ast.FloorDiv, ast.Mod)):
                if right.interval.contains(0.0):
                    self.warnings.append({
                        "rule_id": "ABS-DIV-ZERO",
                        "lineno": getattr(node, "lineno", 1),
                        "severity": "high",
                        "message": f"Possible division by zero: divisor interval [{right.interval.lo}, {right.interval.hi}] contains 0",
                    })
                return AbstractValue(Interval(NEG_INF, INF), tainted)
        return AbstractValue(Interval(NEG_INF, INF), False)

    def run(self, code: str) -> AbstractFixpointReport:
        try:
            tree = ast.parse(code or "")
        except SyntaxError as exc:
            return AbstractFixpointReport(safe=False, warnings=[{"rule_id": "ABS-SYNTAX", "message": str(exc)}])

        for stmt in tree.body:
            self._exec_stmt(stmt)

        return AbstractFixpointReport(
            safe=(len(self.warnings) == 0),
            env=dict(self.env),
            warnings=list(self.warnings),
        )

    def _exec_stmt(self, stmt: ast.AST) -> None:
        if isinstance(stmt, ast.Assign):
            val = self._eval_expr(stmt.value)
            for t in stmt.targets:
                if isinstance(t, ast.Name):
                    self.env[t.id] = val
        elif isinstance(stmt, ast.AugAssign) and isinstance(stmt.target, ast.Name):
            fake_bin = ast.BinOp(left=ast.Name(id=stmt.target.id, ctx=ast.Load()), op=stmt.op, right=stmt.value)
            ast.copy_location(fake_bin, stmt)
            self.env[stmt.target.id] = self._eval_expr(fake_bin)
        elif isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for s in stmt.body:
                self._exec_stmt(s)
        elif isinstance(stmt, ast.If):
            saved = dict(self.env)
            for s in stmt.body:
                self._exec_stmt(s)
            then_env = dict(self.env)
            self.env = saved
            for s in stmt.orelse:
                self._exec_stmt(s)
            else_env = dict(self.env)
            merged: Dict[str, AbstractValue] = {}
            for k in set(then_env) | set(else_env):
                a = then_env.get(k, AbstractValue())
                b = else_env.get(k, AbstractValue())
                merged[k] = AbstractValue(a.interval.join(b.interval), a.tainted or b.tainted)
            self.env = merged
        elif isinstance(stmt, ast.While):
            before = dict(self.env)
            for s in stmt.body:
                self._exec_stmt(s)
            after = dict(self.env)
            for k, av in after.items():
                if k in before:
                    self.env[k] = AbstractValue(
                        before[k].interval.widen(av.interval),
                        before[k].tainted or av.tainted,
                    )


def analyze_ast_intervals(code: str) -> AbstractFixpointReport:
    return AbstractInterpreter().run(code)


def _self_test() -> int:
    code = """
a = 10
b = 20
c = a + b
d = a - 10
risky = c / d
"""
    rep = analyze_ast_intervals(code)
    assert not rep.safe
    assert rep.env["c"].interval == Interval(30.0, 30.0)
    assert rep.env["d"].interval == Interval(0.0, 0.0)
    assert any(w["rule_id"] == "ABS-DIV-ZERO" for w in rep.warnings), rep.to_dict()

    print("abstractinterp._self_test: OK PASS (interval arithmetic, join/widen, div-by-zero detection)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
