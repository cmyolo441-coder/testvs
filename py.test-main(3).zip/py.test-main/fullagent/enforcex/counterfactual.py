"""counterfactual — Structural Causal Model (SCM) & Pearl `do()` Intervention Analyzer.

Implements Pearl's 3-step Counterfactual Algorithm over prompt compliance:
  1. Abduction: Given an observed turn `(clause_salience, context_noise,
     adversarial_pressure, observed_score)`, infer the exogenous background
     disturbance $U = u$.
  2. Action (`do(X = x')`): Intervene on the structural graph by setting
     `clause_salience = 1.0` (e.g., via recency pinning) or `adversarial_pressure = 0.0`
     (via input sanitization).
  3. Prediction: Compute the counterfactual compliance score $Y_{X \leftarrow x'}(u)$
     and the Average Causal Effect (ACE) to rank which intervention yields the
     largest compliance gain.

Self-test: ``python3 -m fullagent.enforcex.counterfactual``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

__all__ = [
    "TurnObservation",
    "CounterfactualReport",
    "CausalComplianceEngine",
    "evaluate_counterfactuals",
]


@dataclass
class TurnObservation:
    clause_salience: float = 0.5      # [0, 1]
    context_noise: float = 0.3        # [0, 1]
    adversarial_pressure: float = 0.2 # [0, 1]
    observed_score: float = 70.0      # [0, 100]


@dataclass
class CounterfactualReport:
    exogenous_u: float
    observed_score: float
    cf_pin_anchor_score: float
    cf_sanitize_input_score: float
    cf_compact_context_score: float
    ace_pin_anchor: float
    ace_sanitize_input: float
    ace_compact_context: float
    best_intervention: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "exogenous_u": round(self.exogenous_u, 4),
            "observed_score": round(self.observed_score, 2),
            "cf_pin_anchor_score": round(self.cf_pin_anchor_score, 2),
            "cf_sanitize_input_score": round(self.cf_sanitize_input_score, 2),
            "cf_compact_context_score": round(self.cf_compact_context_score, 2),
            "ace_pin_anchor": round(self.ace_pin_anchor, 2),
            "ace_sanitize_input": round(self.ace_sanitize_input, 2),
            "ace_compact_context": round(self.ace_compact_context, 2),
            "best_intervention": self.best_intervention,
        }


def _structural_y(salience: float, noise: float, pressure: float, u: float) -> float:
    """Structural equation for compliance score Y in [0, 100]."""
    # Base compliance driven by salience, degraded by noise, pressure, and interaction term
    eff_salience = salience * (1.0 - 0.35 * noise)
    raw = 50.0 + 48.0 * eff_salience - 38.0 * pressure - 18.0 * noise + u
    return max(0.0, min(100.0, raw))


def evaluate_counterfactuals(obs: TurnObservation) -> CounterfactualReport:
    # Step 1: Abduction — solve for exogenous noise U from observed outcome
    predicted_no_u = _structural_y(obs.clause_salience, obs.context_noise, obs.adversarial_pressure, 0.0)
    u = obs.observed_score - predicted_no_u

    # Step 2 & 3: Action do(X = x') & Prediction under fixed exogenous U = u
    cf_anchor = _structural_y(1.0, obs.context_noise, obs.adversarial_pressure, u)
    cf_sanitize = _structural_y(obs.clause_salience, obs.context_noise, 0.0, u)
    cf_compact = _structural_y(obs.clause_salience, 0.05, obs.adversarial_pressure, u)

    ace_anchor = max(0.0, cf_anchor - obs.observed_score)
    ace_sanitize = max(0.0, cf_sanitize - obs.observed_score)
    ace_compact = max(0.0, cf_compact - obs.observed_score)

    candidates = [
        ("pin_recency_anchor", ace_anchor),
        ("sanitize_adversarial_input", ace_sanitize),
        ("compact_context_noise", ace_compact),
    ]
    best = max(candidates, key=lambda x: x[1])[0]

    return CounterfactualReport(
        exogenous_u=u,
        observed_score=obs.observed_score,
        cf_pin_anchor_score=cf_anchor,
        cf_sanitize_input_score=cf_sanitize,
        cf_compact_context_score=cf_compact,
        ace_pin_anchor=ace_anchor,
        ace_sanitize_input=ace_sanitize,
        ace_compact_context=ace_compact,
        best_intervention=best,
    )


class CausalComplianceEngine:
    def analyze(self, obs: TurnObservation) -> CounterfactualReport:
        return evaluate_counterfactuals(obs)


def _self_test() -> int:
    # Turn with buried prompt (low salience=0.25) -> pinning anchor has largest ACE
    obs1 = TurnObservation(clause_salience=0.25, context_noise=0.2, adversarial_pressure=0.1, observed_score=55.0)
    r1 = evaluate_counterfactuals(obs1)
    assert r1.best_intervention == "pin_recency_anchor", r1.to_dict()
    assert r1.cf_pin_anchor_score > obs1.observed_score + 20.0

    # Turn with heavy adversarial injection (pressure=0.85) -> sanitizing input has largest ACE
    obs2 = TurnObservation(clause_salience=0.90, context_noise=0.1, adversarial_pressure=0.85, observed_score=52.0)
    r2 = evaluate_counterfactuals(obs2)
    assert r2.best_intervention == "sanitize_adversarial_input", r2.to_dict()

    print("counterfactual._self_test: OK PASS (Pearl abduction-action-prediction + do-calculus ACE)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
