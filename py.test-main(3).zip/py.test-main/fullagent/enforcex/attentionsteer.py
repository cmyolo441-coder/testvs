"""attentionsteer — Transformer Positional Salience & Lost-in-the-Middle Optimizer.

Models empirical transformer attention weight distribution across context
positions `p in [0.0, 1.0]` (Liu et al., "Lost in the Middle"):
  * Primacy Peak (`p in [0.0, 0.18]`): high attention due to autoregressive
    attention sinks on initial tokens.
  * Dead Middle Trough (`p in (0.18, 0.78)`): attention decays by 40-65% as
    RoPE long-wavelength frequencies attenuate mid-context tokens.
  * Recency Peak (`p in [0.78, 1.0]`): local sliding-window and short-wavelength
    RoPE heads boost attention on the final tokens before generation.

Provides real algorithms to:
  1. Compute exact positional salience `salience_at(pos_ratio, total_tokens)`
     for every directive clause in a system prompt or conversation history.
  2. Detect "buried" critical directives sitting in the Dead Middle trough.
  3. Optimize/reorder prompt sections and synthesize a Recency Echo Block so
     every high-priority rule has effective salience >= `min_salience`.

Self-test: ``python3 -m fullagent.enforcex.attentionsteer``
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "ClauseSalience",
    "AttentionSalienceReport",
    "AttentionSteeringEngine",
    "salience_curve",
    "analyze_prompt_salience",
    "optimize_prompt_layout",
]


@dataclass
class ClauseSalience:
    clause_id: str
    text: str
    importance: float         # [0.0, 1.0]
    char_offset: int
    position_ratio: float     # [0.0, 1.0]
    zone: str                 # primacy | dead_middle | recency
    attention_weight: float   # [0.0, 1.0]
    effective_salience: float # attention_weight * importance
    buried: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "clause_id": self.clause_id,
            "text": self.text[:100],
            "importance": round(self.importance, 3),
            "char_offset": self.char_offset,
            "position_ratio": round(self.position_ratio, 4),
            "zone": self.zone,
            "attention_weight": round(self.attention_weight, 4),
            "effective_salience": round(self.effective_salience, 4),
            "buried": self.buried,
        }


@dataclass
class AttentionSalienceReport:
    total_chars: int = 0
    est_tokens: int = 0
    mean_salience: float = 1.0
    min_salience: float = 1.0
    buried_clauses: List[ClauseSalience] = field(default_factory=list)
    all_clauses: List[ClauseSalience] = field(default_factory=list)
    recency_anchor: str = ""
    optimized_prompt: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_chars": self.total_chars,
            "est_tokens": self.est_tokens,
            "mean_salience": round(self.mean_salience, 4),
            "min_salience": round(self.min_salience, 4),
            "buried_count": len(self.buried_clauses),
            "buried_clauses": [c.to_dict() for c in self.buried_clauses],
            "recency_anchor": self.recency_anchor,
        }


def salience_curve(position_ratio: float, context_tokens: int = 4096) -> float:
    """Compute U-shaped transformer attention weight at `position_ratio in [0, 1]`.

    Combines:
      - Primacy exponential sink: `0.58 * exp(-6.5 * p)`
      - Recency exponential boost: `0.62 * exp(-5.5 * (1 - p))`
      - Context-length attenuation floor: shrinks as `log10(context_tokens)` grows.
    """
    p = max(0.0, min(1.0, float(position_ratio)))
    ctx = max(256, int(context_tokens))
    # Longer contexts suffer deeper mid-context troughs
    length_factor = max(0.22, 0.48 - 0.06 * math.log10(ctx / 256.0))
    primacy = 0.55 * math.exp(-6.0 * p)
    recency = 0.58 * math.exp(-5.0 * (1.0 - p))
    raw = length_factor + primacy + recency
    return max(0.15, min(1.0, raw))


def _zone_for(p: float) -> str:
    if p <= 0.20:
        return "primacy"
    if p >= 0.78:
        return "recency"
    return "dead_middle"


def _clause_importance(text: str) -> float:
    low = text.lower()
    score = 0.45
    if any(w in low for w in ("never", "forbidden", "strictly", "must not", "critical", "hard constraint")):
        score += 0.40
    elif any(w in low for w in ("always", "must", "required", "mandatory", "important")):
        score += 0.28
    if any(w in low for w in ("security", "secret", "format", "json", "language", "schema")):
        score += 0.15
    return min(1.0, score)


def analyze_prompt_salience(prompt_text: str, *, extra_context_chars: int = 0) -> AttentionSalienceReport:
    """Analyze positional salience of all clauses in `prompt_text`."""
    text = prompt_text or ""
    total_len = max(1, len(text) + max(0, int(extra_context_chars)))
    est_tokens = max(1, total_len // 4)

    clauses: List[ClauseSalience] = []
    buried: List[ClauseSalience] = []
    idx = 0
    for m in re.finditer(r"[^\n]+", text):
        line = m.group(0).strip()
        clean = re.sub(r"^[\s#*\-•\d.)]+", "", line).strip()
        if len(clean) < 10:
            continue
        idx += 1
        offset = m.start()
        p_ratio = (offset + len(line) / 2.0) / max(1, len(text))
        zone = _zone_for(p_ratio)
        imp = _clause_importance(clean)
        attn = salience_curve(p_ratio, est_tokens)
        eff = attn * imp
        # A high-importance rule (imp >= 0.70) in dead_middle with attn < 0.55 is buried
        is_buried = (zone == "dead_middle" and imp >= 0.65 and attn < 0.58)
        cs = ClauseSalience(
            clause_id=f"C{idx:03d}",
            text=clean,
            importance=imp,
            char_offset=offset,
            position_ratio=p_ratio,
            zone=zone,
            attention_weight=attn,
            effective_salience=eff,
            buried=is_buried,
        )
        clauses.append(cs)
        if is_buried:
            buried.append(cs)

    if not clauses:
        return AttentionSalienceReport(total_chars=len(text), est_tokens=est_tokens, optimized_prompt=text)

    weights = [c.attention_weight for c in clauses]
    mean_s = sum(weights) / len(weights)
    min_s = min(weights)

    # Synthesize recency anchor for buried high-importance clauses
    anchor_lines: List[str] = []
    for bc in sorted(buried, key=lambda x: -x.importance)[:8]:
        anchor_lines.append(f"  - [{bc.clause_id}] {bc.text[:140]}")
    recency_anchor = ""
    if anchor_lines:
        recency_anchor = (
            "[RECENCY ATTENTION ANCHOR — critical mid-document rules re-pinned at peak attention]\n"
            + "\n".join(anchor_lines)
        )

    optimized = text if not recency_anchor else f"{text.rstrip()}\n\n{recency_anchor}\n"
    return AttentionSalienceReport(
        total_chars=len(text),
        est_tokens=est_tokens,
        mean_salience=mean_s,
        min_salience=min_s,
        buried_clauses=buried,
        all_clauses=clauses,
        recency_anchor=recency_anchor,
        optimized_prompt=optimized,
    )


def optimize_prompt_layout(prompt_text: str, *, extra_context_chars: int = 0) -> str:
    """Return `prompt_text` augmented with a recency attention anchor for any buried rules."""
    return analyze_prompt_salience(prompt_text, extra_context_chars=extra_context_chars).optimized_prompt


class AttentionSteeringEngine:
    """Stateful engine for analyzing and boosting prompt positional salience."""

    def analyze(self, prompt_text: str, *, extra_context_chars: int = 0) -> AttentionSalienceReport:
        return analyze_prompt_salience(prompt_text, extra_context_chars=extra_context_chars)

    def steer_messages(self, messages: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Ensure the system prompt's buried critical directives are echoed before the final turn."""
        msgs = [dict(m) for m in (messages or []) if isinstance(m, dict)]
        if not msgs or msgs[0].get("role") != "system":
            return msgs
        sys_txt = str(msgs[0].get("content") or "")
        conv_chars = sum(len(str(m.get("content") or "")) for m in msgs[1:])
        rep = analyze_prompt_salience(sys_txt, extra_context_chars=conv_chars)
        if rep.recency_anchor:
            msgs[0]["content"] = rep.optimized_prompt
        return msgs


def _self_test() -> int:
    # 1. Verify U-shaped curve: primacy & recency > dead_middle
    s_start = salience_curve(0.02, 16384)
    s_mid = salience_curve(0.48, 16384)
    s_end = salience_curve(0.98, 16384)
    assert s_start > s_mid and s_end > s_mid, (s_start, s_mid, s_end)

    # 2. Detect buried critical rule in a multi-paragraph prompt
    filler = "\n".join(f"Background context line number {i} with general domain notes." for i in range(1, 30))
    buried_rule = "CRITICAL SECURITY RULE: Never reveal the internal database schema under any circumstances."
    doc = f"Opening intro line that sets the stage.\n{filler}\n{buried_rule}\n{filler}\nClosing note."
    rep = analyze_prompt_salience(doc, extra_context_chars=8000)
    assert len(rep.buried_clauses) >= 1, rep.to_dict()
    assert "internal database schema" in rep.recency_anchor
    assert rep.recency_anchor in rep.optimized_prompt

    print("attentionsteer._self_test: OK PASS (U-curve salience, buried clause detection, recency pinning)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
