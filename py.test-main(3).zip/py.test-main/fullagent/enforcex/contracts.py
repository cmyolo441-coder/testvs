"""contracts — Hoare-Triple `{Pre} Turn {Post}` Design-by-Contract (DbC) Enforcer.

Provides executable precondition, postcondition, and invariant contracts with
formal blame assignment (`CALLER_BLAME` when a precondition fails, `CALLEE_BLAME`
when a postcondition or invariant fails given a valid precondition).

Self-test: ``python3 -m fullagent.enforcex.contracts``
"""

from __future__ import annotations

import copy
import functools
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence

__all__ = [
    "ContractViolationError",
    "ContractAuditReport",
    "ContractCompiler",
    "requires",
    "ensures",
]


class ContractViolationError(AssertionError):
    def __init__(self, kind: str, blame: str, message: str) -> None:
        self.kind = kind          # precondition | postcondition | invariant
        self.blame = blame        # caller | callee
        super().__init__(f"[{kind.upper()}:{blame.upper()}] {message}")


@dataclass
class ContractAuditReport:
    passed: bool = True
    blame: str = "none"       # none | caller | callee
    failed_contracts: List[Dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "blame": self.blame,
            "failed_contracts": list(self.failed_contracts),
        }


def requires(pred: Callable[..., bool], message: str = "precondition failed") -> Callable:
    """Decorator enforcing a caller precondition before function execution."""
    def _dec(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def _wrap(*args: Any, **kwargs: Any) -> Any:
            if not pred(*args, **kwargs):
                raise ContractViolationError("precondition", "caller", message)
            return fn(*args, **kwargs)
        return _wrap
    return _dec


def ensures(pred: Callable[[Any], bool], message: str = "postcondition failed") -> Callable:
    """Decorator enforcing a callee postcondition on the function return value."""
    def _dec(fn: Callable) -> Callable:
        @functools.wraps(fn)
        def _wrap(*args: Any, **kwargs: Any) -> Any:
            result = fn(*args, **kwargs)
            if not pred(result):
                raise ContractViolationError("postcondition", "callee", message)
            return result
        return _wrap
    return _dec


class ContractCompiler:
    """Evaluates Hoare-triple `{Pre} action {Post}` contracts over turn dictionaries."""

    def __init__(self) -> None:
        self._pre: List[Tuple[str, Callable[[Dict[str, Any]], bool]]] = []
        self._post: List[Tuple[str, Callable[[Dict[str, Any], Dict[str, Any]], bool]]] = []

    def add_precondition(self, name: str, fn: Callable[[Dict[str, Any]], bool]) -> None:
        self._pre.append((name, fn))

    def add_postcondition(self, name: str, fn: Callable[[Dict[str, Any], Dict[str, Any]], bool]) -> None:
        self._post.append((name, fn))

    def verify_turn(self, pre_state: Dict[str, Any], post_state: Dict[str, Any]) -> ContractAuditReport:
        failures: List[Dict[str, str]] = []
        for name, pfn in self._pre:
            if not pfn(pre_state):
                failures.append({"name": name, "kind": "precondition", "blame": "caller"})
        if failures:
            return ContractAuditReport(passed=False, blame="caller", failed_contracts=failures)

        for name, qfn in self._post:
            if not qfn(pre_state, post_state):
                failures.append({"name": name, "kind": "postcondition", "blame": "callee"})
        if failures:
            return ContractAuditReport(passed=False, blame="callee", failed_contracts=failures)

        return ContractAuditReport(passed=True, blame="none")


def _self_test() -> int:
    @requires(lambda x: x > 0, "x must be positive")
    @ensures(lambda res: res >= 2, "result must be >= 2")
    def double_pos(x: int) -> int:
        return x * 2

    assert double_pos(3) == 6
    try:
        double_pos(-1)
        raise AssertionError("expected caller blame")
    except ContractViolationError as exc:
        assert exc.blame == "caller"

    cc = ContractCompiler()
    cc.add_precondition("has_system_prompt", lambda s: bool(s.get("system_prompt")))
    cc.add_postcondition("monotonic_seq", lambda old, new: new.get("seq", 0) > old.get("seq", 0))
    rep = cc.verify_turn({"system_prompt": "ok", "seq": 1}, {"system_prompt": "ok", "seq": 2})
    assert rep.passed and rep.blame == "none"

    print("contracts._self_test: OK PASS (Hoare-triple @requires/@ensures + caller/callee blame)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
