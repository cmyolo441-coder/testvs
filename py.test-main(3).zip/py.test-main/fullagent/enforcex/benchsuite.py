"""benchsuite — Verifiable Instruction-Following Benchmark (IFEval) & Elo Rating Engine.

Implements 12 deterministic, programmatic IFEval instruction verifiers
(Zhou et al., "Instruction-Following Evaluation for Large Language Models"):
  1. `no_commas`: response contains zero commas (`,`)
  2. `json_format`: entire response is valid JSON
  3. `lowercase_only`: all alphabetic characters are lowercase
  4. `uppercase_only`: all alphabetic characters are uppercase
  5. `title_wrapped`: response contains a title wrapped in `<<Title>>`
  6. `quotation_wrapped`: entire response is wrapped in double quotes
  7. `postscript`: response ends with a `P.S.` or `P.P.S.` postscript
  8. `min_words`: word count >= N
  9. `max_words`: word count <= N
  10. `exact_bullets`: bullet count == N
  11. `include_keywords`: all specified keywords appear
  12. `exclude_keywords`: none of the specified forbidden words appear

Also computes exact Elo rating updates between competing models/configurations.

Self-test: ``python3 -m fullagent.enforcex.benchsuite``
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Sequence

__all__ = [
    "BenchmarkScorecard",
    "ComplianceBenchmarkSuite",
    "verify_ifeval_constraint",
    "update_elo",
]


@dataclass
class BenchmarkScorecard:
    total_constraints: int = 0
    passed_constraints: int = 0
    strict_accuracy: float = 100.0
    results: Dict[str, bool] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_constraints": self.total_constraints,
            "passed_constraints": self.passed_constraints,
            "strict_accuracy": round(self.strict_accuracy, 2),
            "results": dict(self.results),
        }


def verify_ifeval_constraint(name: str, response_text: str, param: Any = None) -> bool:
    s = response_text or ""
    stripped = s.strip()
    if name == "no_commas":
        return "," not in s
    if name == "json_format":
        try:
            json.loads(stripped)
            return True
        except Exception:
            return False
    if name == "lowercase_only":
        alpha = [c for c in s if c.isalpha()]
        return bool(alpha) and all(c.islower() for c in alpha)
    if name == "uppercase_only":
        alpha = [c for c in s if c.isalpha()]
        return bool(alpha) and all(c.isupper() for c in alpha)
    if name == "title_wrapped":
        return bool(re.search(r"<<[^<>]+>>", s))
    if name == "quotation_wrapped":
        return len(stripped) >= 2 and stripped.startswith('"') and stripped.endswith('"')
    if name == "postscript":
        return bool(re.search(r"\bP\.(?:P\.)?S\.", s))
    if name == "min_words":
        return len(s.split()) >= int(param or 1)
    if name == "max_words":
        return len(s.split()) <= int(param or 100)
    if name == "exact_bullets":
        bullets = re.findall(r"^\s*(?:[-*•]|\d+[.)])\s+", s, flags=re.M)
        return len(bullets) == int(param or 1)
    if name == "include_keywords":
        low = s.lower()
        return all(str(w).lower() in low for w in (param or ()))
    if name == "exclude_keywords":
        low = s.lower()
        return all(str(w).lower() not in low for w in (param or ()))
    return False


def update_elo(rating_a: float, rating_b: float, score_a: float, *, k_factor: float = 32.0) -> Tuple[float, float]:
    """Compute updated Elo ratings `(new_a, new_b)` given `score_a in {0.0, 0.5, 1.0}`."""
    exp_a = 1.0 / (1.0 + 10.0 ** ((rating_b - rating_a) / 400.0))
    exp_b = 1.0 - exp_a
    new_a = rating_a + k_factor * (score_a - exp_a)
    new_b = rating_b + k_factor * ((1.0 - score_a) - exp_b)
    return new_a, new_b


class ComplianceBenchmarkSuite:
    def evaluate(self, response_text: str, constraints: Dict[str, Any]) -> BenchmarkScorecard:
        results: Dict[str, bool] = {}
        for cname, param in (constraints or {}).items():
            results[cname] = verify_ifeval_constraint(cname, response_text, param)
        tot = len(results)
        passed = sum(1 for ok in results.values() if ok)
        acc = (passed / float(tot) * 100.0) if tot > 0 else 100.0
        return BenchmarkScorecard(
            total_constraints=tot,
            passed_constraints=passed,
            strict_accuracy=acc,
            results=results,
        )


def _self_test() -> int:
    suite = ComplianceBenchmarkSuite()
    sample = (
        "<<Architecture Overview>>\n"
        "- first module verified without commas\n"
        "- second module verified cleanly\n"
        "P.S. all checks green"
    )
    card = suite.evaluate(
        sample,
        {
            "no_commas": True,
            "title_wrapped": True,
            "exact_bullets": 2,
            "postscript": True,
            "include_keywords": ["architecture", "module"],
            "exclude_keywords": ["synergy"],
            "max_words": 40,
        },
    )
    assert card.strict_accuracy == 100.0, card.to_dict()

    ra, rb = update_elo(1500.0, 1500.0, 1.0)
    assert ra == 1516.0 and rb == 1484.0

    print("benchsuite._self_test: OK PASS (12 IFEval verifiable constraints + Elo rating updates)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
