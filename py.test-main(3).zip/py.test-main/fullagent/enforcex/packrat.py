"""packrat — Bryan Ford's Packrat Parsing Expression Grammar (PEG) Memoizing Engine.

Implements linear-time `O(n)` memoized **Packrat PEG Parsing** (Ford, ICFP 2002)
with full support for:
  * Terminal literals & regex patterns (`Literal`, `RegexMatch`)
  * Concatenation (`Seq(e1, e2, ...)`)
  * Prioritized Ordered Choice (`Choice(e1, e2, ...)` — `e1 / e2`)
  * Zero-or-more (`ZeroOrMore(e)` — `e*`) & One-or-more (`OneOrMore(e)` — `e+`)
  * Positive syntactic predicate / lookahead (`AndPredicate(e)` — `&e`, consumes 0 chars)
  * Negative syntactic predicate / lookahead (`NotPredicate(e)` — `!e`, consumes 0 chars)
  * Non-terminal rule references (`Ref("RuleName")`) with `(rule_name, pos)` packrat
    memoization table guaranteeing `O(n)` worst-case runtime even with backtracking!

Self-test: ``python3 -m fullagent.enforcex.packrat``
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

__all__ = [
    "PEGExpr",
    "PEGNode",
    "PackratGrammar",
    "Lit",
    "Rx",
    "Seq",
    "Choice",
    "Star",
    "Plus",
    "AndPred",
    "NotPred",
    "Ref",
]


@dataclass(frozen=True)
class PEGNode:
    kind: str
    text: str
    start: int
    end: int
    children: Tuple["PEGNode", ...] = ()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "kind": self.kind,
            "text": self.text,
            "start": self.start,
            "end": self.end,
            "children": [c.to_dict() for c in self.children],
        }


class PEGExpr:
    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        raise NotImplementedError


@dataclass(frozen=True)
class Lit(PEGExpr):
    literal: str

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        end = pos + len(self.literal)
        if text[pos:end] == self.literal:
            return end, PEGNode("Lit", self.literal, pos, end)
        return None


@dataclass(frozen=True)
class Rx(PEGExpr):
    pattern: str

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        m = re.compile(self.pattern).match(text, pos)
        if m:
            return m.end(), PEGNode("Rx", m.group(0), pos, m.end())
        return None


@dataclass(frozen=True)
class Seq(PEGExpr):
    items: Tuple[PEGExpr, ...]

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        cur = pos
        kids: List[PEGNode] = []
        for it in self.items:
            res = it.eval(grammar, text, cur)
            if res is None:
                return None
            cur, node = res
            kids.append(node)
        return cur, PEGNode("Seq", text[pos:cur], pos, cur, tuple(kids))


@dataclass(frozen=True)
class Choice(PEGExpr):
    options: Tuple[PEGExpr, ...]

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        for opt in self.options:
            res = opt.eval(grammar, text, pos)
            if res is not None:
                return res
        return None


@dataclass(frozen=True)
class Star(PEGExpr):
    inner: PEGExpr

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        cur = pos
        kids: List[PEGNode] = []
        while True:
            res = self.inner.eval(grammar, text, cur)
            if res is None or res[0] == cur:
                break
            cur, node = res
            kids.append(node)
        return cur, PEGNode("Star", text[pos:cur], pos, cur, tuple(kids))


@dataclass(frozen=True)
class Plus(PEGExpr):
    inner: PEGExpr

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        first = self.inner.eval(grammar, text, pos)
        if first is None:
            return None
        cur, n0 = first
        rest = Star(self.inner).eval(grammar, text, cur)
        assert rest is not None
        end_pos, rest_node = rest
        return end_pos, PEGNode("Plus", text[pos:end_pos], pos, end_pos, (n0,) + rest_node.children)


@dataclass(frozen=True)
class AndPred(PEGExpr):
    inner: PEGExpr

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        res = self.inner.eval(grammar, text, pos)
        if res is not None:
            return pos, PEGNode("AndPred", "", pos, pos)
        return None


@dataclass(frozen=True)
class NotPred(PEGExpr):
    inner: PEGExpr

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        res = self.inner.eval(grammar, text, pos)
        if res is None:
            return pos, PEGNode("NotPred", "", pos, pos)
        return None


@dataclass(frozen=True)
class Ref(PEGExpr):
    rule_name: str

    def eval(self, grammar: "PackratGrammar", text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        return grammar.eval_rule(self.rule_name, text, pos)


class PackratGrammar:
    """Memoizing Packrat PEG parser with `(rule_name, offset)` cache."""

    def __init__(self, start_rule: str = "Start") -> None:
        self.start_rule = str(start_rule)
        self.rules: Dict[str, PEGExpr] = {}
        self.memo: Dict[Tuple[str, int], Optional[Tuple[int, PEGNode]]] = {}
        self.memo_hits = 0

    def define(self, name: str, expr: PEGExpr) -> None:
        self.rules[str(name)] = expr

    def eval_rule(self, name: str, text: str, pos: int) -> Optional[Tuple[int, PEGNode]]:
        key = (name, pos)
        if key in self.memo:
            self.memo_hits += 1
            return self.memo[key]
        expr = self.rules.get(name)
        if expr is None:
            raise KeyError(f"Undefined PEG rule: {name!r}")
        res = expr.eval(self, text, pos)
        if res is not None:
            end_pos, node = res
            wrapped = (end_pos, PEGNode(name, text[pos:end_pos], pos, end_pos, (node,)))
            self.memo[key] = wrapped
            return wrapped
        self.memo[key] = None
        return None

    def parse(self, text: str, *, full_match: bool = True) -> Optional[PEGNode]:
        self.memo.clear()
        self.memo_hits = 0
        res = self.eval_rule(self.start_rule, text, 0)
        if res is None:
            return None
        end_pos, node = res
        if full_match and end_pos != len(text):
            return None
        return node


def _self_test() -> int:
    # Classic non-Context-Free language a^n b^n c^n parsed in O(n) via Packrat PEG lookahead `&` and `!`:
    # S <- &(A !'b') 'a'+ B !.
    # A <- 'a' A? 'b'
    # B <- 'b' B? 'c'
    g = PackratGrammar("S")
    g.define("A", Seq((Lit("a"), Choice((Ref("A"), Lit(""))), Lit("b"))))
    g.define("B", Seq((Lit("b"), Choice((Ref("B"), Lit(""))), Lit("c"))))
    g.define(
        "S",
        Seq((
            AndPred(Seq((Ref("A"), NotPred(Lit("b"))))),
            Plus(Lit("a")),
            Ref("B"),
            NotPred(Rx(r".")),
        )),
    )

    assert g.parse("aaabbbccc") is not None
    assert g.parse("aabbc") is None
    assert g.parse("aaabbbcccc") is None

    print("packrat._self_test: OK PASS (Ford O(n) Packrat PEG memoization + non-CFG a^n b^n c^n lookahead)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
