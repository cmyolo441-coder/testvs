"""entropysense — Multi-Scale Shannon, Rényi, Tsallis & Zlib Compression Complexity Analyzer.

Detects two opposite information-theoretic failure modes in LLM generations
and untrusted inputs:
  1. Mode Collapse / Degenerate Repetition: abnormally low compression ratio
     and low Rényi collision entropy ($H_2$).
  2. Steganographic / Obfuscated Payload Smuggling: high-entropy spikes
     ($H_1 > 4.6$ bits/char) inside sliding windows caused by Base64/Hex/XOR
     blobs hidden inside normal prose.

Self-test: ``python3 -m fullagent.enforcex.entropysense``
"""

from __future__ import annotations

import math
import zlib
from dataclasses import dataclass, field
from typing import Any, Dict, List

__all__ = [
    "EntropyAnomalyReport",
    "EntropyComplexityAnalyzer",
    "shannon_entropy",
    "renyi_collision_entropy",
    "tsallis_entropy",
    "compression_ratio",
    "analyze_entropy",
]


@dataclass
class EntropyAnomalyReport:
    shannon_bits: float = 0.0
    renyi_bits: float = 0.0
    tsallis_q2: float = 0.0
    zlib_ratio: float = 1.0
    max_window_entropy: float = 0.0
    mode_collapse: bool = False
    obfuscated_spike: bool = False
    anomalies: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "shannon_bits": round(self.shannon_bits, 4),
            "renyi_bits": round(self.renyi_bits, 4),
            "tsallis_q2": round(self.tsallis_q2, 4),
            "zlib_ratio": round(self.zlib_ratio, 4),
            "max_window_entropy": round(self.max_window_entropy, 4),
            "mode_collapse": self.mode_collapse,
            "obfuscated_spike": self.obfuscated_spike,
            "anomalies": list(self.anomalies),
        }


def _probs(text: str) -> List[float]:
    if not text:
        return []
    counts: Dict[str, int] = {}
    for ch in text:
        counts[ch] = counts.get(ch, 0) + 1
    n = float(len(text))
    return [c / n for c in counts.values()]


def shannon_entropy(text: str) -> float:
    """Compute Shannon entropy H_1(X) = -sum p_i log2(p_i) in bits per character."""
    ps = _probs(text)
    return -sum(p * math.log2(p) for p in ps if p > 0.0)


def renyi_collision_entropy(text: str) -> float:
    """Compute Rényi quadratic collision entropy H_2(X) = -log2(sum p_i^2)."""
    ps = _probs(text)
    if not ps:
        return 0.0
    s2 = sum(p * p for p in ps)
    return -math.log2(s2) if s2 > 0.0 else 0.0


def tsallis_entropy(text: str, q: float = 2.0) -> float:
    """Compute Tsallis entropy S_q(X) = (1 - sum p_i^q) / (q - 1)."""
    ps = _probs(text)
    if not ps or abs(q - 1.0) < 1e-6:
        return shannon_entropy(text)
    return (1.0 - sum(p ** q for p in ps)) / (q - 1.0)


def compression_ratio(text: str) -> float:
    """Compute compressed_bytes / raw_bytes using deflate (zlib)."""
    if not text:
        return 1.0
    raw = text.encode("utf-8", "replace")
    if len(raw) < 32:
        return 1.0
    comp = zlib.compress(raw, level=6)
    return len(comp) / float(len(raw))


def analyze_entropy(text: str, *, window: int = 80, step: int = 40) -> EntropyAnomalyReport:
    s = text or ""
    if not s:
        return EntropyAnomalyReport()

    h1 = shannon_entropy(s)
    h2 = renyi_collision_entropy(s)
    tq = tsallis_entropy(s, q=2.0)
    z_rat = compression_ratio(s)

    max_win = h1
    w = max(32, int(window))
    st = max(16, int(step))
    if len(s) >= w:
        for i in range(0, len(s) - w + 1, st):
            chunk = s[i:i + w]
            # Only flag chunks with minimal whitespace (like base64/hex blobs)
            wh_ratio = sum(1 for c in chunk if c.isspace()) / float(w)
            ch_h = shannon_entropy(chunk)
            if wh_ratio < 0.05 and ch_h > max_win:
                max_win = ch_h

    anomalies: List[str] = []
    mode_collapse = len(s) >= 120 and z_rat < 0.18
    if mode_collapse:
        anomalies.append(f"mode_collapse: zlib compression ratio={z_rat:.3f} (< 0.18)")

    obf_spike = max_win >= 5.15
    if obf_spike:
        anomalies.append(f"high_entropy_blob: window Shannon H={max_win:.2f} bits/char")

    return EntropyAnomalyReport(
        shannon_bits=h1,
        renyi_bits=h2,
        tsallis_q2=tq,
        zlib_ratio=z_rat,
        max_window_entropy=max_win,
        mode_collapse=mode_collapse,
        obfuscated_spike=obf_spike,
        anomalies=anomalies,
    )


class EntropyComplexityAnalyzer:
    def analyze(self, text: str) -> EntropyAnomalyReport:
        return analyze_entropy(text)


def _self_test() -> int:
    normal = "The system architecture separates the Temporal Kernel from the stateless tool handlers."
    r_norm = analyze_entropy(normal)
    assert not r_norm.mode_collapse and not r_norm.obfuscated_spike, r_norm.to_dict()

    collapsed = "repeat this phrase again and again " * 20
    r_col = analyze_entropy(collapsed)
    assert r_col.mode_collapse, r_col.to_dict()

    blob = "Normal intro. " + "aB3$xZ9!qW8@pL7#mN6%vC5^bG4&hJ2*kF1(dS0)yT9+rE8=uI7~oP6_zX5" * 2
    r_blob = analyze_entropy(blob)
    assert r_blob.obfuscated_spike, r_blob.to_dict()

    print("entropysense._self_test: OK PASS (Shannon, Rényi, Tsallis, zlib mode-collapse & blob detection)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
