"""personaguard — Stylometric Persona Lock (Contractions, Active Voice & Anti-Preachiness).

Enforces a warm, direct peer-collaborator voice:
  * Auto-Contracts Stiff Uncontracted Openings: converts `"I have created"`,
     `"I have drafted"`, `"I have located"`, `"Here is"` -> `"I've created"`,
     `"I've drafted"`, `"I've located"`, `"Here's"`.
  * Passive Opening Detector: flags clinical passive openings (`"A summary has
    been compiled"`, `"The files have been updated"`).
  * Self-Congratulatory Superlative Filter: blocks `"flawlessly"`, `"100% correct"`,
    `"perfectly"`, `"Summary of Accomplishments"`.
  * Internal System Jargon Blocker: blocks exposing internal terms like
    `"workspace items"` or raw `/working_dir/...` container paths.

Self-test: ``python3 -m fullagent.enforcex.personaguard``
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple

__all__ = [
    "PersonaFidelityReport",
    "PersonaLockEngine",
    "enforce_persona_style",
]

_UNCONTRACTED_SUBS: Tuple[Tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"\bI have (created|drafted|located|updated|prepared|fixed|built|added)\b"), r"I've \1"),
    (re.compile(r"\bHere is (the|your|a|an)\b"), r"Here's \1"),
    (re.compile(r"\bIt is (a|an|ready|important)\b"), r"It's \1"),
)

_PASSIVE_RE = re.compile(
    r"\b(?:a\s+summary\s+has\s+been\s+compiled|the\s+(?:report|file|document)\s+has\s+been\s+(?:created|generated))\b",
    re.I,
)
_SUPERLATIVE_RE = re.compile(
    r"\b(?:flawlessly|100%\s+correct|undisputed\s+gold\s+standard|summary\s+of\s+accomplishments|summary\s+of\s+actions)\b",
    re.I,
)
_INTERNAL_PATH_RE = re.compile(r"(?:/working_dir/[a-zA-Z0-9_/-]+|artifacts/file_generation/ttl=63d/[a-zA-Z0-9_/-]+)")


@dataclass
class PersonaFidelityReport:
    passed: bool = True
    score: float = 100.0
    rewritten_text: str = ""
    contractions_applied: int = 0
    violations: List[Dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "passed": self.passed,
            "score": round(self.score, 2),
            "contractions_applied": self.contractions_applied,
            "violations_count": len(self.violations),
            "violations": list(self.violations),
            "rewritten_text": self.rewritten_text,
        }


def enforce_persona_style(text: str) -> PersonaFidelityReport:
    out = text or ""
    contractions = 0
    violations: List[Dict[str, str]] = []

    for pat, repl in _UNCONTRACTED_SUBS:
        new_out, n = pat.subn(repl, out)
        if n > 0:
            contractions += n
            out = new_out

    for m in _PASSIVE_RE.finditer(out):
        violations.append({
            "rule_id": "PERS-PASSIVE-VOICE",
            "severity": "low",
            "evidence": m.group(0),
            "message": "Stiff passive-voice announcement detected; use active first-person ('I've created...').",
        })

    for m in _SUPERLATIVE_RE.finditer(out):
        violations.append({
            "rule_id": "PERS-SUPERLATIVE",
            "severity": "medium",
            "evidence": m.group(0),
            "message": f"Self-congratulatory superlative '{m.group(0)}' is forbidden.",
        })

    for m in _INTERNAL_PATH_RE.finditer(out):
        violations.append({
            "rule_id": "PERS-INTERNAL-PATH",
            "severity": "high",
            "evidence": m.group(0),
            "message": "Internal sandbox path exposed in user-facing response.",
        })

    score = max(0.0, 100.0 - 20.0 * len(violations) - 3.0 * contractions)
    return PersonaFidelityReport(
        passed=(len(violations) == 0),
        score=score,
        rewritten_text=out,
        contractions_applied=contractions,
        violations=violations,
    )


class PersonaLockEngine:
    def evaluate(self, text: str) -> PersonaFidelityReport:
        return enforce_persona_style(text)


def _self_test() -> int:
    stiff = "I have created the report. Here is the summary."
    rep = enforce_persona_style(stiff)
    assert rep.passed and rep.contractions_applied == 2
    assert rep.rewritten_text == "I've created the report. Here's the summary."

    bad = "A summary has been compiled flawlessly at /working_dir/c_123/output/x.pdf."
    rep_bad = enforce_persona_style(bad)
    assert not rep_bad.passed and len(rep_bad.violations) == 3

    print("personaguard._self_test: OK PASS (contractions rewrite, passive/superlative/path blocker)")
    return 0


if __name__ == "__main__":
    raise SystemExit(_self_test())
